/*
  # Fix customers table permissions

  1. Changes
    - Ensure proper RLS setup for customers table
    - Add explicit permissions for authenticated users
    - Clean up existing policies

  2. Security
    - Maintain RLS protection
    - Allow authenticated users to perform all operations
*/

-- First ensure RLS is enabled
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;

-- Drop existing policies for customers to avoid conflicts
DO $$ 
BEGIN
    IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'customers') THEN
        DROP POLICY IF EXISTS "Enable full access for authenticated users" ON customers;
        DROP POLICY IF EXISTS "Allow full access to customers" ON customers;
    END IF;
END $$;

-- Create comprehensive policy for customers
CREATE POLICY "customers_full_access"
    ON customers
    AS PERMISSIVE
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- Ensure proper grants
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON customers TO authenticated;