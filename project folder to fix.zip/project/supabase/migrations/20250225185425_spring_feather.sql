/*
  # Final Database Structure Fix

  1. Changes
    - Complete rebuild of shipped_boxes table
    - Ensure all required columns exist
    - Proper constraints and defaults
    - Correct permissions

  2. Details
    - Preserve existing data
    - Set proper column types
    - Add missing columns
    - Set up proper relationships
*/

-- First create a backup of existing data
CREATE TEMP TABLE IF NOT EXISTS temp_shipped_boxes AS 
SELECT * FROM shipped_boxes;

-- Drop the existing table completely
DROP TABLE IF EXISTS shipped_boxes CASCADE;

-- Create the table with the complete correct structure
CREATE TABLE shipped_boxes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL,
  weight decimal NOT NULL,
  price decimal NOT NULL DEFAULT 0,
  bag_type text,
  in_cage boolean DEFAULT false,
  archived boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_type_check CHECK (
    (type IN ('single', 'small', 'big') AND bag_type IS NULL) OR
    (type = 'bag' AND bag_type IN ('standard', 'large'))
  )
);

-- Create indexes for better performance
CREATE INDEX idx_shipped_boxes_customer_id ON shipped_boxes(customer_id);
CREATE INDEX idx_shipped_boxes_archived ON shipped_boxes(archived);
CREATE INDEX idx_shipped_boxes_created_at ON shipped_boxes(created_at DESC);

-- Restore the data with proper prices
INSERT INTO shipped_boxes (
  id,
  customer_id,
  type,
  weight,
  price,
  archived,
  created_at
)
SELECT
  id,
  customer_id,
  type,
  weight,
  CASE
    WHEN type = 'single' THEN 3.99
    WHEN type = 'small' THEN 7.99
    WHEN type = 'big' THEN 9.99
    ELSE 0
  END as price,
  COALESCE(archived, false),
  created_at
FROM temp_shipped_boxes;

-- Drop the temporary table
DROP TABLE temp_shipped_boxes;

-- Verify twilio_config exists and has correct structure
CREATE TABLE IF NOT EXISTS twilio_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_sid text NOT NULL,
  auth_token text NOT NULL,
  phone_number text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for twilio_config
DROP TRIGGER IF EXISTS update_twilio_config_updated_at ON twilio_config;
CREATE TRIGGER update_twilio_config_updated_at
  BEFORE UPDATE ON twilio_config
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Disable RLS on both tables
ALTER TABLE shipped_boxes DISABLE ROW LEVEL SECURITY;
ALTER TABLE twilio_config DISABLE ROW LEVEL SECURITY;

-- Grant all permissions
GRANT ALL ON shipped_boxes TO authenticated;
GRANT ALL ON shipped_boxes TO anon;
GRANT ALL ON twilio_config TO authenticated;
GRANT ALL ON twilio_config TO anon;

-- Verify the price column exists and is not null
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'price'
  ) THEN
    RAISE EXCEPTION 'Price column is missing!';
  END IF;
  
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'price' 
    AND is_nullable = 'YES'
  ) THEN
    RAISE EXCEPTION 'Price column must not be nullable!';
  END IF;
END $$;