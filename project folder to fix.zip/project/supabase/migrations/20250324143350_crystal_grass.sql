/*
  # Add webhook URL to Twilio config

  1. Changes
    - Add webhook_url column to twilio_config table
    - Set default webhook URL for existing configs
    - Add validation constraint

  2. Details
    - Store webhook URL for status callbacks
    - Ensure URL is valid
*/

-- Add webhook_url column
ALTER TABLE twilio_config
ADD COLUMN IF NOT EXISTS webhook_url text 
DEFAULT 'https://wdahgclackfaifkhrell.supabase.co/functions/v1/twilio-webhook';

-- Add URL validation constraint
ALTER TABLE twilio_config
ADD CONSTRAINT twilio_config_webhook_url_check
CHECK (webhook_url ~ '^https?://[^\s/$.?#].[^\s]*$');