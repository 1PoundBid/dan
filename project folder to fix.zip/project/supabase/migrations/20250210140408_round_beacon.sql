-- Insert test box orders
INSERT INTO box_orders (
  customer_name,
  email,
  phone,
  box_type,
  price,
  status,
  created_at
) VALUES
  (
    'John Smith',
    'john.smith@example.com',
    '+12345678901',
    'small',
    3.99,
    'new',
    now() - interval '2 days'
  ),
  (
    'Jane Doe',
    'jane.doe@example.com',
    '+15551234567',
    'medium',
    7.99,
    'processing',
    now() - interval '1 day'
  ),
  (
    'Bob Wilson',
    'bob.wilson@example.com',
    '+19876543210',
    'big',
    9.99,
    'shipped',
    now()
  );