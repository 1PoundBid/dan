/*
  # Make phone field optional for box orders

  1. Changes
    - Make phone field optional in box_orders table
    - Remove phone validation constraint
    - Keep RLS disabled for now
  
  2. Details
    - Allows empty or null phone numbers
    - Maintains other validations
*/

-- First drop the existing table
DROP TABLE IF EXISTS box_orders CASCADE;

-- Recreate the table with phone field optional
CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
  phone text NULL,
  box_type text CHECK (box_type IN ('small', 'medium', 'big')) NOT NULL,
  price decimal NOT NULL CHECK (price > 0),
  status text CHECK (status IN ('new', 'processing', 'shipped')) DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Keep RLS disabled
ALTER TABLE box_orders DISABLE ROW LEVEL SECURITY;

-- Grant full permissions
GRANT ALL ON box_orders TO authenticated;
GRANT ALL ON box_orders TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;