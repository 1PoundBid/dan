/*
  # Add bag type support to shipped_boxes table

  1. Changes
    - Add bag_type column for different bag sizes
    - Add in_cage flag for tracking bag location
    - Update type constraints to handle both boxes and bags
  
  2. Details
    - bag_type can be 'standard', 'large', or null
    - in_cage boolean flag defaults to false
    - Update type check to ensure valid combinations
*/

-- Add bag_type and in_cage columns
ALTER TABLE shipped_boxes 
ADD COLUMN IF NOT EXISTS bag_type text CHECK (bag_type IN ('standard', 'large', null)),
ADD COLUMN IF NOT EXISTS in_cage boolean DEFAULT false;

-- Update the type check constraint to include bag indicator
ALTER TABLE shipped_boxes 
DROP CONSTRAINT IF EXISTS shipped_boxes_type_check;

ALTER TABLE shipped_boxes 
ADD CONSTRAINT shipped_boxes_type_check 
CHECK (
  (type IN ('single', 'small', 'big') AND bag_type IS NULL) OR
  (type = 'bag' AND bag_type IN ('standard', 'large'))
);