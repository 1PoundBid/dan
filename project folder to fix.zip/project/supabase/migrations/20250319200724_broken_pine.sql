/*
  # Fix Shipped Boxes Relationships

  1. Changes
    - Drop and recreate shipped_boxes and shipped_box_items tables
    - Set up proper foreign key relationships
    - Add necessary indexes
    - Maintain existing data structure

  2. Details
    - Ensure proper cascade behavior
    - Add performance optimizing indexes
    - Keep existing column constraints
*/

-- First create backup tables
CREATE TABLE IF NOT EXISTS shipped_boxes_backup AS 
SELECT * FROM shipped_boxes;

CREATE TABLE IF NOT EXISTS shipped_box_items_backup AS 
SELECT * FROM shipped_box_items;

-- Drop existing tables
DROP TABLE IF EXISTS shipped_box_items CASCADE;
DROP TABLE IF EXISTS shipped_boxes CASCADE;

-- Recreate shipped_boxes table
CREATE TABLE shipped_boxes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL,
  weight decimal NOT NULL,
  price decimal NOT NULL DEFAULT 0,
  bag_type text,
  in_cage boolean DEFAULT false,
  archived boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_type_check CHECK (
    (type IN ('single', 'small', 'big') AND bag_type IS NULL) OR
    (type = 'bag' AND bag_type IN ('standard', 'large'))
  )
);

-- Create shipped_box_items table with proper relationships
CREATE TABLE shipped_box_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  box_id uuid REFERENCES shipped_boxes(id) ON DELETE CASCADE NOT NULL,
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(box_id, order_id)
);

-- Create indexes for better query performance
CREATE INDEX idx_shipped_boxes_customer_id ON shipped_boxes(customer_id);
CREATE INDEX idx_shipped_boxes_archived ON shipped_boxes(archived);
CREATE INDEX idx_shipped_boxes_created_at ON shipped_boxes(created_at DESC);
CREATE INDEX idx_shipped_box_items_box_id ON shipped_box_items(box_id);
CREATE INDEX idx_shipped_box_items_order_id ON shipped_box_items(order_id);

-- Restore data from backup tables
INSERT INTO shipped_boxes (
  id,
  customer_id,
  type,
  weight,
  price,
  bag_type,
  in_cage,
  archived,
  created_at
)
SELECT 
  id,
  customer_id,
  type,
  weight,
  COALESCE(price, 
    CASE
      WHEN type = 'single' THEN 3.99
      WHEN type = 'small' THEN 7.99
      WHEN type = 'big' THEN 9.99
      ELSE 0
    END
  ),
  bag_type,
  COALESCE(in_cage, false),
  COALESCE(archived, false),
  created_at
FROM shipped_boxes_backup;

INSERT INTO shipped_box_items (
  id,
  box_id,
  order_id,
  created_at
)
SELECT 
  id,
  box_id,
  order_id,
  created_at
FROM shipped_box_items_backup;

-- Drop backup tables
DROP TABLE shipped_boxes_backup;
DROP TABLE shipped_box_items_backup;

-- Verify the tables and relationships exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.tables 
    WHERE table_name = 'shipped_boxes'
  ) THEN
    RAISE EXCEPTION 'shipped_boxes table does not exist!';
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.tables 
    WHERE table_name = 'shipped_box_items'
  ) THEN
    RAISE EXCEPTION 'shipped_box_items table does not exist!';
  END IF;

  -- Verify foreign key relationships
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.table_constraints tc
    JOIN information_schema.constraint_column_usage ccu 
    ON tc.constraint_name = ccu.constraint_name
    WHERE tc.table_name = 'shipped_box_items' 
    AND tc.constraint_type = 'FOREIGN KEY'
    AND ccu.table_name = 'shipped_boxes'
  ) THEN
    RAISE EXCEPTION 'Foreign key relationship between shipped_box_items and shipped_boxes is missing!';
  END IF;
END $$;