/*
  # Fix box orders and customer inquiries setup

  1. Changes
    - Drop and recreate policies with proper names
    - Ensure proper permissions for both anon and authenticated users
    - Add missing grants

  2. Security
    - Maintain RLS protection
    - Allow anonymous users to submit orders and inquiries
    - Allow authenticated users full access
*/

-- First clean up any existing policies
DO $$ 
BEGIN
    -- Drop box_orders policies
    DROP POLICY IF EXISTS "anon_insert" ON box_orders;
    DROP POLICY IF EXISTS "public_select" ON box_orders;
    DROP POLICY IF EXISTS "auth_all" ON box_orders;
    DROP POLICY IF EXISTS "Enable insert for anon" ON box_orders;
    DROP POLICY IF EXISTS "Enable read for all" ON box_orders;
    DROP POLICY IF EXISTS "Enable write for authenticated" ON box_orders;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON box_orders;

    -- Drop customer_inquiries policies
    DROP POLICY IF EXISTS "Enable insert for anon" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable read for all" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable write for authenticated" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON customer_inquiries;
END $$;

-- Recreate box_orders policies
CREATE POLICY "box_orders_anon_insert" ON box_orders
    FOR INSERT TO anon
    WITH CHECK (true);

CREATE POLICY "box_orders_public_select" ON box_orders
    FOR SELECT TO authenticated, anon
    USING (true);

CREATE POLICY "box_orders_auth_all" ON box_orders
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

-- Recreate customer_inquiries policies
CREATE POLICY "inquiries_anon_insert" ON customer_inquiries
    FOR INSERT TO anon
    WITH CHECK (true);

CREATE POLICY "inquiries_public_select" ON customer_inquiries
    FOR SELECT TO authenticated, anon
    USING (true);

CREATE POLICY "inquiries_auth_all" ON customer_inquiries
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

-- Ensure proper grants
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;

-- Box orders permissions
GRANT SELECT, INSERT ON box_orders TO anon;
GRANT ALL ON box_orders TO authenticated;

-- Customer inquiries permissions  
GRANT SELECT, INSERT ON customer_inquiries TO anon;
GRANT ALL ON customer_inquiries TO authenticated;