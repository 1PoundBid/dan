/*
  # Add initial authenticated user

  1. Changes
    - Add user account to auth.users table
    - Set up initial password
    - Enable email authentication
  
  2. Security
    - Password is hashed
    - Email confirmation disabled
*/

-- Create the user account
INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at,
  confirmation_token,
  email_change_token_current,
  email_change,
  last_sign_in_at
)
VALUES (
  '00000000-0000-0000-0000-000000000000'::uuid,
  gen_random_uuid(),
  'authenticated',
  'authenticated',
  'neilsen4tools@hotmail.co.uk',
  crypt('Dg9803555', gen_salt('bf')),
  now(),
  now(),
  now(),
  '',
  '',
  '',
  NULL
);