/*
  # Fix Shipped Boxes Schema

  1. Changes
    - Add bag_type and in_cage columns
    - Update type check constraint
    - Add performance indexes
    - Maintain existing data

  2. Details
    - Support both boxes and bags
    - Track bag location
    - Optimize queries
*/

-- Add bag_type and in_cage columns
ALTER TABLE shipped_boxes 
ADD COLUMN IF NOT EXISTS bag_type text CHECK (bag_type IN ('standard', 'large', null)),
ADD COLUMN IF NOT EXISTS in_cage boolean DEFAULT false;

-- Update the type check constraint
ALTER TABLE shipped_boxes 
DROP CONSTRAINT IF EXISTS valid_type_check;

ALTER TABLE shipped_boxes 
ADD CONSTRAINT valid_type_check 
CHECK (
  (type IN ('single', 'small', 'big') AND bag_type IS NULL) OR
  (type = 'bag' AND bag_type IN ('standard', 'large'))
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_shipped_boxes_bag_type 
ON shipped_boxes(bag_type) 
WHERE bag_type IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_shipped_boxes_in_cage 
ON shipped_boxes(in_cage) 
WHERE in_cage = true;