/*
  # Add Twilio configuration table

  1. New Tables
    - `twilio_config`
      - `id` (uuid, primary key)
      - `account_sid` (text)
      - `auth_token` (text)
      - `phone_number` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Disable RLS to match other tables
*/

-- Create twilio_config table
CREATE TABLE IF NOT EXISTS twilio_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_sid text NOT NULL,
  auth_token text NOT NULL,
  phone_number text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Disable RLS
ALTER TABLE twilio_config DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON twilio_config TO authenticated;
GRANT ALL ON twilio_config TO anon;