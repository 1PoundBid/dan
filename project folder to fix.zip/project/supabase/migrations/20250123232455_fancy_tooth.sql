/*
  # Fix database permissions and policies

  1. Changes
    - Drop all existing policies
    - Create new unified policies for all tables
    - Grant proper permissions to both authenticated and anon roles
    - Enable RLS on all tables
  
  2. Security
    - Enables RLS on all tables
    - Creates unified policies for authenticated and anon access
    - Grants proper permissions to both roles
*/

-- First, enable RLS on all tables
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_boxes ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies to start fresh
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "enable_all_access" ON customers;
    DROP POLICY IF EXISTS "enable_all_access" ON orders;
    DROP POLICY IF EXISTS "enable_all_access" ON storage_items;
    DROP POLICY IF EXISTS "enable_all_access" ON shipped_boxes;
END $$;

-- Create new unified policies
CREATE POLICY "unified_access_policy" ON customers
    FOR ALL
    TO authenticated, anon
    USING (true)
    WITH CHECK (true);

CREATE POLICY "unified_access_policy" ON orders
    FOR ALL
    TO authenticated, anon
    USING (true)
    WITH CHECK (true);

CREATE POLICY "unified_access_policy" ON storage_items
    FOR ALL
    TO authenticated, anon
    USING (true)
    WITH CHECK (true);

CREATE POLICY "unified_access_policy" ON shipped_boxes
    FOR ALL
    TO authenticated, anon
    USING (true)
    WITH CHECK (true);

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO anon;

-- Grant full access to authenticated role
GRANT ALL ON customers TO authenticated;
GRANT ALL ON orders TO authenticated;
GRANT ALL ON storage_items TO authenticated;
GRANT ALL ON shipped_boxes TO authenticated;

-- Grant read and insert access to anon role
GRANT SELECT, INSERT ON customers TO anon;
GRANT SELECT, INSERT ON orders TO anon;
GRANT SELECT, INSERT ON storage_items TO anon;
GRANT SELECT, INSERT ON shipped_boxes TO anon;

-- Reset session settings
ALTER ROLE authenticated SET search_path TO public;
ALTER ROLE anon SET search_path TO public;