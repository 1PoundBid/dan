/*
  # Add price column to shipped_boxes table

  1. Changes
    - Add price column to shipped_boxes table
    - Set default prices for existing boxes
    - Make price column required for future entries

  2. Details
    - Price is stored as decimal
    - Not null constraint
    - Default prices based on box type
*/

-- Add price column
ALTER TABLE shipped_boxes
ADD COLUMN IF NOT EXISTS price decimal;

-- Set default prices for existing boxes
UPDATE shipped_boxes
SET price = CASE
  WHEN type = 'single' THEN 3.99
  WHEN type = 'small' THEN 7.99
  WHEN type = 'big' THEN 9.99
  ELSE 0
END
WHERE price IS NULL;

-- Make price column required
ALTER TABLE shipped_boxes
ALTER COLUMN price SET NOT NULL;