/*
  # Fix RLS policies for all tables

  1. Changes
    - Drop and recreate RLS policies for all tables
    - Ensure consistent RLS setup across the database
    - Enable full access for authenticated users

  2. Security
    - Enable RLS on all tables
    - Grant full CRUD access to authenticated users
    - Maintain data integrity with proper references
*/

-- Ensure RLS is enabled on all tables
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_boxes ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies to ensure clean slate
DO $$ 
BEGIN
    -- Drop customers policies
    IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'customers') THEN
        DROP POLICY IF EXISTS "Allow full access to customers" ON customers;
        DROP POLICY IF EXISTS "Allow read access to customers" ON customers;
        DROP POLICY IF EXISTS "Allow insert access to customers" ON customers;
        DROP POLICY IF EXISTS "Allow update access to customers" ON customers;
    END IF;

    -- Drop orders policies
    IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'orders') THEN
        DROP POLICY IF EXISTS "Allow full access to orders" ON orders;
        DROP POLICY IF EXISTS "Allow read access to orders" ON orders;
        DROP POLICY IF EXISTS "Allow delete access to orders" ON orders;
    END IF;

    -- Drop storage_items policies
    IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'storage_items') THEN
        DROP POLICY IF EXISTS "Allow full access to storage_items" ON storage_items;
    END IF;

    -- Drop shipped_boxes policies
    IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'shipped_boxes') THEN
        DROP POLICY IF EXISTS "Allow full access to shipped_boxes" ON shipped_boxes;
    END IF;
END $$;

-- Create new policies with consistent naming and permissions
CREATE POLICY "Enable full access for authenticated users"
    ON customers
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "Enable full access for authenticated users"
    ON orders
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "Enable full access for authenticated users"
    ON storage_items
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "Enable full access for authenticated users"
    ON shipped_boxes
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- Grant necessary permissions to authenticated users
GRANT ALL ON customers TO authenticated;
GRANT ALL ON orders TO authenticated;
GRANT ALL ON storage_items TO authenticated;
GRANT ALL ON shipped_boxes TO authenticated;