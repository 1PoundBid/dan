/*
  # Fix deletion functionality with database function

  1. Changes
    - Add dedicated deletion function
    - Reset policies to basic version
    - Grant necessary permissions

  2. Security
    - Maintain RLS protection
    - Ensure proper access control
*/

-- Create a function to handle deletions
CREATE OR REPLACE FUNCTION delete_customer_inquiry(inquiry_id uuid)
RETURNS boolean AS $$
DECLARE
  success boolean;
BEGIN
  DELETE FROM customer_inquiries WHERE id = inquiry_id;
  GET DIAGNOSTICS success = ROW_COUNT;
  RETURN success > 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Reset policies to basic version
DROP POLICY IF EXISTS "enable_all_access" ON customer_inquiries;
DROP POLICY IF EXISTS "enable_insert_only" ON customer_inquiries;

-- Create basic policies
CREATE POLICY "basic_access" ON customer_inquiries
  FOR ALL 
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Grant function execution permission
GRANT EXECUTE ON FUNCTION delete_customer_inquiry TO authenticated;