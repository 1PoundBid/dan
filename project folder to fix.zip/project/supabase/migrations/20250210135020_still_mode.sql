/*
  # Verify box orders setup

  1. Changes
    - Verify table structure
    - Reset and recreate policies
    - Ensure proper permissions

  2. Security
    - Maintain existing security model
    - Ensure proper access for both anon and authenticated users
*/

-- First verify the table exists and has the correct structure
DO $$ 
BEGIN
    -- Drop all existing policies first
    DROP POLICY IF EXISTS "Enable insert for anon" ON box_orders;
    DROP POLICY IF EXISTS "Enable read for all" ON box_orders;
    DROP POLICY IF EXISTS "Enable write for authenticated" ON box_orders;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON box_orders;
END $$;

-- Recreate policies with simpler names
CREATE POLICY "anon_insert" ON box_orders
    FOR INSERT TO anon
    WITH CHECK (true);

CREATE POLICY "public_select" ON box_orders
    FOR SELECT TO authenticated, anon
    USING (true);

CREATE POLICY "auth_all" ON box_orders
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

-- Ensure proper grants
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;

GRANT SELECT, INSERT ON box_orders TO anon;
GRANT ALL ON box_orders TO authenticated;