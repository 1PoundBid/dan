/*
  # Add SMS Replies Table and Webhook URL

  1. Changes
    - Create sms_replies table if it doesn't exist
    - Add webhook_url to twilio_config if needed
    - Set up proper indexes and permissions

  2. Details
    - Store both sent and received messages
    - Track read status
    - Enable webhook for receiving replies
*/

-- Create sms_replies table if it doesn't exist
CREATE TABLE IF NOT EXISTS sms_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_number text NOT NULL,
  to_number text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now(),
  read boolean DEFAULT false
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_sms_replies_created_at ON sms_replies(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sms_replies_from_number ON sms_replies(from_number);
CREATE INDEX IF NOT EXISTS idx_sms_replies_read ON sms_replies(read) WHERE NOT read;

-- Add webhook_url to twilio_config if it doesn't exist
DO $$ 
BEGIN
  -- Add the column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'twilio_config' 
    AND column_name = 'webhook_url'
  ) THEN
    ALTER TABLE twilio_config
    ADD COLUMN webhook_url text 
    DEFAULT 'https://wdahgclackfaifkhrell.supabase.co/functions/v1/twilio-webhook';
  END IF;

  -- Add the constraint if it doesn't exist
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.constraint_column_usage
    WHERE constraint_name = 'twilio_config_webhook_url_check'
  ) THEN
    ALTER TABLE twilio_config
    ADD CONSTRAINT twilio_config_webhook_url_check
    CHECK (webhook_url ~ '^https?://[^\s/$.?#].[^\s]*$');
  END IF;
END $$;

-- Disable RLS for sms_replies
ALTER TABLE sms_replies DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON sms_replies TO authenticated;
GRANT ALL ON sms_replies TO anon;