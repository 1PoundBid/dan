/*
  # Remove phone column from box_orders table

  1. Changes
    - Remove phone column from box_orders table
    - Keep all other columns and constraints intact

  2. Details
    - Simple ALTER TABLE to drop the phone column
    - No data migration needed since phone is not used
*/

-- Drop the phone column from box_orders
ALTER TABLE box_orders DROP COLUMN IF EXISTS phone;