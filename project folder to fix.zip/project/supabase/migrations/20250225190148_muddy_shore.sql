/*
  # Fix Twilio Config Table

  1. Changes
    - Drop and recreate twilio_config table
    - Ensure proper structure and constraints
    - Grant necessary permissions
    - Disable RLS

  2. Details
    - Complete table recreation to avoid any state issues
    - Proper permission setup
    - Verification steps included
*/

-- First drop the table if it exists
DROP TABLE IF EXISTS twilio_config CASCADE;

-- Create the table with proper structure
CREATE TABLE twilio_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_sid text NOT NULL,
  auth_token text NOT NULL,
  phone_number text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create index for better query performance
CREATE INDEX idx_twilio_config_created_at ON twilio_config(created_at DESC);

-- Create updated_at trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION update_twilio_config_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger
DROP TRIGGER IF EXISTS update_twilio_config_updated_at ON twilio_config;
CREATE TRIGGER update_twilio_config_updated_at
  BEFORE UPDATE ON twilio_config
  FOR EACH ROW
  EXECUTE FUNCTION update_twilio_config_updated_at();

-- Disable RLS
ALTER TABLE twilio_config DISABLE ROW LEVEL SECURITY;

-- Grant all permissions
GRANT ALL ON twilio_config TO authenticated;
GRANT ALL ON twilio_config TO anon;

-- Verify table exists and has correct structure
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.tables 
    WHERE table_name = 'twilio_config'
  ) THEN
    RAISE EXCEPTION 'twilio_config table does not exist!';
  END IF;

  -- Verify required columns exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'twilio_config' 
    AND column_name IN ('account_sid', 'auth_token', 'phone_number')
  ) THEN
    RAISE EXCEPTION 'Required columns are missing!';
  END IF;
END $$;