/*
  # Add bag_type column to shipped_boxes table

  1. Changes
    - Add bag_type column to shipped_boxes table
    - Add check constraint for valid values
    - Create index for performance

  2. Details
    - Column is nullable
    - Valid values are 'standard', 'large', or null
    - Partial index for non-null values
*/

-- Add bag_type column with check constraint
ALTER TABLE shipped_boxes 
ADD COLUMN IF NOT EXISTS bag_type text CHECK (bag_type IN ('standard', 'large', null));

-- Create index for bag_type queries
CREATE INDEX IF NOT EXISTS idx_shipped_boxes_bag_type 
ON shipped_boxes(bag_type) 
WHERE bag_type IS NOT NULL;