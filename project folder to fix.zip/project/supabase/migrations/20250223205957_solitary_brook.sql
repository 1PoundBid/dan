/*
  # Remove all validation constraints from box_orders

  1. Changes
    - Drop and recreate box_orders table without any validation constraints
    - Make phone field completely optional
    - Keep RLS disabled
    - Grant all permissions
  
  2. Details
    - Removes all CHECK constraints
    - Allows NULL or empty phone numbers
    - Maintains basic table structure
*/

-- Drop the existing table
DROP TABLE IF EXISTS box_orders CASCADE;

-- Recreate table with absolute minimum constraints
CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  phone text,
  box_type text NOT NULL,
  price decimal NOT NULL,
  status text DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Keep RLS disabled
ALTER TABLE box_orders DISABLE ROW LEVEL SECURITY;

-- Grant all permissions
GRANT ALL ON box_orders TO authenticated;
GRANT ALL ON box_orders TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;