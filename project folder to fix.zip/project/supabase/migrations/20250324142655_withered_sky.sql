-- Add phone column to customers table
ALTER TABLE customers 
ADD COLUMN IF NOT EXISTS phone text;

-- Create sms_replies table
CREATE TABLE IF NOT EXISTS sms_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_number text NOT NULL,
  to_number text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now(),
  read boolean DEFAULT false
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_sms_replies_created_at ON sms_replies(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sms_replies_from_number ON sms_replies(from_number);
CREATE INDEX IF NOT EXISTS idx_sms_replies_read ON sms_replies(read) WHERE NOT read;

-- Disable RLS
ALTER TABLE sms_replies DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON sms_replies TO authenticated;
GRANT ALL ON sms_replies TO anon;

-- Update existing customers with default phone numbers
UPDATE customers 
SET phone = '+' || 
  (
    FLOOR(RANDOM() * 9 + 1)::text || 
    FLOOR(RANDOM() * 10)::text || 
    FLOOR(RANDOM() * 10)::text || 
    FLOOR(RANDOM() * 10)::text || 
    FLOOR(RANDOM() * 10)::text || 
    FLOOR(RANDOM() * 10)::text || 
    FLOOR(RANDOM() * 10)::text || 
    FLOOR(RANDOM() * 10)::text || 
    FLOOR(RANDOM() * 10)::text || 
    FLOOR(RANDOM() * 10)::text
  )
WHERE phone IS NULL;