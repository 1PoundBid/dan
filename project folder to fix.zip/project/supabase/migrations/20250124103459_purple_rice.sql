/*
  # Fix Shipped Boxes Schema

  1. Changes
    - Modify shipped_boxes table to properly link with orders
    - Add junction table for box-order relationships
    - Update RLS policies

  2. Details
    - Remove items array from shipped_boxes
    - Create shipped_box_items junction table
    - Add proper foreign key constraints
*/

-- First, create a new junction table for box-order relationships
CREATE TABLE IF NOT EXISTS shipped_box_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  box_id uuid REFERENCES shipped_boxes(id) ON DELETE CASCADE,
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(box_id, order_id)
);

-- Enable RLS on the new table
ALTER TABLE shipped_box_items ENABLE ROW LEVEL SECURITY;

-- Create policy for the junction table
CREATE POLICY "Enable full access for authenticated users"
  ON shipped_box_items
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Grant permissions
GRANT ALL ON shipped_box_items TO authenticated;
GRANT ALL ON shipped_box_items TO anon;

-- Remove the items array from shipped_boxes
ALTER TABLE shipped_boxes DROP COLUMN IF EXISTS items;