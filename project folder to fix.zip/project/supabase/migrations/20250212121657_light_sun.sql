/*
  # Enable customer deletion cascade

  1. Changes
    - Add ON DELETE CASCADE to foreign key constraints
    - Ensure proper cleanup of related records
  
  2. Security
    - Maintain existing RLS policies
    - Add explicit delete permissions
*/

-- Add cascade delete to orders
ALTER TABLE orders
DROP CONSTRAINT IF EXISTS orders_customer_id_fkey,
ADD CONSTRAINT orders_customer_id_fkey
    FOREIGN KEY (customer_id)
    REFERENCES customers(id)
    ON DELETE CASCADE;

-- Add cascade delete to storage_items  
ALTER TABLE storage_items
DROP CONSTRAINT IF EXISTS storage_items_customer_id_fkey,
ADD CONSTRAINT storage_items_customer_id_fkey
    FOREIGN KEY (customer_id)
    REFERENCES customers(id)
    ON DELETE CASCADE;

-- Add cascade delete to shipped_boxes
ALTER TABLE shipped_boxes
DROP CONSTRAINT IF EXISTS shipped_boxes_customer_id_fkey,
ADD CONSTRAINT shipped_boxes_customer_id_fkey
    FOREIGN KEY (customer_id)
    REFERENCES customers(id)
    ON DELETE CASCADE;