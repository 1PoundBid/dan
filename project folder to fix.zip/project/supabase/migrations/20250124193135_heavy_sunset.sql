/*
  # Clear test data from database

  1. Changes
    - Safely remove all test data from tables
    - Preserve table structure and relationships
    - Keep RLS policies and permissions intact

  2. Details
    - Clear data from all tables in correct order
    - Handle foreign key constraints properly
*/

-- Clear data from tables in reverse order of dependencies
TRUNCATE TABLE shipped_box_items CASCADE;
TRUNCATE TABLE shipped_boxes CASCADE;
TRUNCATE TABLE storage_items CASCADE;
TRUNCATE TABLE orders CASCADE;
TRUNCATE TABLE customers CASCADE;