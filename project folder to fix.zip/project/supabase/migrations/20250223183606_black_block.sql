/*
  # Fix deletion functionality with trigger

  1. Changes
    - Add trigger to handle deletions properly
    - Reset policies to simpler version
    - Add explicit delete function
    - Grant necessary permissions

  2. Security
    - Maintain RLS protection
    - Ensure proper access control
*/

-- First, drop existing policies
DROP POLICY IF EXISTS "allow_delete_for_authenticated" ON customer_inquiries;
DROP POLICY IF EXISTS "allow_select_for_all" ON customer_inquiries;
DROP POLICY IF EXISTS "allow_insert_for_anon" ON customer_inquiries;

-- Create a function to handle deletions
CREATE OR REPLACE FUNCTION handle_customer_inquiry_delete()
RETURNS TRIGGER AS $$
BEGIN
  -- Log deletion attempt
  RAISE NOTICE 'Attempting to delete inquiry with ID: %', OLD.id;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for deletion
DROP TRIGGER IF EXISTS tr_customer_inquiry_delete ON customer_inquiries;
CREATE TRIGGER tr_customer_inquiry_delete
  BEFORE DELETE ON customer_inquiries
  FOR EACH ROW
  EXECUTE FUNCTION handle_customer_inquiry_delete();

-- Create simpler policies
CREATE POLICY "enable_all_access" ON customer_inquiries
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "enable_insert_only" ON customer_inquiries
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Reset permissions
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON customer_inquiries TO authenticated;
GRANT INSERT ON customer_inquiries TO anon;

-- Ensure sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;