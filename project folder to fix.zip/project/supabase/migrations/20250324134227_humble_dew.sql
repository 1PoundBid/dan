/*
  # Add SMS Templates Table

  1. New Tables
    - `sms_templates`
      - `id` (uuid, primary key)
      - `name` (text)
      - `content` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Disable RLS to match other tables
    - Grant necessary permissions
*/

-- Create sms_templates table
CREATE TABLE IF NOT EXISTS sms_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_sms_templates_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger
CREATE TRIGGER update_sms_templates_updated_at
  BEFORE UPDATE ON sms_templates
  FOR EACH ROW
  EXECUTE FUNCTION update_sms_templates_updated_at();

-- Create indexes
CREATE INDEX idx_sms_templates_created_at ON sms_templates(created_at DESC);

-- Disable RLS
ALTER TABLE sms_templates DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON sms_templates TO authenticated;
GRANT ALL ON sms_templates TO anon;

-- Insert some default templates
INSERT INTO sms_templates (name, content) VALUES
  ('Order Ready', 'Hi, your order is ready for collection. Please visit us during opening hours to collect your items.'),
  ('Box Ready', 'Your box has been packed and is ready for delivery. We will contact you with tracking details soon.'),
  ('Payment Received', 'Thank you for your payment. Your items will be processed shortly.'),
  ('Collection Reminder', 'Friendly reminder: You have items waiting for collection. Please collect them at your earliest convenience.');