/*
  # Fix Shipped Boxes Schema

  1. Changes
    - Drop and recreate shipped_boxes table with correct structure
    - Preserve existing data
    - Set up proper constraints and relationships
    - Add performance optimizing indexes

  2. Details
    - Ensure all required columns exist
    - Support both boxes and bags
    - Maintain data integrity
    - Optimize query performance
*/

-- First backup existing data
CREATE TEMP TABLE IF NOT EXISTS temp_shipped_boxes AS 
SELECT * FROM shipped_boxes;

-- Drop existing tables to ensure clean slate
DROP TABLE IF EXISTS shipped_box_items CASCADE;
DROP TABLE IF EXISTS shipped_boxes CASCADE;

-- Recreate shipped_boxes table with complete structure
CREATE TABLE shipped_boxes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL,
  weight decimal NOT NULL CHECK (weight > 0),
  price decimal NOT NULL DEFAULT 0,
  bag_type text CHECK (bag_type IN ('standard', 'large', null)),
  in_cage boolean DEFAULT false,
  archived boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_type_check CHECK (
    (type IN ('single', 'small', 'big') AND bag_type IS NULL) OR
    (type = 'bag' AND bag_type IN ('standard', 'large'))
  )
);

-- Create shipped_box_items junction table
CREATE TABLE shipped_box_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  box_id uuid REFERENCES shipped_boxes(id) ON DELETE CASCADE NOT NULL,
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(box_id, order_id)
);

-- Create indexes for better performance
CREATE INDEX idx_shipped_boxes_customer_id ON shipped_boxes(customer_id);
CREATE INDEX idx_shipped_boxes_archived ON shipped_boxes(archived);
CREATE INDEX idx_shipped_boxes_created_at ON shipped_boxes(created_at DESC);
CREATE INDEX idx_shipped_boxes_bag_type ON shipped_boxes(bag_type) WHERE bag_type IS NOT NULL;
CREATE INDEX idx_shipped_boxes_in_cage ON shipped_boxes(in_cage) WHERE in_cage = true;
CREATE INDEX idx_shipped_box_items_box_id ON shipped_box_items(box_id);
CREATE INDEX idx_shipped_box_items_order_id ON shipped_box_items(order_id);

-- Restore data from backup
INSERT INTO shipped_boxes (
  id,
  customer_id,
  type,
  weight,
  price,
  archived,
  created_at
)
SELECT
  id,
  customer_id,
  type,
  weight,
  CASE
    WHEN type = 'single' THEN 3.99
    WHEN type = 'small' THEN 7.99
    WHEN type = 'big' THEN 9.99
    ELSE 0
  END as price,
  COALESCE(archived, false),
  created_at
FROM temp_shipped_boxes;

-- Restore shipped_box_items relationships if they exist
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'temp_shipped_boxes'
    AND column_name = 'items'
  ) THEN
    INSERT INTO shipped_box_items (box_id, order_id)
    SELECT 
      sb.id as box_id,
      unnest(sb.items)::uuid as order_id
    FROM temp_shipped_boxes sb
    WHERE sb.items IS NOT NULL;
  END IF;
END $$;

-- Drop backup table
DROP TABLE temp_shipped_boxes;