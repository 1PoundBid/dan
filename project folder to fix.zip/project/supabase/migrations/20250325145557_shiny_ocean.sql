/*
  # Fix Shipped Boxes Schema

  1. Changes
    - Add bag_type and in_cage columns
    - Update type check constraint
    - Add performance optimizing indexes
    - Maintain existing data

  2. Details
    - Support both boxes and bags
    - Track bag location with in_cage flag
    - Optimize queries with indexes
*/

-- First backup existing data
CREATE TEMP TABLE IF NOT EXISTS temp_shipped_boxes AS 
SELECT * FROM shipped_boxes;

-- Drop and recreate table with correct structure
DROP TABLE IF EXISTS shipped_boxes CASCADE;

CREATE TABLE shipped_boxes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL,
  weight decimal NOT NULL CHECK (weight > 0),
  price decimal NOT NULL DEFAULT 0,
  bag_type text CHECK (bag_type IN ('standard', 'large', null)),
  in_cage boolean DEFAULT false,
  archived boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_type_check CHECK (
    (type IN ('single', 'small', 'big') AND bag_type IS NULL) OR
    (type = 'bag' AND bag_type IN ('standard', 'large'))
  )
);

-- Create indexes for better performance
CREATE INDEX idx_shipped_boxes_customer_id ON shipped_boxes(customer_id);
CREATE INDEX idx_shipped_boxes_archived ON shipped_boxes(archived);
CREATE INDEX idx_shipped_boxes_created_at ON shipped_boxes(created_at DESC);
CREATE INDEX idx_shipped_boxes_bag_type ON shipped_boxes(bag_type) WHERE bag_type IS NOT NULL;
CREATE INDEX idx_shipped_boxes_in_cage ON shipped_boxes(in_cage) WHERE in_cage = true;

-- Restore data from backup
INSERT INTO shipped_boxes (
  id,
  customer_id,
  type,
  weight,
  price,
  archived,
  created_at
)
SELECT
  id,
  customer_id,
  type,
  weight,
  CASE
    WHEN type = 'single' THEN 3.99
    WHEN type = 'small' THEN 7.99
    WHEN type = 'big' THEN 9.99
    ELSE 0
  END as price,
  COALESCE(archived, false),
  created_at
FROM temp_shipped_boxes;

-- Drop backup table
DROP TABLE temp_shipped_boxes;