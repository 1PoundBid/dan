-- Add archived column with default value
ALTER TABLE shipped_boxes 
ADD COLUMN IF NOT EXISTS archived boolean NOT NULL DEFAULT false;