/*
  # Add Box Orders and Customer Inquiries Tables

  1. New Tables
    - `box_orders`
      - `id` (uuid, primary key)
      - `customer_name` (text)
      - `email` (text)
      - `phone` (text)
      - `box_type` (text)
      - `price` (decimal)
      - `status` (text)
      - `created_at` (timestamp)

    - `customer_inquiries`
      - `id` (uuid, primary key)
      - `customer_name` (text)
      - `email` (text)
      - `phone` (text)
      - `question` (text)
      - `priority` (text)
      - `status` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create box_orders table
CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  box_type text CHECK (box_type IN ('small', 'medium', 'big')) NOT NULL,
  price decimal NOT NULL,
  status text CHECK (status IN ('new', 'processing', 'shipped')) DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

-- Create customer_inquiries table
CREATE TABLE IF NOT EXISTS customer_inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  question text NOT NULL,
  priority text CHECK (priority IN ('low', 'medium', 'high')) DEFAULT 'low',
  status text CHECK (status IN ('new', 'in_progress', 'answered')) DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE box_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_inquiries ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable full access for authenticated users"
  ON box_orders
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable full access for authenticated users"
  ON customer_inquiries
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Grant permissions
GRANT ALL ON box_orders TO authenticated;
GRANT ALL ON customer_inquiries TO authenticated;