/*
  # Final Box Orders Permissions Fix

  1. Changes
    - Drop and recreate box_orders table
    - Disable RLS completely
    - Grant full permissions to all roles
    - Add necessary sequence permissions

  2. Security
    - No RLS restrictions
    - Full access for all operations
*/

-- First drop the existing table
DROP TABLE IF EXISTS box_orders CASCADE;

-- Recreate the table with minimal constraints
CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  phone text DEFAULT '',
  box_type text CHECK (box_type IN ('small', 'medium', 'big')) NOT NULL,
  price decimal NOT NULL CHECK (price > 0),
  status text CHECK (status IN ('new', 'processing', 'shipped')) DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Disable RLS completely
ALTER TABLE box_orders DISABLE ROW LEVEL SECURITY;

-- Grant full permissions to both roles
GRANT ALL ON box_orders TO authenticated;
GRANT ALL ON box_orders TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO anon;