/*
  # Remove RLS from box_orders table

  1. Changes
    - Disable RLS on box_orders table
    - Grant all permissions to both authenticated and anonymous users
    - Remove all existing policies

  2. Security
    - Allow unrestricted access to box_orders table
    - Maintain basic permission grants
*/

-- First drop all existing policies
DROP POLICY IF EXISTS "allow_all_operations" ON box_orders;
DROP POLICY IF EXISTS "box_orders_anon_insert" ON box_orders;
DROP POLICY IF EXISTS "box_orders_public_select" ON box_orders;
DROP POLICY IF EXISTS "box_orders_auth_all" ON box_orders;

-- Disable RLS completely
ALTER TABLE box_orders DISABLE ROW LEVEL SECURITY;

-- Ensure proper permissions are still granted
GRANT ALL ON box_orders TO authenticated;
GRANT ALL ON box_orders TO anon;