/*
  # Final RLS permissions fix

  1. Changes
    - Reset and properly configure RLS for all tables
    - Ensure proper sequence of operations
    - Grant all necessary permissions
    - Set up policies correctly

  2. Security
    - Enable RLS on all tables
    - Create permissive policies for authenticated users
    - Grant necessary table permissions
*/

-- First, enable RLS on all tables
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_boxes ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies to start fresh
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "authenticated_full_access" ON customers;
    DROP POLICY IF EXISTS "authenticated_full_access" ON orders;
    DROP POLICY IF EXISTS "authenticated_full_access" ON storage_items;
    DROP POLICY IF EXISTS "authenticated_full_access" ON shipped_boxes;
    DROP POLICY IF EXISTS "customers_full_access" ON customers;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON customers;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON orders;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON storage_items;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON shipped_boxes;
END $$;

-- Grant schema usage first
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO anon;

-- Create policies with proper security context
CREATE POLICY "enable_all_access" ON customers FOR ALL TO authenticated, anon USING (true) WITH CHECK (true);
CREATE POLICY "enable_all_access" ON orders FOR ALL TO authenticated, anon USING (true) WITH CHECK (true);
CREATE POLICY "enable_all_access" ON storage_items FOR ALL TO authenticated, anon USING (true) WITH CHECK (true);
CREATE POLICY "enable_all_access" ON shipped_boxes FOR ALL TO authenticated, anon USING (true) WITH CHECK (true);

-- Grant table permissions
GRANT ALL ON customers TO authenticated;
GRANT ALL ON orders TO authenticated;
GRANT ALL ON storage_items TO authenticated;
GRANT ALL ON shipped_boxes TO authenticated;

-- Grant read access to anon role
GRANT SELECT ON customers TO anon;
GRANT SELECT ON orders TO anon;
GRANT SELECT ON storage_items TO anon;
GRANT SELECT ON shipped_boxes TO anon;

-- Grant insert access to anon role (needed for sign-up flow)
GRANT INSERT ON customers TO anon;
GRANT INSERT ON orders TO anon;
GRANT INSERT ON storage_items TO anon;
GRANT INSERT ON shipped_boxes TO anon;