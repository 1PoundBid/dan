/*
  # Fix box orders and inquiries policies

  1. Changes
    - Add policies for anonymous users to insert data
    - Grant insert permissions to anonymous users
    - Add policies for public read access

  2. Security
    - Anonymous users can only insert
    - Authenticated users have full access
    - Everyone can read
*/

-- Drop existing policies
DO $$ 
BEGIN
    IF EXISTS (
        SELECT 1 
        FROM pg_policies 
        WHERE schemaname = 'public' 
        AND tablename = 'box_orders'
    ) THEN
        DROP POLICY IF EXISTS "Enable full access for authenticated users" ON box_orders;
    END IF;

    IF EXISTS (
        SELECT 1 
        FROM pg_policies 
        WHERE schemaname = 'public' 
        AND tablename = 'customer_inquiries'
    ) THEN
        DROP POLICY IF EXISTS "Enable full access for authenticated users" ON customer_inquiries;
    END IF;
END $$;

-- Create new policies for box_orders
CREATE POLICY "Enable insert for anon"
    ON box_orders
    FOR INSERT
    TO anon
    WITH CHECK (true);

CREATE POLICY "Enable read for all"
    ON box_orders
    FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "Enable write for authenticated"
    ON box_orders
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- Create new policies for customer_inquiries
CREATE POLICY "Enable insert for anon"
    ON customer_inquiries
    FOR INSERT
    TO anon
    WITH CHECK (true);

CREATE POLICY "Enable read for all"
    ON customer_inquiries
    FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "Enable write for authenticated"
    ON customer_inquiries
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- Grant necessary permissions to anon role
GRANT INSERT ON box_orders TO anon;
GRANT INSERT ON customer_inquiries TO anon;
GRANT SELECT ON box_orders TO anon;
GRANT SELECT ON customer_inquiries TO anon;