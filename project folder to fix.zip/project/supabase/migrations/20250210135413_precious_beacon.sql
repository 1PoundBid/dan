/*
  # Fix box orders and customer inquiries setup

  1. Changes
    - Drop and recreate tables with proper constraints
    - Set up proper RLS policies
    - Grant correct permissions to roles
    - Add indexes for better performance

  2. Security
    - Maintain RLS protection
    - Allow anonymous users to submit orders and inquiries
    - Allow authenticated users full access
*/

-- Drop existing tables and recreate them
DROP TABLE IF EXISTS box_orders CASCADE;
DROP TABLE IF EXISTS customer_inquiries CASCADE;

-- Recreate box_orders table
CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  box_type text CHECK (box_type IN ('small', 'medium', 'big')) NOT NULL,
  price decimal NOT NULL,
  status text CHECK (status IN ('new', 'processing', 'shipped')) DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Recreate customer_inquiries table
CREATE TABLE IF NOT EXISTS customer_inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  question text NOT NULL,
  priority text CHECK (priority IN ('low', 'medium', 'high')) DEFAULT 'low',
  status text CHECK (status IN ('new', 'in_progress', 'answered')) DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS box_orders_created_at_idx ON box_orders(created_at DESC);
CREATE INDEX IF NOT EXISTS box_orders_status_idx ON box_orders(status);
CREATE INDEX IF NOT EXISTS customer_inquiries_created_at_idx ON customer_inquiries(created_at DESC);
CREATE INDEX IF NOT EXISTS customer_inquiries_status_idx ON customer_inquiries(status);

-- Enable RLS
ALTER TABLE box_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_inquiries ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "box_orders_anon_insert" ON box_orders;
    DROP POLICY IF EXISTS "box_orders_public_select" ON box_orders;
    DROP POLICY IF EXISTS "box_orders_auth_all" ON box_orders;
    DROP POLICY IF EXISTS "inquiries_anon_insert" ON customer_inquiries;
    DROP POLICY IF EXISTS "inquiries_public_select" ON customer_inquiries;
    DROP POLICY IF EXISTS "inquiries_auth_all" ON customer_inquiries;
END $$;

-- Create box_orders policies
CREATE POLICY "box_orders_anon_insert" ON box_orders
    FOR INSERT TO anon
    WITH CHECK (true);

CREATE POLICY "box_orders_public_select" ON box_orders
    FOR SELECT TO authenticated, anon
    USING (true);

CREATE POLICY "box_orders_auth_all" ON box_orders
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

-- Create customer_inquiries policies
CREATE POLICY "inquiries_anon_insert" ON customer_inquiries
    FOR INSERT TO anon
    WITH CHECK (true);

CREATE POLICY "inquiries_public_select" ON customer_inquiries
    FOR SELECT TO authenticated, anon
    USING (true);

CREATE POLICY "inquiries_auth_all" ON customer_inquiries
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;

-- Grant table permissions
GRANT SELECT, INSERT ON box_orders TO anon;
GRANT ALL ON box_orders TO authenticated;
GRANT SELECT, INSERT ON customer_inquiries TO anon;
GRANT ALL ON customer_inquiries TO authenticated;