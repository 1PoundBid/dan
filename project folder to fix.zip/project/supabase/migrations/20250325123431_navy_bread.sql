/*
  # Restore SMS Templates and Box Tracking Features

  1. Changes
    - Create sms_templates table
    - Add phone column to customers
    - Set up proper triggers and indexes
    - Insert default templates

  2. Details
    - Ensure clean table creation
    - Add necessary constraints
    - Include default SMS templates
*/

-- First drop existing objects to ensure clean state
DROP TRIGGER IF EXISTS update_sms_templates_updated_at ON sms_templates;
DROP FUNCTION IF EXISTS update_sms_templates_updated_at();
DROP TABLE IF EXISTS sms_templates;

-- Create sms_templates table
CREATE TABLE IF NOT EXISTS sms_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_sms_templates_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger
CREATE TRIGGER update_sms_templates_updated_at
  BEFORE UPDATE ON sms_templates
  FOR EACH ROW
  EXECUTE FUNCTION update_sms_templates_updated_at();

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_sms_templates_created_at ON sms_templates(created_at DESC);

-- Disable RLS
ALTER TABLE sms_templates DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON sms_templates TO authenticated;
GRANT ALL ON sms_templates TO anon;

-- Add phone column to customers table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'customers' 
    AND column_name = 'phone'
  ) THEN
    ALTER TABLE customers ADD COLUMN phone text;
  END IF;
END $$;

-- Insert default templates
INSERT INTO sms_templates (name, content) VALUES
  ('1PoundBid Large Box Ready For Delivery', '1PoundBid Large Box Ready For Delivery Hi You Have A Box Full Ready For Delivery Please Go Onto Your Account And Buy The Right Size Box. You Will Find This Under The Tab Called (Postage Buy Here) Once Postage Is Paid You Box Will Automatically Get Booked Out With Parcelforce. Many Thanks From The 1PoundBid Team (We Will Only Send Out Boxes That Have Been Paid For First)'),
  ('1PoundBid Medium Box Ready For Delivery', '1PoundBid Medium Box Ready For Delivery Hi You Have A Box Full Ready For Delivery Please Go Onto Your Account And Buy The Right Size Box. You Will Find This Under The Tab Called (Postage Buy Here) Once Postage Is Paid You Box Will Automatically Get Booked Out With Parcelforce. Many Thanks From The 1PoundBid Team (We Will Only Send Out Boxes That Have Been Paid For First)'),
  ('1PoundBid Single Item Ready For Delivery', '1PoundBid Single Item Ready For Delivery Hi You Have A Box Full Ready For Delivery Please Go Onto Your Account And Buy The Right Size Box. You Will Find This Under The Tab Called (Postage Buy Here) Once Postage Is Paid You Box Will Automatically Get Booked Out With Parcelforce. Many Thanks From The 1PoundBid Team (We Will Only Send Out Boxes That Have Been Paid For First)'),
  ('Box Ready', 'Your box has been packed and is ready for delivery. We will contact you with tracking details soon.')
ON CONFLICT DO NOTHING;