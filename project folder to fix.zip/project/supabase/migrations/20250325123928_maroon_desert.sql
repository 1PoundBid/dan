/*
  # Fix Shipped Boxes Schema

  1. Changes
    - Add bag_type and in_cage columns to shipped_boxes
    - Update type constraints
    - Add proper indexes
  
  2. Details
    - Support both box and bag types
    - Track bag location with in_cage flag
    - Optimize queries with indexes
*/

-- Add required columns
ALTER TABLE shipped_boxes 
ADD COLUMN IF NOT EXISTS bag_type text,
ADD COLUMN IF NOT EXISTS in_cage boolean DEFAULT false;

-- Update type constraint
ALTER TABLE shipped_boxes 
DROP CONSTRAINT IF EXISTS valid_type_check;

ALTER TABLE shipped_boxes 
ADD CONSTRAINT valid_type_check 
CHECK (
  (type IN ('single', 'small', 'big') AND bag_type IS NULL) OR
  (type = 'bag' AND bag_type IN ('standard', 'large'))
);

-- Add index for bag_type queries
CREATE INDEX IF NOT EXISTS idx_shipped_boxes_bag_type 
ON shipped_boxes(bag_type) 
WHERE bag_type IS NOT NULL;