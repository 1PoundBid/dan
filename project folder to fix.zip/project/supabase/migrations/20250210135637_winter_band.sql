/*
  # Fix box orders table and policies

  1. Changes
    - Drop and recreate box_orders table with correct structure
    - Set up proper RLS policies
    - Grant correct permissions to roles
    - Add updated_at trigger

  2. Security
    - Enable RLS
    - Allow anonymous inserts
    - Allow public reads
    - Allow authenticated users full access
*/

-- First drop existing table and recreate
DROP TABLE IF EXISTS box_orders CASCADE;

CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  box_type text CHECK (box_type IN ('small', 'medium', 'big')) NOT NULL,
  price decimal NOT NULL,
  status text CHECK (status IN ('new', 'processing', 'shipped')) DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_box_orders_updated_at
  BEFORE UPDATE ON box_orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes
CREATE INDEX IF NOT EXISTS box_orders_created_at_idx ON box_orders(created_at DESC);
CREATE INDEX IF NOT EXISTS box_orders_status_idx ON box_orders(status);

-- Enable RLS
ALTER TABLE box_orders ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "box_orders_anon_insert" ON box_orders;
DROP POLICY IF EXISTS "box_orders_public_select" ON box_orders;
DROP POLICY IF EXISTS "box_orders_auth_all" ON box_orders;

-- Create new policies
CREATE POLICY "box_orders_anon_insert" ON box_orders
    FOR INSERT TO anon
    WITH CHECK (true);

CREATE POLICY "box_orders_public_select" ON box_orders
    FOR SELECT TO authenticated, anon
    USING (true);

CREATE POLICY "box_orders_auth_all" ON box_orders
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

-- Grant permissions
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;

GRANT SELECT, INSERT ON box_orders TO anon;
GRANT ALL ON box_orders TO authenticated;