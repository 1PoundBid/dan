/*
  # Fix phone column removal from box_orders table

  1. Changes
    - Drop the table and recreate without phone column
    - Keep all other columns and constraints intact
    - Ensure proper permissions

  2. Details
    - Complete table recreation to ensure clean state
    - Maintain all other functionality
*/

-- Drop and recreate the table without the phone column
DROP TABLE IF EXISTS box_orders CASCADE;

CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  box_type text NOT NULL,
  price decimal NOT NULL,
  status text DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Keep RLS disabled
ALTER TABLE box_orders DISABLE ROW LEVEL SECURITY;

-- Grant all permissions
GRANT ALL ON box_orders TO authenticated;
GRANT ALL ON box_orders TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;