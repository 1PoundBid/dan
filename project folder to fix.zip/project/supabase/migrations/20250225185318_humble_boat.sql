/*
  # Verify Database Changes

  1. Changes
    - Verify price column exists on shipped_boxes
    - Verify twilio_config table exists
    - Re-run price defaults if needed
    - Ensure proper permissions

  2. Details
    - Double check all required columns and tables
    - Set default prices for any missing values
    - Grant necessary permissions
*/

-- Verify price column exists and set defaults if needed
DO $$ 
BEGIN
  -- First verify the column exists
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'price'
  ) THEN
    -- Add the column if it doesn't exist
    ALTER TABLE shipped_boxes
    ADD COLUMN price decimal;
  END IF;

  -- Set default prices for any NULL values
  UPDATE shipped_boxes
  SET price = CASE
    WHEN type = 'single' THEN 3.99
    WHEN type = 'small' THEN 7.99
    WHEN type = 'big' THEN 9.99
    ELSE 0
  END
  WHERE price IS NULL;

  -- Make sure the column is NOT NULL
  ALTER TABLE shipped_boxes
  ALTER COLUMN price SET NOT NULL;
END $$;

-- Verify twilio_config table exists
CREATE TABLE IF NOT EXISTS twilio_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_sid text NOT NULL,
  auth_token text NOT NULL,
  phone_number text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Ensure RLS is disabled for twilio_config
ALTER TABLE twilio_config DISABLE ROW LEVEL SECURITY;

-- Ensure proper permissions
GRANT ALL ON twilio_config TO authenticated;
GRANT ALL ON twilio_config TO anon;

-- Verify trigger exists
CREATE OR REPLACE FUNCTION update_twilio_config_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Recreate trigger
DROP TRIGGER IF EXISTS update_twilio_config_updated_at ON twilio_config;
CREATE TRIGGER update_twilio_config_updated_at
  BEFORE UPDATE ON twilio_config
  FOR EACH ROW
  EXECUTE FUNCTION update_twilio_config_updated_at();