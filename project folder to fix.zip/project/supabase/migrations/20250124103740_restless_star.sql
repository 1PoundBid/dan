/*
  # Fix Shipped Boxes Schema

  1. Changes
    - Create junction table for box-order relationships
    - Add proper foreign key constraints
    - Update RLS policies

  2. Details
    - Create shipped_box_items table to link boxes with orders
    - Enable RLS and set up policies
    - Grant necessary permissions
*/

-- Create junction table for box-order relationships
CREATE TABLE IF NOT EXISTS shipped_box_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  box_id uuid REFERENCES shipped_boxes(id) ON DELETE CASCADE,
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(box_id, order_id)
);

-- Enable RLS
ALTER TABLE shipped_box_items ENABLE ROW LEVEL SECURITY;

-- Create policy for full access
CREATE POLICY "enable_all_access"
  ON shipped_box_items
  FOR ALL
  TO authenticated, anon
  USING (true)
  WITH CHECK (true);

-- Grant permissions
GRANT ALL ON shipped_box_items TO authenticated;
GRANT ALL ON shipped_box_items TO anon;

-- Remove items array from shipped_boxes if it exists
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'items'
  ) THEN
    ALTER TABLE shipped_boxes DROP COLUMN items;
  END IF;
END $$;