/*
  # Add SMS Templates and Customer Phone Column

  1. Changes
    - Create sms_templates table
    - Add phone column to customers table
    - Add default templates
    - Add necessary indexes

  2. Details
    - Store SMS template messages
    - Track customer phone numbers
    - Maintain proper constraints
*/

-- Create sms_templates table
CREATE TABLE IF NOT EXISTS sms_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Drop existing trigger and function if they exist
DROP TRIGGER IF EXISTS update_sms_templates_updated_at ON sms_templates;
DROP FUNCTION IF EXISTS update_sms_templates_updated_at();

-- Create updated_at trigger function
CREATE FUNCTION update_sms_templates_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger
CREATE TRIGGER update_sms_templates_updated_at
  BEFORE UPDATE ON sms_templates
  FOR EACH ROW
  EXECUTE FUNCTION update_sms_templates_updated_at();

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_sms_templates_created_at ON sms_templates(created_at DESC);

-- Disable RLS
ALTER TABLE sms_templates DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON sms_templates TO authenticated;
GRANT ALL ON sms_templates TO anon;

-- Add phone column to customers table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'customers' 
    AND column_name = 'phone'
  ) THEN
    ALTER TABLE customers ADD COLUMN phone text;
  END IF;
END $$;

-- Insert default templates
INSERT INTO sms_templates (name, content) VALUES
  ('Order Ready', 'Hi, your order is ready for collection. Please visit us during opening hours to collect your items.'),
  ('Box Ready', 'Your box has been packed and is ready for delivery. We will contact you with tracking details soon.'),
  ('Payment Received', 'Thank you for your payment. Your items will be processed shortly.'),
  ('Collection Reminder', 'Friendly reminder: You have items waiting for collection. Please collect them at your earliest convenience.')
ON CONFLICT DO NOTHING;