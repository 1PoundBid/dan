/*
  # Update Orders table RLS policies

  1. Changes
    - Drop existing RLS policies for orders table
    - Add new policy allowing full access for authenticated users

  2. Security
    - Enable full CRUD operations for authenticated users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Allow read access to orders" ON orders;
DROP POLICY IF EXISTS "Allow delete access to orders" ON orders;

-- Create new policy for full access
CREATE POLICY "Allow full access to orders"
  ON orders
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);