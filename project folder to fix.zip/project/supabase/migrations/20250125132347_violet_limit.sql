/*
  # Add archived column to shipped_boxes table

  1. Changes
    - Add archived boolean column to shipped_boxes table
    - Set default value to false
    - Add not null constraint
    - Backfill existing rows

  2. Details
    - All existing boxes will be marked as not archived
    - New boxes will default to not archived
*/

-- Add archived column with default value
ALTER TABLE shipped_boxes 
ADD COLUMN IF NOT EXISTS archived boolean NOT NULL DEFAULT false;