/*
  # Update Customers table RLS policies

  1. Changes
    - Drop and recreate RLS policies for customers table if they don't exist
    - Ensure full access for authenticated users

  2. Security
    - Enable full CRUD operations for authenticated users
*/

DO $$ 
BEGIN
    -- Drop the policy if it exists (will not error if it doesn't)
    IF EXISTS (
        SELECT 1 
        FROM pg_policies 
        WHERE schemaname = 'public' 
        AND tablename = 'customers' 
        AND policyname = 'Allow full access to customers'
    ) THEN
        DROP POLICY "Allow full access to customers" ON customers;
    END IF;

    -- Create the policy
    CREATE POLICY "Allow full access to customers"
        ON customers
        FOR ALL
        TO authenticated
        USING (true)
        WITH CHECK (true);
END $$;