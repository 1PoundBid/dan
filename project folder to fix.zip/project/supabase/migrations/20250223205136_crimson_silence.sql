/*
  # Final Permissions Fix

  1. Changes
    - Disable RLS on all tables
    - Grant full permissions to all roles
    - Reset all restrictions
*/

-- Disable RLS on all tables
ALTER TABLE customers DISABLE ROW LEVEL SECURITY;
ALTER TABLE orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE storage_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_boxes DISABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_box_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE box_orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE customer_inquiries DISABLE ROW LEVEL SECURITY;

-- Reset and grant all permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon;
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL ROUTINES IN SCHEMA public TO anon;
GRANT ALL ON ALL ROUTINES IN SCHEMA public TO authenticated;

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO anon;