/*
  # Final fix for box_orders table structure

  1. Changes
    - Drop and recreate table without phone column
    - Ensure minimal required columns only
    - Keep all permissions intact
*/

-- Drop and recreate table with absolute minimum structure
DROP TABLE IF EXISTS box_orders CASCADE;

CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  box_type text NOT NULL,
  price decimal NOT NULL,
  status text DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Keep RLS disabled
ALTER TABLE box_orders DISABLE ROW LEVEL SECURITY;

-- Grant all permissions
GRANT ALL ON box_orders TO authenticated;
GRANT ALL ON box_orders TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;

-- Verify phone column is not present
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'box_orders' 
    AND column_name = 'phone'
  ) THEN
    RAISE EXCEPTION 'Phone column still exists!';
  END IF;
END $$;