/*
  # Fix customer inquiries delete permissions

  1. Changes
    - Drop existing policies
    - Create new explicit policies for delete operations
    - Grant proper permissions to authenticated users

  2. Security
    - Maintain RLS protection
    - Allow authenticated users to delete inquiries
*/

-- Drop existing policies for customer_inquiries
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable insert for anon" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable read for all" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable write for authenticated" ON customer_inquiries;
END $$;

-- Create new policies with explicit delete permissions
CREATE POLICY "allow_delete_for_authenticated"
    ON customer_inquiries
    FOR DELETE
    TO authenticated
    USING (true);

CREATE POLICY "allow_select_for_all"
    ON customer_inquiries
    FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "allow_insert_for_anon"
    ON customer_inquiries
    FOR INSERT
    TO anon
    WITH CHECK (true);

-- Ensure proper grants
GRANT DELETE ON customer_inquiries TO authenticated;