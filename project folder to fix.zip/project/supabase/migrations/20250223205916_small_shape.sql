/*
  # Make phone field optional for box orders

  1. Changes
    - Make phone field optional in box_orders table
    - Remove all validation constraints
    - Keep RLS disabled
  
  2. Details
    - Allows empty or null phone numbers
    - Maintains other basic constraints
*/

-- First drop the existing table
DROP TABLE IF EXISTS box_orders CASCADE;

-- Recreate the table with minimal constraints
CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  phone text,
  box_type text CHECK (box_type IN ('small', 'medium', 'big')) NOT NULL,
  price decimal NOT NULL CHECK (price > 0),
  status text CHECK (status IN ('new', 'processing', 'shipped')) DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Keep RLS disabled
ALTER TABLE box_orders DISABLE ROW LEVEL SECURITY;

-- Grant full permissions
GRANT ALL ON box_orders TO authenticated;
GRANT ALL ON box_orders TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;