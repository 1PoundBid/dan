/*
  # Fix RLS permissions for all tables

  1. Changes
    - Reset and properly configure RLS for all tables
    - Grant appropriate permissions to authenticated users
    - Ensure consistent policy naming and behavior

  2. Security
    - Enable RLS on all tables
    - Create permissive policies for authenticated users
    - Grant necessary table permissions
*/

-- Enable RLS on all tables
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_boxes ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies to ensure clean slate
DO $$ 
BEGIN
    -- Drop existing policies if they exist
    DROP POLICY IF EXISTS "customers_full_access" ON customers;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON customers;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON orders;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON storage_items;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON shipped_boxes;
END $$;

-- Create new policies with consistent naming and full permissions
CREATE POLICY "authenticated_full_access"
    ON customers
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_full_access"
    ON orders
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_full_access"
    ON storage_items
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_full_access"
    ON shipped_boxes
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON customers TO authenticated;
GRANT ALL ON orders TO authenticated;
GRANT ALL ON storage_items TO authenticated;
GRANT ALL ON shipped_boxes TO authenticated;