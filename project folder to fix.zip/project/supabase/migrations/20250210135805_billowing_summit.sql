/*
  # Final fix for box orders table and policies

  1. Changes
    - Drop and recreate box_orders table with proper structure
    - Add updated_at trigger
    - Create proper indexes
    - Set up RLS policies correctly
    - Grant proper permissions

  2. Security
    - Enable RLS
    - Allow anonymous inserts for public form submissions
    - Allow public reads
    - Allow authenticated users full access
*/

-- First drop existing table and recreate with proper structure
DROP TABLE IF EXISTS box_orders CASCADE;

CREATE TABLE IF NOT EXISTS box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
  phone text NOT NULL,
  box_type text CHECK (box_type IN ('small', 'medium', 'big')) NOT NULL,
  price decimal NOT NULL CHECK (price > 0),
  status text CHECK (status IN ('new', 'processing', 'shipped')) DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create updated_at trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger
DROP TRIGGER IF EXISTS update_box_orders_updated_at ON box_orders;
CREATE TRIGGER update_box_orders_updated_at
  BEFORE UPDATE ON box_orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS box_orders_created_at_idx ON box_orders(created_at DESC);
CREATE INDEX IF NOT EXISTS box_orders_status_idx ON box_orders(status);
CREATE INDEX IF NOT EXISTS box_orders_email_idx ON box_orders(email);

-- Enable RLS
ALTER TABLE box_orders ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to ensure clean slate
DROP POLICY IF EXISTS "box_orders_anon_insert" ON box_orders;
DROP POLICY IF EXISTS "box_orders_public_select" ON box_orders;
DROP POLICY IF EXISTS "box_orders_auth_all" ON box_orders;

-- Create new policies with proper security context
CREATE POLICY "box_orders_anon_insert" ON box_orders
    FOR INSERT TO anon
    WITH CHECK (
      -- Validate required fields
      customer_name IS NOT NULL AND
      email IS NOT NULL AND
      phone IS NOT NULL AND
      box_type IS NOT NULL AND
      price IS NOT NULL AND
      -- Only allow setting status to 'new' for anon users
      (status IS NULL OR status = 'new')
    );

CREATE POLICY "box_orders_public_select" ON box_orders
    FOR SELECT TO authenticated, anon
    USING (true);

CREATE POLICY "box_orders_auth_all" ON box_orders
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

-- Grant proper permissions
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;

GRANT SELECT, INSERT ON box_orders TO anon;
GRANT ALL ON box_orders TO authenticated;