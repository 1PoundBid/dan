/*
  # Create items and scanning tables

  1. New Tables
    - `items`
      - `id` (uuid, primary key)
      - `barcode` (text, unique)
      - `name` (text)
      - `customer_id` (uuid, foreign key)
      - `status` (enum: pending, in_tray, in_box, shipped)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `tracking_number` (text, nullable)

  2. Security
    - Enable RLS on `items` table
    - Add policies for authenticated users to read and update items
*/

-- Create enum for item status
CREATE TYPE item_status AS ENUM ('pending', 'in_tray', 'in_box', 'shipped');

-- Create items table
CREATE TABLE IF NOT EXISTS items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  barcode text UNIQUE NOT NULL,
  name text NOT NULL,
  customer_id uuid REFERENCES auth.users(id),
  status item_status DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  tracking_number text
);

-- Enable RLS
ALTER TABLE items ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow read access to items"
  ON items
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow update access to items"
  ON items
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_items_updated_at
  BEFORE UPDATE ON items
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();