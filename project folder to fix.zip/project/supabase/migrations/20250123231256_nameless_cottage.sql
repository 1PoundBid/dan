/*
  # Add storage tracking and shipping features

  1. New Tables
    - `storage_items`: Track bags in cage and boxes on shelf
      - `id` (uuid, primary key)
      - `customer_id` (uuid, references customers)
      - `type` (text, either 'bag_cage' or 'box_shelf')
      - `created_at` (timestamptz)
    
    - `shipped_boxes`: Track processed boxes
      - `id` (uuid, primary key)
      - `customer_id` (uuid, references customers)
      - `type` (text, either 'single', 'small', or 'big')
      - `weight` (decimal)
      - `items` (text[], list of order IDs)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on new tables
    - Update RLS policies on customers table
    - Add policies for authenticated users to manage storage items and shipped boxes
*/

-- Create storage_items table
CREATE TABLE IF NOT EXISTS storage_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  type text CHECK (type IN ('bag_cage', 'box_shelf')),
  created_at timestamptz DEFAULT now()
);

-- Create shipped_boxes table
CREATE TABLE IF NOT EXISTS shipped_boxes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  type text CHECK (type IN ('single', 'small', 'big')),
  weight decimal NOT NULL,
  items text[] NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE storage_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_boxes ENABLE ROW LEVEL SECURITY;

-- Update customers RLS policy
DROP POLICY IF EXISTS "Allow read access to customers" ON customers;
DROP POLICY IF EXISTS "Allow insert access to customers" ON customers;
DROP POLICY IF EXISTS "Allow update access to customers" ON customers;

CREATE POLICY "Allow full access to customers" ON customers
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for storage_items
CREATE POLICY "Allow full access to storage_items"
  ON storage_items
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for shipped_boxes
CREATE POLICY "Allow full access to shipped_boxes"
  ON shipped_boxes
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);