/*
  # Add Bag Collections Support

  1. Changes
    - Add bag_type to shipped_boxes table
    - Update type check constraint to include bag collection types
    - Add in_cage boolean flag for bags

  2. Details
    - Allows tracking of bagged items separately from boxed items
    - Supports automatic cage tracking
*/

-- Add bag_type and in_cage columns
ALTER TABLE shipped_boxes 
ADD COLUMN IF NOT EXISTS bag_type text CHECK (bag_type IN ('standard', 'large', null)),
ADD COLUMN IF NOT EXISTS in_cage boolean DEFAULT false;

-- Update the type check constraint to include bag indicator
ALTER TABLE shipped_boxes 
DROP CONSTRAINT IF EXISTS shipped_boxes_type_check;

ALTER TABLE shipped_boxes 
ADD CONSTRAINT shipped_boxes_type_check 
CHECK (
  (type IN ('single', 'small', 'big') AND bag_type IS NULL) OR
  (type = 'bag' AND bag_type IN ('standard', 'large'))
);