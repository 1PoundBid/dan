-- Enable pg_trgm extension for text search
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Create validation functions
CREATE OR REPLACE FUNCTION is_valid_phone(phone text)
RETURNS boolean AS $$
BEGIN
  -- Allow formats: +1234567890, 123-456-7890, (123) 456-7890
  RETURN phone ~ '^\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

CREATE OR REPLACE FUNCTION is_valid_email(email text)
RETURNS boolean AS $$
BEGIN
  RETURN email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Add validation constraints
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'box_orders_email_check'
  ) THEN
    ALTER TABLE box_orders 
    ADD CONSTRAINT box_orders_email_check 
    CHECK (is_valid_email(email));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'box_orders_phone_check'
  ) THEN
    ALTER TABLE box_orders 
    ADD CONSTRAINT box_orders_phone_check 
    CHECK (is_valid_phone(phone));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'box_orders_price_check'
  ) THEN
    ALTER TABLE box_orders 
    ADD CONSTRAINT box_orders_price_check 
    CHECK (price > 0);
  END IF;
END $$;

-- Add missing indexes
CREATE INDEX IF NOT EXISTS box_orders_status_created_at_idx 
ON box_orders(status, created_at DESC);

CREATE INDEX IF NOT EXISTS box_orders_customer_name_trgm_idx 
ON box_orders USING gin(customer_name gin_trgm_ops);

CREATE INDEX IF NOT EXISTS box_orders_email_idx 
ON box_orders(email);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger
DROP TRIGGER IF EXISTS set_box_orders_updated_at ON box_orders;
CREATE TRIGGER set_box_orders_updated_at
  BEFORE UPDATE ON box_orders
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();

-- Drop existing policies
DROP POLICY IF EXISTS "box_orders_anon_insert" ON box_orders;
DROP POLICY IF EXISTS "box_orders_public_select" ON box_orders;
DROP POLICY IF EXISTS "box_orders_auth_all" ON box_orders;

-- Create new policies
CREATE POLICY "box_orders_anon_insert" ON box_orders
  FOR INSERT TO anon
  WITH CHECK (
    customer_name IS NOT NULL AND
    email IS NOT NULL AND
    phone IS NOT NULL AND
    box_type IS NOT NULL AND
    price IS NOT NULL AND
    is_valid_email(email) AND
    is_valid_phone(phone) AND
    price > 0 AND
    (status IS NULL OR status = 'new')
  );

CREATE POLICY "box_orders_public_select" ON box_orders
  FOR SELECT TO authenticated, anon
  USING (true);

CREATE POLICY "box_orders_auth_all" ON box_orders
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);