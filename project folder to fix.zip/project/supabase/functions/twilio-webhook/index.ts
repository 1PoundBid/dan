import { serve } from 'https://deno.fresh.runtime.dev/server';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.7';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log('Received webhook request:', {
      method: req.method,
      url: req.url,
      headers: Object.fromEntries(req.headers.entries())
    });

    // Parse the request body
    const formData = await req.formData();
    const from = formData.get('From');
    const to = formData.get('To');
    const message = formData.get('Body');

    console.log('Webhook form data:', {
      from,
      to,
      message,
      allFields: Object.fromEntries(formData.entries())
    });

    if (!from || !to || !message) {
      console.error('Missing required fields:', { from, to, message });
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY');

    console.log('Supabase config:', {
      url: supabaseUrl,
      keyExists: !!supabaseKey
    });

    const supabaseClient = createClient(
      supabaseUrl ?? '',
      supabaseKey ?? ''
    );

    console.log('Storing SMS reply in database');

    // Store the SMS reply in the database
    const { data, error: insertError } = await supabaseClient
      .from('sms_replies')
      .insert({
        from_number: from,
        to_number: to,
        message: message,
        read: false
      })
      .select()
      .single();

    if (insertError) {
      console.error('Error inserting SMS reply:', {
        error: insertError,
        errorMessage: insertError.message,
        details: insertError.details,
        hint: insertError.hint
      });
      throw insertError;
    }

    console.log('SMS reply stored successfully:', data);

    // Return empty TwiML response (no auto-reply)
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response></Response>`;

    return new Response(twiml, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/xml'
      }
    });

  } catch (error) {
    console.error('Error processing webhook:', {
      error,
      message: error.message,
      stack: error.stack
    });
    
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});