# System Backup - 1PoundBid Center

This backup contains the complete state of the 1PoundBid Center system as of $(date +"%B %d, %Y").

## Directory Structure

```
backup/
├── README.md
├── src/                    # Application source code
├── supabase/              # Database migrations and configurations
├── config/                # Configuration files
└── public/                # Public assets
```

## Important Files

1. Source Code:
   - All React components
   - Database utilities
   - Type definitions
   - Utility functions

2. Database:
   - Complete migration history
   - Database schema
   - Table structures
   - RLS policies

3. Configuration:
   - Environment variables (structure only, no sensitive data)
   - Build configuration
   - TypeScript configuration
   - ESLint configuration

## Restore Instructions

1. Create a new project directory
2. Copy all files from the backup maintaining the directory structure
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```

## Database Schema

The database consists of the following tables:

1. `customers`
   - Customer information and balances
   - Bidder numbers and contact details

2. `orders`
   - Order tracking and status
   - Item details and processing information

3. `storage_items`
   - Bags in cage
   - Boxes on shelf

4. `shipped_boxes`
   - Completed shipments
   - Box types and weights

5. `shipped_box_items`
   - Junction table for box-order relationships

## Features

1. Customer Management
   - Customer profiles
   - Order history
   - Balance tracking

2. Order Processing
   - Barcode scanning
   - Tray management
   - Box packing
   - Shipping preparation

3. Storage Management
   - Bag cage tracking
   - Box shelf organization
   - Archive system

4. Real-time Updates
   - Live order status
   - Instant notifications
   - Voice feedback