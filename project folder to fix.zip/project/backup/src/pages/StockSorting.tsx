import React from 'react';
import { Box } from 'lucide-react';

export function StockSorting() {
  const categories = [
    {
      name: 'Live Auction Items',
      color: 'bg-teal-200 text-teal-800',
      trayColor: 'Turquoise',
      description: 'High turnover items that will sell quickly in live auctions'
    },
    {
      name: 'Jewellery',
      color: 'bg-orange-400 text-white',
      trayColor: 'Orange',
      description: 'Small, valuable items requiring careful handling'
    },
    {
      name: 'Wires & Cables',
      color: 'bg-red-500 text-white',
      trayColor: 'Red',
      description: 'Tech accessories, chargers, and miscellaneous wiring'
    },
    {
      name: 'Vinted Items',
      color: 'bg-gray-900 text-gray-100',
      trayColor: 'Black',
      description: 'Items suitable for resale on Vinted'
    },
    {
      name: 'Small Random Bits',
      color: 'bg-green-900 text-white',
      trayColor: 'Dark Green',
      description: 'Miscellaneous, might need further sorting or sold in bulk'
    },
    {
      name: 'Beauty Products',
      color: 'bg-blue-200 text-blue-800',
      trayColor: 'Blue',
      description: 'Cosmetics, skincare, and beauty-related items'
    },
    {
      name: 'High Priced Goods',
      color: 'bg-pink-500 text-white',
      trayColor: 'Pink',
      description: 'To be sold in the evenings for better prices'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <Box className="h-8 w-8 text-blue-500" />
          <h1 className="text-2xl font-bold text-gray-900">Stock Sorting Guide</h1>
        </div>

        <div className="prose max-w-none">
          <p className="text-lg text-gray-700 mb-6">
            Assign a specific color tray for each category to maintain organized and efficient stock management.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {categories.map((category) => (
            <div
              key={category.name}
              className="border rounded-lg overflow-hidden"
            >
              <div className={`p-4 ${category.color}`}>
                <h3 className="text-lg font-semibold">{category.name}</h3>
              </div>
              <div className="p-4 bg-white">
                <div className="mb-2">
                  <span className="font-medium">Tray Color:</span>{' '}
                  <span className="text-gray-700">{category.trayColor}</span>
                </div>
                <p className="text-gray-600">{category.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}