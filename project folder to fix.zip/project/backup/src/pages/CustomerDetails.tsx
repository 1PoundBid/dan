import React, { useRef, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Package, Mail, Scan, Box, Inbox, Trash2, Archive, Clock, AlertCircle, Scale } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { speak } from '../utils/speech';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { lookupItem, updateItemStatus, processBox, getShippedBoxes } from '../lib/supabase';
import { LoadingSpinner } from '../components/LoadingSpinner';

interface Customer {
  id: string;
  bidder_number: string;
  first_name: string;
  last_name: string;
  email: string;
  balance: number | null;
}

interface Order {
  id: string;
  item_code: string;
  item_name: string;
  status: string;
  processed_at: string | null;
  created_at: string;
}

interface StorageItem {
  id: string;
  type: 'bag_cage' | 'box_shelf';
  created_at: string;
}

interface AccountSummary {
  unprocessedOrders: number;
  bagsInCage: number;
  boxesOnShelf: number;
  itemsInTray: number;
  itemsInBox: number;
  daysSinceLastOrder: number;
}

interface ShippedBox {
  id: string;
  type: 'single' | 'small' | 'big';
  weight: number;
  created_at: string;
  items: {
    id: string;
    item_code: string;
    item_name: string;
    status: string;
    processed_at: string | null;
  }[];
}

const getStatusColor = (status: string) => {
  switch (status) {
    case 'in_tray':
      return 'bg-green-100 text-green-800';
    case 'in_box':
      return 'bg-blue-100 text-blue-800';
    case 'shipped':
      return 'bg-purple-100 text-purple-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export function CustomerDetails() {
  const { id } = useParams<{ id: string }>();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [storageItems, setStorageItems] = useState<StorageItem[]>([]);
  const [shippedBoxes, setShippedBoxes] = useState<ShippedBox[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showBoxModal, setShowBoxModal] = useState(false);
  const [boxType, setBoxType] = useState<'single' | 'small' | 'big'>('single');
  const [weight, setWeight] = useState('');
  const [accountSummary, setAccountSummary] = useState<AccountSummary>({
    unprocessedOrders: 0,
    bagsInCage: 0,
    boxesOnShelf: 0,
    itemsInTray: 0,
    itemsInBox: 0,
    daysSinceLastOrder: 0
  });

  const lookupRef = useRef<HTMLInputElement>(null);
  const trayRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLInputElement>(null);
  const ordersChannelRef = useRef<RealtimeChannel | null>(null);
  const storageChannelRef = useRef<RealtimeChannel | null>(null);

  useEffect(() => {
    if (!id) return;
    
    lookupRef.current?.focus();
    fetchCustomerData();
    setupRealtimeSubscriptions();

    return () => {
      if (ordersChannelRef.current) {
        ordersChannelRef.current.unsubscribe();
      }
      if (storageChannelRef.current) {
        storageChannelRef.current.unsubscribe();
      }
    };
  }, [id]);

  const setupRealtimeSubscriptions = () => {
    if (!id) return;

    ordersChannelRef.current = supabase
      .channel('orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
          filter: `customer_id=eq.${id}`
        },
        () => {
          fetchOrders();
        }
      )
      .subscribe();

    storageChannelRef.current = supabase
      .channel('storage-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'storage_items',
          filter: `customer_id=eq.${id}`
        },
        () => {
          fetchStorageItems();
        }
      )
      .subscribe();
  };

  const calculateAccountSummary = (orders: Order[], storageItems: StorageItem[]) => {
    const unprocessedOrders = orders.filter(order => order.status === 'unprocessed').length;
    const itemsInTray = orders.filter(order => order.status === 'in_tray').length;
    const itemsInBox = orders.filter(order => order.status === 'in_box').length;
    const bagsInCage = storageItems.filter(item => item.type === 'bag_cage').length;
    const boxesOnShelf = storageItems.filter(item => item.type === 'box_shelf').length;

    const lastOrderDate = orders.length > 0
      ? Math.max(...orders.map(order => new Date(order.created_at).getTime()))
      : null;
    const daysSinceLastOrder = lastOrderDate
      ? Math.floor((Date.now() - lastOrderDate) / (1000 * 60 * 60 * 24))
      : 0;

    setAccountSummary({
      unprocessedOrders,
      bagsInCage,
      boxesOnShelf,
      itemsInTray,
      itemsInBox,
      daysSinceLastOrder
    });
  };

  const fetchOrders = async () => {
    if (!id) return;

    try {
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*')
        .eq('customer_id', id)
        .order('created_at', { ascending: false });

      if (ordersError) throw ordersError;
      setOrders(ordersData);
      calculateAccountSummary(ordersData, storageItems);
    } catch (error) {
      console.error('Error fetching orders:', error);
      setError('Failed to fetch orders');
    }
  };

  const fetchStorageItems = async () => {
    if (!id) return;

    try {
      const { data: storageData, error: storageError } = await supabase
        .from('storage_items')
        .select('*')
        .eq('customer_id', id)
        .order('created_at', { ascending: false });

      if (storageError) throw storageError;
      setStorageItems(storageData || []);
      calculateAccountSummary(orders, storageData || []);
    } catch (error) {
      console.error('Error fetching storage items:', error);
      setError('Failed to fetch storage items');
    }
  };

  const fetchShippedBoxes = async () => {
    if (!id) return;

    try {
      const boxes = await getShippedBoxes(id);
      setShippedBoxes(boxes);
    } catch (error) {
      console.error('Error fetching shipped boxes:', error);
      setError('Failed to fetch shipped boxes');
    }
  };

  const fetchCustomerData = async () => {
    if (!id) return;

    setLoading(true);
    setError(null);
    
    try {
      const { data: customerData, error: customerError } = await supabase
        .from('customers')
        .select('*')
        .eq('id', id)
        .single();

      if (customerError) throw customerError;
      setCustomer(customerData);

      await Promise.all([
        fetchOrders(),
        fetchStorageItems(),
        fetchShippedBoxes()
      ]);
    } catch (error) {
      console.error('Error fetching customer data:', error);
      setError('Failed to fetch customer data');
    } finally {
      setLoading(false);
    }
  };

  const handleScan = async (
    ref: React.RefObject<HTMLInputElement>,
    handler: (barcode: string) => Promise<void>
  ) => {
    setError(null);
    const value = ref.current?.value || '';
    
    if (!value.trim()) {
      setError('Please scan a barcode');
      speak('Please scan a barcode');
      return;
    }

    try {
      await handler(value);
      if (ref.current) {
        ref.current.value = '';
        ref.current.focus();
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Error scanning item';
      console.error('Scan error:', err);
      speak(message);
      setError(message);
      if (ref.current) {
        ref.current.select();
      }
    }
  };

  const handleKeyPress = async (
    e: React.KeyboardEvent<HTMLInputElement>,
    ref: React.RefObject<HTMLInputElement>,
    handler: (barcode: string) => Promise<void>
  ) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      await handleScan(ref, handler);
    }
  };

  const handleLookup = async (barcode: string) => {
    const item = await lookupItem(barcode);
    const fullName = `${item.customer.first_name} ${item.customer.last_name}`;
    speak(`This item belongs to ${fullName}`);
  };

  const handleTray = async (barcode: string) => {
    const item = await updateItemStatus(barcode, 'in_tray');
    const fullName = `${item.customer.first_name} ${item.customer.last_name}`;
    speak(`Item scanned into tray for ${fullName}`);
    fetchOrders();
  };

  const handleBox = async (barcode: string) => {
    const item = await updateItemStatus(barcode, 'in_box');
    const fullName = `${item.customer.first_name} ${item.customer.last_name}`;
    speak(`Item packed into box for ${fullName}`);
    fetchOrders();
  };

  const handleAddBagToCage = async () => {
    if (!id) return;
    
    try {
      const { data, error } = await supabase
        .from('storage_items')
        .insert({
          customer_id: id,
          type: 'bag_cage',
          created_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      
      setStorageItems(prev => [data, ...prev]);
      speak('Bag has been added to the cage');
    } catch (error) {
      console.error('Error adding bag to cage:', error);
      const message = error instanceof Error ? error.message : 'Error adding bag to cage';
      setError(message);
      speak(message);
    }
  };

  const handleBoxFull = () => {
    speak('Please select a box type and enter the weight in kilograms');
    setShowBoxModal(true);
  };

  const handleBoxFullSubmit = async () => {
    if (!id) return;
    
    try {
      const boxItems = orders.filter(order => order.status === 'in_box').map(order => order.id);
      
      await processBox(id, boxType, parseFloat(weight), boxItems);

      setShowBoxModal(false);
      setWeight('');
      await Promise.all([
        fetchOrders(),
        fetchShippedBoxes()
      ]);
      speak('Box has been processed and items marked as shipped');
    } catch (error) {
      console.error('Error processing box:', error);
      const message = error instanceof Error ? error.message : 'Error processing box';
      setError(message);
      speak(message);
    }
  };

  const handleAddBoxToShelf = async () => {
    if (!id) return;
    
    try {
      const { data, error } = await supabase
        .from('storage_items')
        .insert({
          customer_id: id,
          type: 'box_shelf',
          created_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      setStorageItems(prev => [data, ...prev]);
      speak('Box has been added to the shelf');
    } catch (error) {
      console.error('Error adding box to shelf:', error);
      const message = error instanceof Error ? error.message : 'Error adding box to shelf';
      setError(message);
      speak(message);
    }
  };

  const handleDeleteStorageItem = async (itemId: string) => {
    try {
      const { error } = await supabase
        .from('storage_items')
        .delete()
        .eq('id', itemId);

      if (error) throw error;
      setStorageItems(prev => prev.filter(item => item.id !== itemId));
    } catch (error) {
      console.error('Error deleting storage item:', error);
      const message = error instanceof Error ? error.message : 'Error deleting storage item';
      setError(message);
      speak(message);
    }
  };

  const handleDeleteSelected = async () => {
    try {
      const { error } = await supabase
        .from('orders')
        .delete()
        .in('id', selectedOrders);

      if (error) throw error;
      setOrders(prev => prev.filter(order => !selectedOrders.includes(order.id)));
      setSelectedOrders([]);
    } catch (error) {
      console.error('Error deleting orders:', error);
      const message = error instanceof Error ? error.message : 'Error deleting orders';
      setError(message);
      speak(message);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!customer) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <AlertCircle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800">Customer Not Found</h2>
          <p className="text-gray-600 mt-2">The requested customer could not be found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      {/* Customer Info Card */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {customer.first_name} {customer.last_name}
            </h1>
            <div className="mt-2 space-y-2">
              <div className="text-gray-600">
                Bidder #: <span className="font-medium">{customer.bidder_number}</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Mail className="h-4 w-4 mr-2" />
                <a href={`mailto:${customer.email}`} className="hover:text-blue-600">
                  {customer.email}
                </a>
              </div>
              <div className="text-gray-600">
                Balance: <span className="font-medium">${customer.balance?.toFixed(2) ?? '0.00'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scanning Fields */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {/* Item Lookup */}
        <div className="relative">
          <div className="absolute -top-3 left-4 px-2 bg-gray-100 rounded">
            <div className="flex items-center gap-2">
              <Scan className="h-4 w-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-800">Item Lookup</span>
            </div>
          </div>
          <div className="bg-gray-100 rounded-lg p-4 pt-6">
            <input
              ref={lookupRef}
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-300 focus:border-gray-400 focus:ring-0"
              placeholder="Scan barcode..."
              onKeyPress={(e) => handleKeyPress(e, lookupRef, handleLookup)}
            />
          </div>
        </div>

        {/* Scan to Tray */}
        <div className="relative">
          <div className="absolute -top-3 left-4 px-2 bg-green-50 rounded">
            <div className="flex items-center gap-2">
              <Inbox className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium text-green-800">Scan to Tray</span>
            </div>
          </div>
          <div className="bg-green-50 rounded-lg p-4 pt-6">
            <input
              ref={trayRef}
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-green-300 focus:border-green-400 focus:ring-0"
              placeholder="Scan barcode..."
              onKeyPress={(e) => handleKeyPress(e, trayRef, handleTray)}
            />
          </div>
        </div>

        {/* Scan to Box */}
        <div className="relative">
          <div className="absolute -top-3 left-4 px-2 bg-blue-50 rounded">
            <div className="flex items-center gap-2">
              <Box className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-800">Scan to Box</span>
            </div>
          </div>
          <div className="bg-blue-50 rounded-lg p-4 pt-6">
            <input
              ref={boxRef}
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-blue-300 focus:border-blue-400 focus:ring-0"
              placeholder="Scan barcode..."
              onKeyPress={(e) => handleKeyPress(e, boxRef, handleBox)}
            />
          </div>
        </div>
      </div>

      {/* Management Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={handleAddBagToCage}
          className="px-4 py-3 bg-pink-500 text-white rounded-lg hover:bg-pink-600 font-medium"
        >
          Add Bag to Cage
        </button>
        <button
          onClick={handleBoxFull}
          className="px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 font-medium"
        >
          Box Full
        </button>
        <button
          onClick={handleAddBoxToShelf}
          className="px-4 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 font-medium"
        >
          Add Box to Shelf
        </button>
      </div>

      {/* Account Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {/* Unprocessed Orders */}
        <div className="bg-gray-100 rounded-lg p-4 flex flex-col items-center justify-center">
          <Package className="h-8 w-8 text-gray-600 mb-2" />
          <span className="text-2xl font-bold text-gray-800">{accountSummary.unprocessedOrders}</span>
          <span className="text-sm text-gray-600">Unprocessed Orders</span>
        </div>

        {/* Bags in Cage */}
        <div className="bg-pink-50 rounded-lg p-4 flex flex-col items-center justify-center">
          <Archive className="h-8 w-8 text-pink-600 mb-2" />
          <span className="text-2xl font-bold text-pink-800">{accountSummary.bagsInCage}</span>
          <span className="text-sm text-pink-600">Bags in Cage</span>
        </div>

        {/* Boxes on Shelf */}
        <div className="bg-orange-50 rounded-lg p-4 flex flex-col items-center justify-center">
          <Box className="h-8 w-8 text-orange-600 mb-2" />
          <span className="text-2xl font-bold text-orange-800">{accountSummary.boxesOnShelf}</span>
          <span className="text-sm text-orange-600">Boxes on Shelf</span>
        </div>

        {/* Items in Tray */}
        <div className="bg-green-50 rounded-lg p-4 flex flex-col items-center justify-center">
          <Inbox className="h-8 w-8 text-green-600 mb-2" />
          <span className="text-2xl font-bold text-green-800">{accountSummary.itemsInTray}</span>
          <span className="text-sm text-green-600">Items in Tray</span>
        </div>

        {/* Items in Box */}
        <div className="bg-blue-50 rounded-lg p-4 flex flex-col items-center justify-center">
          <Box className="h-8 w-8 text-blue-600 mb-2" />
          <span className="text-2xl font-bold text-blue-800">{accountSummary.itemsInBox}</span>
          <span className="text-sm text-blue-600">Items in Box</span>
        </div>

        {/* Days Since Last Order */}
        <div className="bg-purple-50 rounded-lg p-4 flex flex-col items-center justify-center">
          <Clock className="h-8 w-8 text-purple-600 mb-2" />
          <span className="text-2xl font-bold text-purple-800">
            {accountSummary.daysSinceLastOrder}
          </span>
          <span className="text-sm text-purple-600">Days Since Last Order</span>
        </div>
      </div>

      {/* Storage Items */}
      {storageItems.length > 0 && (
        <div className="space-y-2">
          {storageItems.map(item => (
            <div
              key={item.id}
              className={`flex items-center justify-between p-4 rounded-lg ${
                item.type === 'bag_cage' ? 'bg-pink-100' : 'bg-orange-100'
              }`}
            >
              <div className="flex items-center gap-4">
                <input
                  type="checkbox"
                  className="rounded border-gray-300"
                />
                <span className="font-medium">
                  {item.type === 'bag_cage' ? 'Bag added to cage' : 'Box added to shelf'}
                </span>
              </div>
              <button
                onClick={() => handleDeleteStorageItem(item.id)}
                className="text-red-600 hover:text-red-700"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Box Full Modal */}
      {showBoxModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Process Box</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Box Type
                </label>
                <select
                  value={boxType}
                  onChange={(e) => setBoxType(e.target.value as any)}
                  className="w-full rounded-lg border-gray-300"
                >
                  <option value="single">Single Item</option>
                  <option value="small">Small Box</option>
                  <option value="big">Big Box</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Weight (kg)
                </label>
                <input
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  className="w-full rounded-lg border-gray-300"
                  step="0.1"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowBoxModal(false)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  onClick={handleBoxFullSubmit}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  Submit
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Orders Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-800">Purchased Items</h2>
            {selectedOrders.length > 0 && (
              <button
                onClick={handleDeleteSelected}
                className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                <Trash2 className="h-4 w-4" />
                Delete Selected ({selectedOrders.length})
              </button>
            )}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="w-12 px-6 py-3">
                  <input
                    type="checkbox"
                    checked={selectedOrders.length === orders.length}
                    onChange={(e) => {
                      setSelectedOrders(
                        e.target.checked ? orders.map(order => order.id) : []
                      );
                    }}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Item Code
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Item Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Process Time
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="w-12 px-6 py-4">
                    <input
                      type="checkbox"
                      checked={selectedOrders.includes(order.id)}
                      onChange={(e) => {
                        setSelectedOrders(prev =>
                          e.target.checked
                            ? [...prev, order.id]
                            : prev.filter(id => id !== order.id)
                        );
                      }}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {order.item_code}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {order.item_name}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(order.status)}`}>
                      {order.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">
                      {order.processed_at
                        ? new Date(order.processed_at).toLocaleString()
                        : new Date(order.created_at).toLocaleString()}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}