import React, { useState, useEffect, useRef } from 'react';
import { Mail, Phone, Clock, AlertCircle, MessageSquare, Trash2, Send, CheckCircle2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { sendSMS } from '../lib/twilio';
import { LoadingSpinner } from '../components/LoadingSpinner';
import type { RealtimeChannel } from '@supabase/supabase-js';

interface CustomerInquiry {
  id: string;
  customer_name: string;
  email: string;
  phone: string;
  question: string;
  created_at: string;
}

interface SMSReply {
  id: string;
  from_number: string;
  message: string;
  created_at: string;
  read: boolean;
}

export function CustomerInquiries() {
  const [inquiries, setInquiries] = useState<CustomerInquiry[]>([]);
  const [smsReplies, setSMSReplies] = useState<SMSReply[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedInquiries, setSelectedInquiries] = useState<string[]>([]);
  const [smsMessage, setSmsMessage] = useState('');
  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([]);
  const [manualPhone, setManualPhone] = useState('');
  const [sendingSMS, setSendingSMS] = useState(false);
  const repliesChannelRef = useRef<RealtimeChannel | null>(null);

  useEffect(() => {
    console.log('CustomerInquiries component mounted');
    fetchInquiries();
    fetchSMSReplies();
    setupRealtimeSubscription();

    return () => {
      console.log('CustomerInquiries component unmounting');
      if (repliesChannelRef.current) {
        console.log('Unsubscribing from realtime channel');
        repliesChannelRef.current.unsubscribe();
      }
    };
  }, []);

  const setupRealtimeSubscription = () => {
    console.log('Setting up realtime subscription');
    
    repliesChannelRef.current = supabase
      .channel('sms-replies-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'sms_replies'
        },
        (payload) => {
          console.log('Received realtime update:', {
            type: payload.eventType,
            new: payload.new,
            old: payload.old
          });
          fetchSMSReplies();
        }
      )
      .subscribe((status) => {
        console.log('Subscription status:', status);
      });
  };

  const fetchInquiries = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('customer_inquiries')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setInquiries(data || []);
    } catch (err) {
      console.error('Error fetching inquiries:', err);
      setError('Failed to fetch inquiries');
    } finally {
      setLoading(false);
    }
  };

  const fetchSMSReplies = async () => {
    try {
      console.log('Fetching SMS replies');
      const { data, error: fetchError } = await supabase
        .from('sms_replies')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) {
        console.error('Error fetching SMS replies:', fetchError);
        throw fetchError;
      }
      
      console.log('Fetched SMS replies:', data);
      setSMSReplies(data || []);
    } catch (err) {
      console.error('Error in fetchSMSReplies:', err);
      setError('Failed to fetch SMS replies');
    }
  };

  const handleDeleteSelected = async () => {
    if (!selectedInquiries.length) return;

    if (!confirm(`Are you sure you want to delete ${selectedInquiries.length} selected inquir${selectedInquiries.length === 1 ? 'y' : 'ies'}?`)) {
      return;
    }

    try {
      const { error: deleteError } = await supabase
        .from('customer_inquiries')
        .delete()
        .in('id', selectedInquiries);

      if (deleteError) throw deleteError;

      setInquiries(prev => prev.filter(inquiry => !selectedInquiries.includes(inquiry.id)));
      setSelectedInquiries([]);
    } catch (err) {
      console.error('Error deleting inquiries:', err);
      setError('Failed to delete inquiries');
    }
  };

  const markReplyAsRead = async (replyId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('sms_replies')
        .update({ read: true })
        .eq('id', replyId);

      if (updateError) throw updateError;

      setSMSReplies(prev =>
        prev.map(reply =>
          reply.id === replyId ? { ...reply, read: true } : reply
        )
      );
    } catch (err) {
      console.error('Error marking reply as read:', err);
      setError('Failed to mark reply as read');
    }
  };

  const validatePhoneNumber = (phone: string) => {
    return phone.replace(/[^\d+]/g, '').length >= 10;
  };

  const handleSendSMS = async () => {
    if (!smsMessage.trim()) {
      setError('Please enter a message');
      return;
    }

    if (selectedRecipients.length === 0 && !manualPhone) {
      setError('Please select at least one recipient or enter a phone number');
      return;
    }

    if (manualPhone && !validatePhoneNumber(manualPhone)) {
      setError('Please enter a valid phone number');
      return;
    }

    setSendingSMS(true);
    setError(null);

    try {
      // Get selected inquiries with phone numbers
      const recipients = [
        ...inquiries
          .filter(inquiry => selectedRecipients.includes(inquiry.id))
          .map(inquiry => inquiry.phone),
        ...(manualPhone ? [manualPhone] : [])
      ];

      // Send SMS to each recipient
      await Promise.all(
        recipients.map(async (to) => {
          await sendSMS(to, smsMessage);
        })
      );

      setSmsMessage('');
      setSelectedRecipients([]);
      setManualPhone('');
      alert('Messages sent successfully!');
    } catch (err) {
      console.error('Error sending SMS:', err);
      setError('Failed to send SMS messages');
    } finally {
      setSendingSMS(false);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      {/* SMS Composition Section */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <Send className="h-6 w-6 text-blue-500" />
          <h2 className="text-xl font-semibold text-gray-900">Send SMS</h2>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Message
            </label>
            <textarea
              value={smsMessage}
              onChange={(e) => setSmsMessage(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={3}
              placeholder="Enter your message..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Manual Phone Number
            </label>
            <div className="flex gap-2">
              <input
                type="tel"
                value={manualPhone}
                onChange={(e) => setManualPhone(e.target.value)}
                placeholder="+1234567890"
                className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Or Select Recipients
            </label>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {inquiries.map((inquiry) => (
                <label key={inquiry.id} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={selectedRecipients.includes(inquiry.id)}
                    onChange={(e) => {
                      setSelectedRecipients(prev =>
                        e.target.checked
                          ? [...prev, inquiry.id]
                          : prev.filter(id => id !== inquiry.id)
                      );
                    }}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-700">
                    {inquiry.customer_name} ({inquiry.phone})
                  </span>
                </label>
              ))}
            </div>
          </div>

          <button
            onClick={handleSendSMS}
            disabled={sendingSMS || !smsMessage.trim() || (!manualPhone && selectedRecipients.length === 0)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {sendingSMS ? 'Sending...' : 'Send SMS'}
          </button>
        </div>
      </div>

      {/* SMS Replies Section */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">SMS Replies</h2>
          <span className="text-sm text-gray-500">
            {smsReplies.filter(reply => !reply.read).length} unread
          </span>
        </div>
        
        <div className="space-y-4">
          {smsReplies.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No SMS replies yet</p>
          ) : (
            smsReplies.map((reply) => (
              <div
                key={reply.id}
                className={`border rounded-lg p-4 ${
                  reply.read ? 'bg-gray-50' : 'bg-blue-50 border-blue-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Phone className="h-5 w-5 text-blue-500" />
                    <span className="font-medium">{reply.from_number}</span>
                  </div>
                  {!reply.read && (
                    <button
                      onClick={() => markReplyAsRead(reply.id)}
                      className="p-2 text-blue-600 hover:text-blue-700 hover:bg-blue-100 rounded-lg"
                      title="Mark as read"
                    >
                      <CheckCircle2 className="h-5 w-5" />
                    </button>
                  )}
                </div>
                <p className="text-gray-700 whitespace-pre-wrap mb-2">{reply.message}</p>
                <div className="flex items-center gap-2 text-gray-500 text-sm">
                  <Clock className="h-4 w-4" />
                  <span>{new Date(reply.created_at).toLocaleString()}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Customer Inquiries Section */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Customer Inquiries</h1>
          {selectedInquiries.length > 0 && (
            <button
              onClick={handleDeleteSelected}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              <Trash2 className="h-4 w-4" />
              Delete Selected ({selectedInquiries.length})
            </button>
          )}
        </div>
        
        <div className="space-y-4">
          {inquiries.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No inquiries found</p>
          ) : (
            inquiries.map((inquiry) => (
              <div
                key={inquiry.id}
                className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <input
                      type="checkbox"
                      checked={selectedInquiries.includes(inquiry.id)}
                      onChange={(e) => {
                        setSelectedInquiries(prev =>
                          e.target.checked
                            ? [...prev, inquiry.id]
                            : prev.filter(id => id !== inquiry.id)
                        );
                      }}
                      className="h-5 w-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-5 w-5 text-blue-500" />
                        <span className="font-medium">{inquiry.customer_name}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Mail className="h-4 w-4" />
                        <a href={`mailto:${inquiry.email}`} className="hover:text-blue-600">
                          {inquiry.email}
                        </a>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Phone className="h-4 w-4" />
                        <span>{inquiry.phone}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Clock className="h-4 w-4" />
                        <span>{new Date(inquiry.created_at).toLocaleString()}</span>
                      </div>
                      <div className="mt-4 bg-gray-50 p-4 rounded-lg">
                        <p className="text-gray-700 whitespace-pre-wrap">{inquiry.question}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}