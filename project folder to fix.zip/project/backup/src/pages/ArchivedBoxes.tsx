import React, { useState, useEffect } from 'react';
import { Box, Package, Search, Scale } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { LoadingSpinner } from '../components/LoadingSpinner';

interface ArchivedBox {
  id: string;
  type: 'single' | 'small' | 'big';
  weight: number;
  created_at: string;
  customer: {
    id: string;
    first_name: string;
    last_name: string;
    bidder_number: string;
  };
  items: {
    id: string;
    item_code: string;
    item_name: string;
  }[];
}

const getBoxTypeColor = (type: string) => {
  switch (type) {
    case 'single':
      return 'bg-blue-100 text-blue-600';
    case 'small':
      return 'bg-green-100 text-green-600';
    case 'big':
      return 'bg-purple-100 text-purple-600';
    default:
      return 'bg-gray-100 text-gray-600';
  }
};

export function ArchivedBoxes() {
  const [boxes, setBoxes] = useState<ArchivedBox[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchArchivedBoxes();
  }, []);

  const fetchArchivedBoxes = async () => {
    try {
      const { data: boxesData, error: boxesError } = await supabase
        .from('shipped_boxes')
        .select(`
          id,
          type,
          weight,
          created_at,
          customer:customer_id (
            id,
            first_name,
            last_name,
            bidder_number
          ),
          shipped_box_items!inner (
            order:order_id (
              id,
              item_code,
              item_name
            )
          )
        `)
        .eq('archived', true)  // Only fetch archived boxes
        .order('created_at', { ascending: false });

      if (boxesError) throw boxesError;

      // Process the data to make it easier to work with
      const processedBoxes = boxesData.map(box => ({
        id: box.id,
        type: box.type,
        weight: box.weight,
        created_at: box.created_at,
        customer: box.customer,
        items: box.shipped_box_items.map(item => item.order)
      }));

      setBoxes(processedBoxes);
      setError(null);
    } catch (error) {
      console.error('Error fetching archived boxes:', error);
      setError('Failed to fetch archived boxes');
    } finally {
      setLoading(false);
    }
  };

  const filteredBoxes = boxes.filter(box => {
    const searchString = searchTerm.toLowerCase();
    const customerName = `${box.customer.first_name} ${box.customer.last_name}`.toLowerCase();
    const bidderNumber = box.customer.bidder_number.toLowerCase();
    const itemCodes = box.items.map(item => item.item_code.toLowerCase());
    const itemNames = box.items.map(item => item.item_name.toLowerCase());

    return (
      customerName.includes(searchString) ||
      bidderNumber.includes(searchString) ||
      itemCodes.some(code => code.includes(searchString)) ||
      itemNames.some(name => name.includes(searchString))
    );
  });

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-6">
      {/* Search Box */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="relative max-w-2xl mx-auto">
          <input
            type="text"
            placeholder="Search by customer name, bidder number, or item..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
          />
          <Search className="absolute left-4 top-4 h-6 w-6 text-gray-400" />
        </div>
      </div>

      {error ? (
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      ) : filteredBoxes.length === 0 ? (
        <div className="bg-white rounded-lg shadow-lg p-6 text-center text-gray-500">
          No archived boxes found
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredBoxes.map((box) => (
            <div key={box.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="p-6">
                <div className="flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`p-2 rounded-lg ${getBoxTypeColor(box.type)}`}>
                        <Box className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">
                          {box.customer.first_name} {box.customer.last_name}
                        </div>
                        <div className="text-sm text-gray-500">
                          Bidder #: {box.customer.bidder_number}
                        </div>
                        <div className="text-sm text-gray-500">
                          Archived on {new Date(box.created_at).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-sm font-medium text-gray-700">
                        {box.type.charAt(0).toUpperCase() + box.type.slice(1)} Box
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Scale className="h-5 w-5" />
                        <span>{box.weight}kg</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {box.items.map((item) => (
                      <div
                        key={item.id}
                        className="inline-flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-gray-700"
                      >
                        <Package className="h-4 w-4 text-gray-500" />
                        <span>{item.item_code}</span>
                        <span className="text-gray-400">-</span>
                        <span>{item.item_name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}