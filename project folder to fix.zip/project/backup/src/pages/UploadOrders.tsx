import React, { useState, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { Upload, AlertCircle } from 'lucide-react';

interface LogEntry {
  id: string;
  message: string;
  timestamp: Date;
  type: 'upload' | 'process' | 'error';
}

interface OrderData {
  recordedAt: string;
  bidderNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  itemCode: string;
  itemName: string;
  quantity: number;
  debit: number;
  credit: number;
  balance: number;
}

const AUTO_SHIP_KEYWORDS = [
  'fee',
  'fees',
  'account',
  'ticket',
  'tickets',
  'postage',
  'payment'
];

const shouldAutoShip = (itemName: string): boolean => {
  const lowerItemName = itemName.toLowerCase();
  return AUTO_SHIP_KEYWORDS.some(keyword => lowerItemName.includes(keyword.toLowerCase()));
};

const isPostageItem = (itemName: string): boolean => {
  return itemName.toLowerCase().includes('postage');
};

const getBoxTypeAndPrice = (itemName: string): { type: 'small' | 'medium' | 'big', price: number } => {
  const lowerItemName = itemName.toLowerCase();
  if (lowerItemName.includes('small')) {
    return { type: 'small', price: 3.99 };
  } else if (lowerItemName.includes('medium')) {
    return { type: 'medium', price: 7.99 };
  } else {
    return { type: 'big', price: 9.99 };
  }
};

const generateId = () => {
  return crypto.randomUUID();
};

const parseCSVLine = (line: string): string[] => {
  const values: string[] = [];
  let currentValue = '';
  let insideQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      insideQuotes = !insideQuotes;
    } else if (char === ',' && !insideQuotes) {
      values.push(currentValue.trim());
      currentValue = '';
    } else {
      currentValue += char;
    }
  }
  
  // Add the last field
  values.push(currentValue.trim());
  
  // Clean up quotes and whitespace
  return values.map(value => {
    // Remove surrounding quotes and trim
    value = value.replace(/^"([\s\S]*)"$/, '$1').trim();
    // Replace multiple spaces with single space
    value = value.replace(/\s+/g, ' ');
    return value;
  });
};

const parseCurrency = (value: string): number => {
  if (!value || value === '-') return 0;
  
  // Remove currency symbol, commas and spaces
  const cleanValue = value.replace(/[£$,\s]/g, '');
  
  // Handle parentheses for negative values
  if (cleanValue.startsWith('(') && cleanValue.endsWith(')')) {
    return -parseFloat(cleanValue.slice(1, -1));
  }
  
  const number = parseFloat(cleanValue);
  if (isNaN(number)) {
    throw new Error(`Invalid currency value: ${value}`);
  }
  return number;
};

const parseTimestamp = (dateStr: string): string => {
  try {
    // Check for Excel error values like #REF!, #N/A, etc.
    if (dateStr.includes('#')) {
      throw new Error(`Invalid date format: Found Excel error value "${dateStr}"`);
    }
    
    // Input format: "DDMMYYYY HHMM HH:MM:SS"
    const parts = dateStr.trim().split(' ');
    if (parts.length !== 3) {
      throw new Error(`Invalid date format: Expected "DDMMYYYY HHMM HH:MM:SS", got "${dateStr}"`);
    }

    const datePart = parts[0];
    const timePart = parts[2]; // Use the HH:MM:SS part

    if (datePart.length !== 8) {
      throw new Error(`Invalid date format: Expected DDMMYYYY, got "${datePart}"`);
    }

    // Extract date components
    const day = datePart.substring(0, 2);
    const month = datePart.substring(2, 4);
    const year = datePart.substring(4, 8);

    // Create ISO string
    const isoString = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${timePart}.000Z`;
    
    // Final validation
    const date = new Date(isoString);
    if (isNaN(date.getTime())) {
      throw new Error(`Invalid date: ${isoString}`);
    }

    return isoString;
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Error parsing timestamp: ${error.message}`);
    }
    throw new Error(`Error parsing timestamp: ${dateStr}`);
  }
};

export function UploadOrders() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [processing, setProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addLog = (message: string, type: LogEntry['type']) => {
    const newLog: LogEntry = {
      id: generateId(),
      message,
      timestamp: new Date(),
      type,
    };
    setLogs(prev => [newLog, ...prev].slice(0, 100));
  };

  const validateOrderData = (values: string[], index: number): OrderData => {
    const lineNumber = index + 2; // Add 2 to account for 0-based index and header row

    if (values.length < 11) {
      throw new Error(`Line ${lineNumber}: Invalid number of columns. Expected at least 11 columns, got ${values.length}. Line content: ${values.join(',')}`);
    }

    // Required field validation
    const requiredFields = [
      { index: 0, name: 'Recorded At' },
      { index: 1, name: 'Bidder number' },
      { index: 2, name: 'First name' },
      { index: 3, name: 'Last name' }
    ];

    for (const field of requiredFields) {
      if (!values[field.index]?.trim()) {
        throw new Error(`Line ${lineNumber}: ${field.name} is required`);
      }
    }

    // Use a fallback date if the timestamp is invalid
    let recordedAt;
    try {
      recordedAt = parseTimestamp(values[0]);
    } catch (error) {
      addLog(`Warning on line ${lineNumber}: ${error instanceof Error ? error.message : 'Invalid date'}. Using current date instead.`, 'error');
      recordedAt = new Date().toISOString();
    }

    // Parse numeric values with better error handling
    let debit = 0, credit = 0, balance = 0;
    try {
      debit = parseCurrency(values[8]);
      credit = parseCurrency(values[9]);
      balance = parseCurrency(values[10]);
    } catch (error) {
      throw new Error(`Line ${lineNumber}: ${error instanceof Error ? error.message : 'Error parsing currency values'}`);
    }

    return {
      recordedAt,
      bidderNumber: values[1].trim(),
      firstName: values[2].trim(),
      lastName: values[3].trim(),
      email: values[4]?.trim() || '',
      itemCode: values[5]?.trim() || '',
      itemName: values[6]?.trim() || '',
      quantity: 1, // Default to 1 since it's not in the data
      debit,
      credit,
      balance
    };
  };

  const parseOrders = (text: string): OrderData[] => {
    try {
      // Normalize line endings and split into lines
      const lines = text.replace(/\r\n/g, '\n').split('\n').filter(line => line.trim());
      
      if (lines.length < 2) {
        throw new Error('No orders found. Please upload a valid file with headers.');
      }

      const headerLine = parseCSVLine(lines[0]);
      const expectedHeaders = [
        'Recorded At', 'Bidder#', 'Firstname', 'Lastname', 'Email',
        'Item#', 'Item', 'Quantity', 'Debit', 'Credit', 'Balance'
      ];

      // Normalize headers for comparison by removing special characters and spaces
      const normalizeHeader = (header: string) => 
        header.toLowerCase()
              .replace(/[^a-z0-9]/g, '') // Remove all non-alphanumeric characters
              .replace(/\s+/g, '');       // Remove all whitespace

      const normalizedHeaders = headerLine.map(normalizeHeader);
      const normalizedExpected = expectedHeaders.map(normalizeHeader);

      // Check if all required headers are present
      const missingHeaders = expectedHeaders.filter((header, index) => {
        const normalizedHeader = normalizeHeader(header);
        return !normalizedHeaders.includes(normalizedHeader);
      });

      if (missingHeaders.length > 0) {
        throw new Error(
          `Invalid header format. Missing headers: ${missingHeaders.join(', ')}`
        );
      }

      // Join lines that are part of a quoted field
      let mergedLines: string[] = [];
      let currentLine = '';
      let insideQuotes = false;

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i];
        
        // Count quotes in the line
        const quoteCount = (line.match(/"/g) || []).length;
        
        if (!insideQuotes && quoteCount % 2 === 1) {
          // Start of a quoted field
          insideQuotes = true;
          currentLine = line;
        } else if (insideQuotes) {
          if (quoteCount % 2 === 1) {
            // End of a quoted field
            insideQuotes = false;
            currentLine += '\n' + line;
            mergedLines.push(currentLine);
            currentLine = '';
          } else {
            // Middle of a quoted field
            currentLine += '\n' + line;
          }
        } else {
          // Normal line
          mergedLines.push(line);
        }
      }

      // If we're still inside quotes at the end, add the last line
      if (currentLine) {
        mergedLines.push(currentLine);
      }

      const validOrders: OrderData[] = [];
      const errors: string[] = [];

      mergedLines.forEach((line, index) => {
        try {
          const values = parseCSVLine(line);
          const orderData = validateOrderData(values, index);
          validOrders.push(orderData);
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : 'Unknown error';
          errors.push(`Error on line ${index + 2}: ${errorMessage}`);
          addLog(`Error on line ${index + 2}: ${errorMessage}`, 'error');
        }
      });

      if (errors.length > 0) {
        addLog(`Processed with ${errors.length} errors. ${validOrders.length} valid orders found.`, 'process');
      }

      if (validOrders.length === 0) {
        throw new Error('No valid orders found in the file. Please check the file format and try again.');
      }

      return validOrders;
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to parse orders: ${error.message}`);
      }
      throw new Error('Failed to parse orders: Unknown error');
    }
  };

  const processCustomer = async (customerData: OrderData): Promise<string> => {
    try {
      // Find existing customer
      const { data: existingCustomer, error: findError } = await supabase
        .from('customers')
        .select('id')
        .eq('bidder_number', customerData.bidderNumber)
        .maybeSingle();

      if (findError) {
        throw new Error(`Database error: ${findError.message}`);
      }

      if (existingCustomer) {
        // Update existing customer
        const { error: updateError } = await supabase
          .from('customers')
          .update({
            first_name: customerData.firstName,
            last_name: customerData.lastName,
            email: customerData.email,
            balance: customerData.balance
          })
          .eq('id', existingCustomer.id);

        if (updateError) {
          throw new Error(`Failed to update customer: ${updateError.message}`);
        }

        return existingCustomer.id;
      } else {
        // Create new customer
        const { data: newCustomer, error: insertError } = await supabase
          .from('customers')
          .insert({
            bidder_number: customerData.bidderNumber,
            first_name: customerData.firstName,
            last_name: customerData.lastName,
            email: customerData.email,
            balance: customerData.balance
          })
          .select('id')
          .single();

        if (insertError) {
          throw new Error(`Failed to create customer: ${insertError.message}`);
        }

        if (!newCustomer) {
          throw new Error('Failed to create customer: No data returned');
        }

        return newCustomer.id;
      }
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to process customer ${customerData.bidderNumber}: ${error.message}`);
      }
      throw new Error(`Failed to process customer ${customerData.bidderNumber}: Unknown error`);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        addLog(`File "${file.name}" loaded successfully`, 'upload');
        processOrders(text);
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Error reading file';
        addLog(`Error reading file: ${message}`, 'error');
      }
    };

    reader.onerror = () => {
      addLog('Error reading file', 'error');
    };

    reader.readAsText(file);
  };

  const processOrders = async (ordersText: string) => {
    if (!ordersText.trim()) {
      addLog('No orders to process. Please upload a file first.', 'error');
      return;
    }

    setProcessing(true);
    try {
      const parsedOrders = parseOrders(ordersText);
      if (parsedOrders.length === 0) {
        throw new Error('No valid orders found in the file');
      }
      
      addLog(`Processing ${parsedOrders.length} orders...`, 'process');

      // Group orders by customer
      const customerOrders = parsedOrders.reduce((acc, order) => {
        const key = order.bidderNumber;
        if (!acc[key]) acc[key] = [];
        acc[key].push(order);
        return acc;
      }, {} as Record<string, OrderData[]>);

      // Process each customer's orders
      for (const [bidderNumber, customerOrderGroup] of Object.entries(customerOrders)) {
        const firstOrder = customerOrderGroup[0];
        
        try {
          // Process customer and get ID
          const customerId = await processCustomer(firstOrder);
          addLog(`Processed customer: ${firstOrder.firstName} ${firstOrder.lastName}`, 'process');

          // Create orders batch
          const orderBatch = customerOrderGroup.map(order => ({
            customer_id: customerId,
            recorded_at: order.recordedAt,
            item_code: order.itemCode,
            item_name: order.itemName,
            quantity: order.quantity,
            debit: order.debit,
            credit: order.credit,
            status: shouldAutoShip(order.itemName) ? 'shipped' : 'unprocessed',
            processed_at: shouldAutoShip(order.itemName) ? new Date().toISOString() : null
          }));

          // Insert orders
          const { error: ordersError } = await supabase
            .from('orders')
            .insert(orderBatch);

          if (ordersError) {
            throw new Error(`Database error: ${ordersError.message}`);
          }

          // Create box orders for postage items
          for (const order of customerOrderGroup) {
            if (isPostageItem(order.itemName)) {
              const { type, price } = getBoxTypeAndPrice(order.itemName);
              
              const { error: boxOrderError } = await supabase
                .from('box_orders')
                .insert({
                  customer_name: `${order.firstName} ${order.lastName}`,
                  email: order.email || '',
                  box_type: type,
                  price: price,
                  status: 'new',
                  created_at: order.recordedAt
                });

              if (boxOrderError) {
                addLog(`Warning: Failed to create box order for ${order.firstName} ${order.lastName}: ${boxOrderError.message}`, 'error');
              } else {
                addLog(`Created box order for ${order.firstName} ${order.lastName}`, 'process');
              }
            }
          }

          addLog(`Processed ${orderBatch.length} orders for ${firstOrder.firstName} ${firstOrder.lastName}`, 'process');
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
          addLog(`Error processing customer ${bidderNumber}: ${errorMessage}`, 'error');
          continue; // Continue with next customer even if one fails
        }
      }

      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      addLog('All orders processed successfully', 'process');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      addLog(`Error: ${errorMessage}`, 'error');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Upload Orders</h2>
        <div className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-blue-800 mb-2">File Format Instructions</h3>
            <p className="text-sm text-blue-700">
              Upload your orders file in CSV format with the following columns:
            </p>
            <div className="mt-2 text-xs font-mono bg-white p-2 rounded border border-blue-200">
              Recorded At,Bidder#,Firstname,Lastname,Email,Item#,Item,Quantity,Debit,Credit,Balance
            </div>
            <p className="text-sm text-blue-700 mt-2">
              Date format should be: DDMMYYYY HHMM HH:MM:SS
            </p>
          </div>

          {/* File Upload */}
          <div className="flex items-center justify-center w-full">
            <label 
              htmlFor="file-upload"
              className="flex flex-col items-center justify-center w-full h-32 border-2 border-blue-300 border-dashed rounded-lg cursor-pointer bg-blue-50 hover:bg-blue-100"
            >
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-8 h-8 mb-3 text-blue-500" />
                <p className="mb-2 text-sm text-blue-700">
                  <span className="font-semibold">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-blue-600">CSV file</p>
              </div>
              <input
                ref={fileInputRef}
                id="file-upload"
                type="file"
                accept=".csv"
                className="hidden"
                onChange={handleFileUpload}
                disabled={processing}
              />
            </label>
          </div>
        </div>
      </div>

      {/* Real-time Logs */}
      <div className="bg-white rounded-lg shadow p-4 md:p-6">
        <h2 className="text-xl font-semibold mb-4">Real-time Logs</h2>
        <div className="bg-gray-50 rounded-lg p-4 h-[calc(100vh-24rem)] md:h-96 overflow-auto font-mono text-sm">
          {logs.length === 0 ? (
            <div className="text-gray-500">No recent activity</div>
          ) : (
            logs.map(log => (
              <div
                key={log.id}
                className={`mb-2 p-2 rounded ${
                  log.type === 'upload'
                    ? 'bg-blue-100'
                    : log.type === 'error'
                    ? 'bg-red-100'
                    : 'bg-green-100'
                }`}
              >
                <span className="text-gray-500">
                  {log.timestamp.toLocaleTimeString()}
                </span>{' '}
                {log.message}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}