import React, { useState, useEffect } from 'react';
import { Key, Save, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface TwilioConfig {
  account_sid: string;
  auth_token: string;
  phone_number: string;
}

export function Settings() {
  const [config, setConfig] = useState<TwilioConfig>({
    account_sid: '',
    auth_token: '',
    phone_number: ''
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    try {
      const { data, error } = await supabase
        .from('twilio_config')
        .select('*')
        .limit(1)
        .single();

      if (error) throw error;
      if (data) {
        setConfig(data);
      }
    } catch (err) {
      console.error('Error fetching Twilio config:', err);
      setMessage({
        type: 'error',
        text: 'Failed to load Twilio configuration'
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    try {
      // First, delete any existing config
      await supabase
        .from('twilio_config')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all rows

      // Then insert new config
      const { error: insertError } = await supabase
        .from('twilio_config')
        .insert([config]);

      if (insertError) throw insertError;

      setMessage({
        type: 'success',
        text: 'Twilio configuration saved successfully!'
      });
    } catch (err) {
      console.error('Error saving Twilio config:', err);
      setMessage({
        type: 'error',
        text: 'Failed to save Twilio configuration'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center gap-3 mb-6">
            <Key className="h-8 w-8 text-blue-500" />
            <h1 className="text-2xl font-bold text-gray-900">Twilio Settings</h1>
          </div>

          {message && (
            <div className={`p-4 rounded-lg mb-6 ${
              message.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
            }`}>
              <div className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                <span>{message.text}</span>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="account_sid" className="block text-sm font-medium text-gray-700 mb-2">
                Account SID
              </label>
              <input
                type="text"
                id="account_sid"
                required
                value={config.account_sid}
                onChange={e => setConfig(prev => ({ ...prev, account_sid: e.target.value }))}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
              />
            </div>

            <div>
              <label htmlFor="auth_token" className="block text-sm font-medium text-gray-700 mb-2">
                Auth Token
              </label>
              <input
                type="password"
                id="auth_token"
                required
                value={config.auth_token}
                onChange={e => setConfig(prev => ({ ...prev, auth_token: e.target.value }))}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Your Twilio auth token"
              />
            </div>

            <div>
              <label htmlFor="phone_number" className="block text-sm font-medium text-gray-700 mb-2">
                Twilio Phone Number
              </label>
              <input
                type="tel"
                id="phone_number"
                required
                value={config.phone_number}
                onChange={e => setConfig(prev => ({ ...prev, phone_number: e.target.value }))}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="+1234567890"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="flex items-center justify-center gap-2 w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-5 w-5" />
              {saving ? 'Saving...' : 'Save Settings'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}