import React, { useState, useEffect, useRef } from 'react';
import { Package, Mail, Phone, Clock, AlertCircle, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { LoadingSpinner } from '../components/LoadingSpinner';
import type { RealtimeChannel } from '@supabase/supabase-js';

interface BoxOrder {
  id: string;
  customer_name: string;
  email: string;
  phone: string;
  box_type: 'small' | 'medium' | 'big';
  price: number;
  created_at: string;
}

export function BoxOrders() {
  const [orders, setOrders] = useState<BoxOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const ordersChannelRef = useRef<RealtimeChannel | null>(null);

  useEffect(() => {
    fetchOrders();
    setupRealtimeSubscription();

    return () => {
      if (ordersChannelRef.current) {
        ordersChannelRef.current.unsubscribe();
      }
    };
  }, []);

  const setupRealtimeSubscription = () => {
    ordersChannelRef.current = supabase
      .channel('box-orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'box_orders'
        },
        () => {
          fetchOrders();
        }
      )
      .subscribe();
  };

  const fetchOrders = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('box_orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) {
        console.error('Error fetching orders:', fetchError);
        throw fetchError;
      }

      setOrders(data || []);
    } catch (err) {
      console.error('Error in fetchOrders:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch orders');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteSelected = async () => {
    if (!selectedOrders.length) return;

    if (!confirm(`Are you sure you want to delete ${selectedOrders.length} selected order(s)?`)) {
      return;
    }

    try {
      const { error: deleteError } = await supabase
        .from('box_orders')
        .delete()
        .in('id', selectedOrders);

      if (deleteError) throw deleteError;

      setOrders(prev => prev.filter(order => !selectedOrders.includes(order.id)));
      setSelectedOrders([]);
    } catch (err) {
      console.error('Error deleting orders:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete orders');
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Box Orders</h1>
          {selectedOrders.length > 0 && (
            <button
              onClick={handleDeleteSelected}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              <Trash2 className="h-4 w-4" />
              Delete Selected ({selectedOrders.length})
            </button>
          )}
        </div>
        
        <div className="space-y-4">
          {orders.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No orders found</p>
          ) : (
            orders.map((order) => (
              <div
                key={order.id}
                className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <input
                      type="checkbox"
                      checked={selectedOrders.includes(order.id)}
                      onChange={(e) => {
                        setSelectedOrders(prev =>
                          e.target.checked
                            ? [...prev, order.id]
                            : prev.filter(id => id !== order.id)
                        );
                      }}
                      className="h-5 w-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Package className="h-5 w-5 text-blue-500" />
                        <span className="font-medium">{order.customer_name}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Mail className="h-4 w-4" />
                        <a href={`mailto:${order.email}`} className="hover:text-blue-600">
                          {order.email}
                        </a>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Phone className="h-4 w-4" />
                        <span>{order.phone}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Clock className="h-4 w-4" />
                        <span>{new Date(order.created_at).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-lg font-medium">
                      {order.box_type.charAt(0).toUpperCase() + order.box_type.slice(1)} Box
                    </div>
                    <div className="text-green-600 font-medium">
                      £{order.price.toFixed(2)}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}