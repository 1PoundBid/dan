import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Package, Archive, Box, Clock, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Customer {
  id: string;
  first_name: string;
  last_name: string;
  unprocessed_count: number;
  cage_items: number;
  shelf_items: number;
  last_purchase_days: number;
}

interface GroupedCustomers {
  [key: string]: Customer[];
}

export function Customers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);
  const [selectedCustomers, setSelectedCustomers] = useState<string[]>([]);
  const navigate = useNavigate();
  
  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      const { data, error } = await supabase
        .from('customers')
        .select(`
          id,
          first_name,
          last_name,
          orders!orders_customer_id_fkey (
            status,
            recorded_at
          ),
          storage_items!storage_items_customer_id_fkey (
            type
          )
        `)
        .order('first_name');

      if (error) throw error;

      const processedCustomers = data.map(customer => {
        const unprocessedOrders = customer.orders.filter(order => order.status === 'unprocessed');
        const cageItems = customer.storage_items.filter(item => item.type === 'bag_cage').length;
        const shelfItems = customer.storage_items.filter(item => item.type === 'box_shelf').length;
        
        // Calculate days since last purchase
        const lastPurchaseDate = customer.orders.length > 0
          ? Math.max(...customer.orders.map(order => new Date(order.recorded_at).getTime()))
          : null;
        
        const daysSinceLastPurchase = lastPurchaseDate
          ? Math.floor((Date.now() - lastPurchaseDate) / (1000 * 60 * 60 * 24))
          : 0;

        return {
          id: customer.id,
          first_name: customer.first_name,
          last_name: customer.last_name,
          unprocessed_count: unprocessedOrders.length,
          cage_items: cageItems,
          shelf_items: shelfItems,
          last_purchase_days: daysSinceLastPurchase
        };
      });

      setCustomers(processedCustomers);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const handleDeleteSelected = async () => {
    if (!selectedCustomers.length) return;
    
    if (!confirm(`Are you sure you want to delete ${selectedCustomers.length} selected customer(s)?`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('customers')
        .delete()
        .in('id', selectedCustomers);

      if (error) throw error;

      // Remove deleted customers from state
      setCustomers(prev => prev.filter(c => !selectedCustomers.includes(c.id)));
      setSelectedCustomers([]); // Clear selection
    } catch (error) {
      console.error('Error deleting customers:', error);
      alert('Failed to delete customers. Please try again.');
    }
  };

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  const filteredCustomers = customers.filter(customer => {
    const fullName = `${customer.first_name} ${customer.last_name}`.toLowerCase();
    return fullName.includes(searchTerm.toLowerCase());
  });

  const groupedCustomers = filteredCustomers.reduce((acc: GroupedCustomers, customer) => {
    const firstLetter = customer.first_name[0].toUpperCase();
    if (!acc[firstLetter]) {
      acc[firstLetter] = [];
    }
    acc[firstLetter].push(customer);
    return acc;
  }, {});

  const scrollToLetter = (letter: string) => {
    setSelectedLetter(letter);
    const element = document.getElementById(`group-${letter}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Box */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="relative max-w-2xl mx-auto">
          <input
            type="text"
            placeholder="Search customers by name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
          />
          <Search className="absolute left-4 top-4 h-6 w-6 text-gray-400" />
        </div>
      </div>

      {/* Delete Button */}
      {selectedCustomers.length > 0 && (
        <div className="bg-white rounded-lg shadow-lg p-4">
          <button
            onClick={handleDeleteSelected}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            <Trash2 className="h-4 w-4" />
            Delete Selected ({selectedCustomers.length})
          </button>
        </div>
      )}

      {/* Legend */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-700 mb-4">Summary Legend</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="flex items-center gap-3 bg-yellow-50 p-3 rounded-lg">
            <Package className="h-6 w-6 text-yellow-500" />
            <span className="text-sm font-medium text-gray-700">Unprocessed Orders</span>
          </div>
          <div className="flex items-center gap-3 bg-pink-50 p-3 rounded-lg">
            <Archive className="h-6 w-6 text-pink-500" />
            <span className="text-sm font-medium text-gray-700">Items in Cage</span>
          </div>
          <div className="flex items-center gap-3 bg-orange-50 p-3 rounded-lg">
            <Box className="h-6 w-6 text-orange-500" />
            <span className="text-sm font-medium text-gray-700">Items on Shelf</span>
          </div>
          <div className="flex items-center gap-3 bg-blue-50 p-3 rounded-lg">
            <Clock className="h-6 w-6 text-blue-500" />
            <span className="text-sm font-medium text-gray-700">Last Purchase</span>
          </div>
        </div>
      </div>

      {/* Alphabet Navigation */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex flex-wrap gap-2 justify-center">
          {alphabet.map((letter) => (
            <button
              key={letter}
              onClick={() => scrollToLetter(letter)}
              className={`w-10 h-10 rounded-lg flex items-center justify-center text-sm font-medium transition-all transform hover:scale-110
                ${selectedLetter === letter
                  ? 'bg-blue-500 text-white shadow-lg'
                  : groupedCustomers[letter]
                    ? 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                    : 'bg-gray-50 text-gray-300 cursor-not-allowed'
                }`}
              disabled={!groupedCustomers[letter]}
            >
              {letter}
            </button>
          ))}
        </div>
      </div>

      {/* Customers List */}
      <div className="space-y-8">
        {alphabet.map((letter) => {
          if (!groupedCustomers[letter]) return null;
          
          return (
            <div key={letter} id={`group-${letter}`} className="space-y-4">
              <h2 className="text-3xl font-bold text-gray-800 sticky top-0 bg-gray-100 p-4 rounded-lg shadow-sm z-10">
                {letter}
              </h2>
              <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="divide-y divide-gray-200">
                  {groupedCustomers[letter].map((customer) => (
                    <div
                      key={customer.id}
                      className="p-6 hover:bg-blue-50 transition-all"
                    >
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div className="flex items-center gap-4">
                          <input
                            type="checkbox"
                            checked={selectedCustomers.includes(customer.id)}
                            onChange={(e) => {
                              setSelectedCustomers(prev =>
                                e.target.checked
                                  ? [...prev, customer.id]
                                  : prev.filter(id => id !== customer.id)
                              );
                            }}
                            onClick={(e) => e.stopPropagation()}
                            className="h-5 w-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <div 
                            onClick={() => navigate(`/customers/${customer.id}`)}
                            className="cursor-pointer"
                          >
                            <h3 className="text-xl font-medium text-gray-900">
                              {customer.first_name} {customer.last_name}
                            </h3>
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-6">
                          {/* Unprocessed Orders */}
                          <div className="flex items-center gap-3 bg-yellow-50 px-4 py-2 rounded-lg">
                            <Package className="h-5 w-5 text-yellow-500" />
                            <div className="flex flex-col">
                              <span className="text-sm text-gray-500">Unprocessed</span>
                              <span className="text-lg font-semibold text-gray-700">
                                {customer.unprocessed_count}
                              </span>
                            </div>
                          </div>
                          
                          {/* Cage Items */}
                          <div className="flex items-center gap-3 bg-pink-50 px-4 py-2 rounded-lg">
                            <Archive className="h-5 w-5 text-pink-500" />
                            <div className="flex flex-col">
                              <span className="text-sm text-gray-500">In Cage</span>
                              <span className="text-lg font-semibold text-gray-700">
                                {customer.cage_items}
                              </span>
                            </div>
                          </div>
                          
                          {/* Shelf Items */}
                          <div className="flex items-center gap-3 bg-orange-50 px-4 py-2 rounded-lg">
                            <Box className="h-5 w-5 text-orange-500" />
                            <div className="flex flex-col">
                              <span className="text-sm text-gray-500">On Shelf</span>
                              <span className="text-lg font-semibold text-gray-700">
                                {customer.shelf_items}
                              </span>
                            </div>
                          </div>
                          
                          {/* Days Since Last Purchase */}
                          <div className="flex items-center gap-3 bg-blue-50 px-4 py-2 rounded-lg">
                            <Clock className="h-5 w-5 text-blue-500" />
                            <div className="flex flex-col">
                              <span className="text-sm text-gray-500">Last Purchase</span>
                              <span className="text-lg font-semibold text-gray-700">
                                {customer.last_purchase_days === 0
                                  ? 'Today'
                                  : customer.last_purchase_days === 1
                                  ? 'Yesterday'
                                  : `${customer.last_purchase_days} days ago`}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}