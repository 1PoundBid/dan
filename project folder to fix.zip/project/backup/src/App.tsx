import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { UploadOrders } from './pages/UploadOrders';
import { CustomerDetails } from './pages/CustomerDetails';
import { Customers } from './pages/Customers';
import { ArchivedBoxes } from './pages/ArchivedBoxes';
import { BoxOrders } from './pages/BoxOrders';
import { CustomerInquiries } from './pages/CustomerInquiries';
import { OrderBox } from './pages/OrderBox';
import { ContactForm } from './pages/ContactForm';
import { StockSorting } from './pages/StockSorting';
import { Settings } from './pages/Settings';
import { ErrorBoundary } from './components/ErrorBoundary';

function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={
            <Layout>
              <Dashboard />
            </Layout>
          } />
          <Route path="/upload" element={
            <Layout>
              <UploadOrders />
            </Layout>
          } />
          <Route path="/customers/:id" element={
            <Layout>
              <CustomerDetails />
            </Layout>
          } />
          <Route path="/customers" element={
            <Layout>
              <Customers />
            </Layout>
          } />
          <Route path="/archived-boxes" element={
            <Layout>
              <ArchivedBoxes />
            </Layout>
          } />
          <Route path="/box-orders" element={
            <Layout>
              <BoxOrders />
            </Layout>
          } />
          <Route path="/order-box" element={
            <Layout>
              <OrderBox />
            </Layout>
          } />
          <Route path="/inquiries" element={
            <Layout>
              <CustomerInquiries />
            </Layout>
          } />
          <Route path="/contact" element={
            <Layout>
              <ContactForm />
            </Layout>
          } />
          <Route path="/stock-sorting" element={
            <Layout>
              <StockSorting />
            </Layout>
          } />
          <Route path="/settings" element={
            <Layout>
              <Settings />
            </Layout>
          } />
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}

export default App;