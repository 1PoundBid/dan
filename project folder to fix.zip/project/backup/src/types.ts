export interface Order {
  id: string;
  itemName: string;
  bidAmount: number;
  customerName: string;
  status: 'pending' | 'in_tray' | 'in_box' | 'shipped';
  createdAt: string;
  updatedAt: string;
  shippingAddress: string;
  trackingNumber?: string;
}

export interface Customer {
  id: string;
  bidder_number: string;
  first_name: string;
  last_name: string;
  email: string;
  balance: number | null;
}

export interface AppState {
  orders: Order[];
  customers: Customer[];
  lastSync: string;
}