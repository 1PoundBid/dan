/**
 * ElevenLabs API client for voice synthesis
 */

interface VoiceSettings {
  stability: number;
  similarity_boost: number;
}

interface TextToSpeechRequest {
  text: string;
  model_id: string;
  voice_settings: VoiceSettings;
}

interface ElevenLabsConfig {
  apiKey: string;
  voiceId: string;
  model: string;
}

// Get configuration from environment variables
const config: ElevenLabsConfig = {
  apiKey: import.meta.env.VITE_ELEVENLABS_API_KEY || '',
  voiceId: import.meta.env.VITE_ELEVENLABS_VOICE_ID || '',
  model: 'eleven_turbo_v2'
};

// Cache for audio to avoid repeated API calls for the same text
const audioCache = new Map<string, ArrayBuffer>();

/**
 * Validates ElevenLabs configuration
 */
function validateConfig() {
  const errors = [];
  
  if (!config.apiKey) {
    errors.push('ElevenLabs API key (VITE_ELEVENLABS_API_KEY) is not configured');
  }
  
  if (!config.voiceId) {
    errors.push('ElevenLabs Voice ID (VITE_ELEVENLABS_VOICE_ID) is not configured');
  }

  if (errors.length > 0) {
    throw new Error(`ElevenLabs configuration errors:\n${errors.join('\n')}`);
  }
}

/**
 * Converts text to speech using ElevenLabs API
 */
export async function textToSpeech(text: string): Promise<ArrayBuffer> {
  try {
    // Validate configuration first
    validateConfig();

    // Check cache first
    if (audioCache.has(text)) {
      return audioCache.get(text)!;
    }

    const url = `https://api.elevenlabs.io/v1/text-to-speech/${config.voiceId}`;
    
    const request: TextToSpeechRequest = {
      text,
      model_id: config.model,
      voice_settings: {
        stability: 0.5,
        similarity_boost: 0.75
      }
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': config.apiKey
      },
      body: JSON.stringify(request)
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      const errorMessage = errorData?.detail?.message || await response.text();
      throw new Error(`ElevenLabs API error (${response.status}): ${errorMessage}`);
    }

    const audioData = await response.arrayBuffer();
    
    // Cache the audio for future use
    audioCache.set(text, audioData);
    
    return audioData;
  } catch (error) {
    console.error('Error calling ElevenLabs API:', error);
    throw error;
  }
}

/**
 * Plays audio from ArrayBuffer
 */
export function playAudio(audioData: ArrayBuffer): Promise<void> {
  return new Promise((resolve, reject) => {
    const blob = new Blob([audioData], { type: 'audio/mpeg' });
    const url = URL.createObjectURL(blob);
    const audio = new Audio(url);
    
    audio.onended = () => {
      URL.revokeObjectURL(url);
      resolve();
    };
    
    audio.onerror = (error) => {
      URL.revokeObjectURL(url);
      reject(error);
    };
    
    audio.play().catch(reject);
  });
}

/**
 * Gets available voices from ElevenLabs
 */
export async function getVoices(): Promise<any> {
  try {
    validateConfig();

    const url = 'https://api.elevenlabs.io/v1/voices';
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'xi-api-key': config.apiKey
      }
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      const errorMessage = errorData?.detail?.message || await response.text();
      throw new Error(`ElevenLabs API error (${response.status}): ${errorMessage}`);
    }

    return response.json();
  } catch (error) {
    console.error('Error fetching ElevenLabs voices:', error);
    throw error;
  }
}