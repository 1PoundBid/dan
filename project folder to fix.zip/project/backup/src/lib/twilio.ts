import { supabase } from './supabase';

interface TwilioConfig {
  account_sid: string;
  auth_token: string;
  phone_number: string;
}

let cachedConfig: TwilioConfig | null = null;

export const getTwilioConfig = async (): Promise<TwilioConfig> => {
  try {
    if (cachedConfig) {
      return cachedConfig;
    }

    const { data, error } = await supabase
      .from('twilio_config')
      .select('*')
      .limit(1)
      .single();

    if (error) {
      if (error.code === '42P01') { // Table does not exist
        throw new Error('Twilio configuration table not found. Please run the database migrations.');
      }
      throw new Error(`Failed to load Twilio configuration: ${error.message}`);
    }

    if (!data) {
      throw new Error('Please configure your Twilio settings in the Settings page first.');
    }

    if (!data.account_sid || !data.auth_token || !data.phone_number) {
      throw new Error('Invalid Twilio configuration. Please check all required fields.');
    }

    cachedConfig = data;
    return data;
  } catch (error) {
    console.error('Error loading Twilio config:', error);
    throw error instanceof Error ? error : new Error('Failed to load Twilio configuration');
  }
};

export const sendSMS = async (to: string, message: string) => {
  try {
    const config = await getTwilioConfig();

    const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${config.account_sid}/Messages.json`, {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + btoa(`${config.account_sid}:${config.auth_token}`),
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams({
        To: to,
        From: config.phone_number,
        Body: message
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to send SMS');
    }

    return await response.json();
  } catch (error) {
    console.error('Error sending SMS:', error);
    if (error instanceof Error && error.message.includes('configuration')) {
      throw error; // Re-throw configuration errors as-is
    }
    throw new Error('Failed to send SMS. Please check your Twilio configuration and try again.');
  }
};