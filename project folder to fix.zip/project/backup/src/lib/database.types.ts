export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      customers: {
        Row: {
          id: string
          bidder_number: string
          first_name: string
          last_name: string
          email: string | null
          balance: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          bidder_number: string
          first_name: string
          last_name: string
          email?: string | null
          balance?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          bidder_number?: string
          first_name?: string
          last_name?: string
          email?: string | null
          balance?: number | null
          created_at?: string
          updated_at?: string
        }
      }
      orders: {
        Row: {
          id: string
          customer_id: string
          recorded_at: string
          item_code: string
          item_name: string
          quantity: number
          debit: number
          credit: number
          status: 'unprocessed' | 'in_tray' | 'in_box' | 'shipped'
          processed_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          customer_id: string
          recorded_at: string
          item_code: string
          item_name: string
          quantity?: number
          debit?: number
          credit?: number
          status?: 'unprocessed' | 'in_tray' | 'in_box' | 'shipped'
          processed_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          customer_id?: string
          recorded_at?: string
          item_code?: string
          item_name?: string
          quantity?: number
          debit?: number
          credit?: number
          status?: 'unprocessed' | 'in_tray' | 'in_box' | 'shipped'
          processed_at?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      shipped_boxes: {
        Row: {
          id: string
          customer_id: string
          type: 'single' | 'small' | 'big'
          weight: number
          price: number
          created_at: string
          archived: boolean
        }
        Insert: {
          id?: string
          customer_id: string
          type: 'single' | 'small' | 'big'
          weight: number
          price: number
          archived?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          customer_id?: string
          type?: 'single' | 'small' | 'big'
          weight?: number
          price?: number
          archived?: boolean
          created_at?: string
        }
      }
      shipped_box_items: {
        Row: {
          id: string
          box_id: string
          order_id: string
          created_at: string
        }
        Insert: {
          id?: string
          box_id: string
          order_id: string
          created_at?: string
        }
        Update: {
          id?: string
          box_id?: string
          order_id?: string
          created_at?: string
        }
      }
      storage_items: {
        Row: {
          id: string
          customer_id: string
          type: 'bag_cage' | 'box_shelf'
          created_at: string
        }
        Insert: {
          id?: string
          customer_id: string
          type: 'bag_cage' | 'box_shelf'
          created_at?: string
        }
        Update: {
          id?: string
          customer_id?: string
          type?: 'bag_cage' | 'box_shelf'
          created_at?: string
        }
      }
      twilio_config: {
        Row: {
          id: string
          account_sid: string
          auth_token: string
          phone_number: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          account_sid: string
          auth_token: string
          phone_number: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          account_sid?: string
          auth_token?: string
          phone_number?: string
          created_at?: string
          updated_at?: string
        }
      }
      box_orders: {
        Row: {
          id: string
          customer_name: string
          email: string
          box_type: string
          price: number
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          customer_name: string
          email: string
          box_type: string
          price: number
          status?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          customer_name?: string
          email?: string
          box_type?: string
          price?: number
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
      sms_replies: {
        Row: {
          id: string
          from_number: string
          to_number: string
          message: string
          created_at: string
          read: boolean
        }
        Insert: {
          id?: string
          from_number: string
          to_number: string
          message: string
          created_at?: string
          read?: boolean
        }
        Update: {
          id?: string
          from_number?: string
          to_number?: string
          message?: string
          created_at?: string
          read?: boolean
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_and_add_price_column: {
        Args: Record<PropertyKey, never>
        Returns: void
      }
      process_box: {
        Args: {
          p_customer_id: string
          p_box_type: string
          p_weight: number
          p_order_ids: string[]
        }
        Returns: string
      }
      can_process_orders: {
        Args: {
          p_order_ids: string[]
        }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
  }
}