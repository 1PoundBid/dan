import { supabase } from './supabase';

export async function testSupabaseConnection() {
  try {
    // Try to get a single customer to test connection
    const { data, error } = await supabase
      .from('customers')
      .select('id')
      .limit(1);

    if (error) {
      console.error('Supabase connection error:', error);
      return {
        connected: false,
        error: error.message,
        url: supabase.supabaseUrl // Use the URL property directly
      };
    }

    return {
      connected: true,
      url: supabase.supabaseUrl
    };
  } catch (error) {
    console.error('Supabase test error:', error);
    return {
      connected: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      url: supabase.supabaseUrl
    };
  }
}