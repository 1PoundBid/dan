/**
 * Get the appropriate CSS color class for an order status
 */
export function getStatusColor(status: string): string {
  switch (status) {
    case 'in_tray':
      return 'bg-green-100 text-green-800';
    case 'in_box':
      return 'bg-blue-100 text-blue-800';
    case 'shipped':
      return 'bg-purple-100 text-purple-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

/**
 * Format a status string for display
 */
export function formatStatus(status: string): string {
  return status.replace('_', ' ').toUpperCase();
}

/**
 * Get the appropriate box type color
 */
export function getBoxTypeColor(type: string): string {
  switch (type) {
    case 'single':
      return 'bg-blue-100 text-blue-600';
    case 'small':
      return 'bg-green-100 text-green-600';
    case 'big':
      return 'bg-purple-100 text-purple-600';
    default:
      return 'bg-gray-100 text-gray-600';
  }
}