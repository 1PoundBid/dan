/**
 * Speech utility that uses ElevenLabs for voice synthesis with browser fallback
 */
export async function speak(text: string) {
  // Skip empty text
  if (!text?.trim()) return;
  
  // Import dynamically to avoid loading ElevenLabs code if not needed
  const { textToSpeech, playAudio } = await import('../lib/elevenlabs');
  
  try {
    // Try to use ElevenLabs first
    const audioData = await textToSpeech(text);
    await playAudio(audioData);
  } catch (error) {
    // Log the error but don't show to user since we'll fall back to browser speech
    console.warn('ElevenLabs unavailable, falling back to browser speech:', error);
    
    // Fall back to browser speech synthesis
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utterance);
    }
  }
}