import React from 'react';
import { Package, Settings, Search, RefreshCw, Home, Upload, Users, Archive, Box, MessageSquare, ShoppingBag, Mail, Boxes } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { testSupabaseConnection } from '../lib/test-connection';
import { useEffect, useState } from 'react';

// Get environment from Supabase URL
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const isProduction = supabaseUrl ? supabaseUrl.includes('wdahgclackfaifkhrell') : false;

export function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const [connectionStatus, setConnectionStatus] = useState<{
    connected: boolean;
    error?: string;
    url?: string;
  } | null>(null);

  useEffect(() => {
    testConnection();
  }, []);

  const testConnection = async () => {
    const status = await testSupabaseConnection();
    setConnectionStatus(status);
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Environment Banner */}
      {!isProduction && (
        <div className="fixed top-0 left-0 w-full bg-yellow-500 text-yellow-900 text-center py-1 font-bold z-50">
          DEVELOPMENT ENVIRONMENT - Test System
          {connectionStatus && (
            <span className="ml-2">
              {connectionStatus.connected ? (
                <span className="text-green-800">● Connected</span>
              ) : (
                <span className="text-red-800">● Not Connected: {connectionStatus.error}</span>
              )}
            </span>
          )}
        </div>
      )}
      {isProduction && (
        <div className="fixed top-0 left-0 w-full bg-green-600 text-white text-center py-1 font-bold z-50">
          LIVE SYSTEM
          {connectionStatus && (
            <span className="ml-2">
              {connectionStatus.connected ? (
                <span className="text-white">● Connected</span>
              ) : (
                <span className="text-red-200">● Not Connected: {connectionStatus.error}</span>
              )}
            </span>
          )}
        </div>
      )}

      {/* Sidebar - adjusted top padding for banner */}
      <div className="w-64 bg-blue-600 shadow-lg mt-8">
        <div className="p-4 border-b border-blue-500">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Package className="h-6 w-6 text-blue-100" />
              1PoundBid Center
            </h1>
          </div>
        </div>
        
        <nav className="p-4">
          <ul className="space-y-2">
            <li>
              <Link
                to="/"
                className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
                  isActive('/') ? 'bg-blue-700 text-white font-medium' : ''
                }`}
              >
                <Home className="h-5 w-5" />
                Dashboard
              </Link>
            </li>
            <li>
              <Link
                to="/upload"
                className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
                  isActive('/upload') ? 'bg-blue-700 text-white font-medium' : ''
                }`}
              >
                <Upload className="h-5 w-5" />
                Upload Orders
              </Link>
            </li>
            <li>
              <Link
                to="/customers"
                className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
                  isActive('/customers') ? 'bg-blue-700 text-white font-medium' : ''
                }`}
              >
                <Users className="h-5 w-5" />
                Customers
              </Link>
            </li>
            <li>
              <Link
                to="/archived-boxes"
                className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
                  isActive('/archived-boxes') ? 'bg-blue-700 text-white font-medium' : ''
                }`}
              >
                <Archive className="h-5 w-5" />
                Archived Boxes
              </Link>
            </li>
            <li>
              <Link
                to="/box-orders"
                className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
                  isActive('/box-orders') ? 'bg-blue-700 text-white font-medium' : ''
                }`}
              >
                <Box className="h-5 w-5" />
                Box Orders
              </Link>
            </li>
            <li>
              <Link
                to="/order-box"
                className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
                  isActive('/order-box') ? 'bg-blue-700 text-white font-medium' : ''
                }`}
              >
                <ShoppingBag className="h-5 w-5" />
                Order a Box
              </Link>
            </li>
            <li>
              <Link
                to="/contact"
                className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
                  isActive('/contact') ? 'bg-blue-700 text-white font-medium' : ''
                }`}
              >
                <Mail className="h-5 w-5" />
                Contact Us
              </Link>
            </li>
            <li>
              <Link
                to="/inquiries"
                className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
                  isActive('/inquiries') ? 'bg-blue-700 text-white font-medium' : ''
                }`}
              >
                <MessageSquare className="h-5 w-5" />
                Inquiries
              </Link>
            </li>
            <li>
              <Link
                to="/stock-sorting"
                className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
                  isActive('/stock-sorting') ? 'bg-blue-700 text-white font-medium' : ''
                }`}
              >
                <Boxes className="h-5 w-5" />
                How to Sort Stock
              </Link>
            </li>
          </ul>
        </nav>

        <div className="absolute bottom-0 w-64 p-4 border-t border-blue-500">
          <Link
            to="/settings"
            className={`w-full flex items-center gap-3 px-4 py-2 text-blue-100 rounded-lg hover:bg-blue-500 ${
              isActive('/settings') ? 'bg-blue-700 text-white font-medium' : ''
            }`}
          >
            <Settings className="h-5 w-5" />
            Settings
          </Link>
        </div>
      </div>

      {/* Main Content - adjusted top padding for banner */}
      <div className="flex-1 overflow-hidden mt-8">
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-4 flex-1">
              <div className="relative flex-1 max-w-md">
                <input
                  type="text"
                  placeholder="Search orders..."
                  className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
              <button 
                onClick={testConnection}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-800"
              >
                <RefreshCw className={`h-5 w-5 ${connectionStatus === null ? 'animate-spin' : ''}`} />
                {connectionStatus === null ? 'Testing...' : 'Test Connection'}
              </button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-6 overflow-auto h-[calc(100vh-4rem)]">
          {children}
        </div>
      </div>
    </div>
  );
}