import React, { useRef, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { speak } from '../utils/speech';
import { Scan, Box, Inbox, Package, Clock, Scale, Archive, Trash2, AlertCircle, RefreshCw } from 'lucide-react';
import { lookupItem, updateItemStatus, supabase } from '../lib/supabase';
import { LoadingSpinner } from '../components/LoadingSpinner';

interface ShippedBox {
  id: string;
  type: 'single' | 'small' | 'big';
  weight: number;
  created_at: string;
  customer: {
    id: string;
    first_name: string;
    last_name: string;
    bidder_number: string;
  };
  items: {
    id: string;
    item_code: string;
    item_name: string;
    processed_at: string | null;
  }[];
}

const getBoxTypeColor = (type: string) => {
  switch (type) {
    case 'single':
      return 'bg-blue-100 text-blue-600';
    case 'small':
      return 'bg-green-100 text-green-600';
    case 'big':
      return 'bg-purple-100 text-purple-600';
    default:
      return 'bg-gray-100 text-gray-600';
  }
};

export function Dashboard() {
  const lookupRef = useRef<HTMLInputElement>(null);
  const trayRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [shippedBoxes, setShippedBoxes] = useState<ShippedBox[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    lookupRef.current?.focus();
    fetchShippedBoxes();
  }, []);

  const fetchShippedBoxes = async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: boxesData, error: boxesError } = await supabase
        .from('shipped_boxes')
        .select(`
          id,
          type,
          weight,
          created_at,
          archived,
          customer:customer_id (
            id,
            first_name,
            last_name,
            bidder_number
          ),
          shipped_box_items!inner (
            order:order_id (
              id,
              item_code,
              item_name,
              processed_at
            )
          )
        `)
        .eq('archived', false)  // Only fetch non-archived boxes
        .order('created_at', { ascending: false });

      if (boxesError) throw boxesError;

      // Process the data to make it easier to work with
      const processedBoxes = boxesData.map(box => ({
        id: box.id,
        type: box.type,
        weight: box.weight,
        created_at: box.created_at,
        customer: box.customer,
        items: box.shipped_box_items.map(item => ({
          id: item.order.id,
          item_code: item.order.item_code,
          item_name: item.order.item_name,
          processed_at: item.order.processed_at
        }))
      }));

      setShippedBoxes(processedBoxes);
      setError(null);
    } catch (error) {
      console.error('Error fetching shipped boxes:', error);
      setError('Failed to fetch shipped boxes. Please try refreshing.');
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    fetchShippedBoxes();
  };

  const handleArchiveBox = async (box: ShippedBox) => {
    try {
      // Update the box to mark it as archived
      const { error: updateError } = await supabase
        .from('shipped_boxes')
        .update({ archived: true })
        .eq('id', box.id);

      if (updateError) throw updateError;

      // Remove box from the local state
      setShippedBoxes(prev => prev.filter(b => b.id !== box.id));
      speak(`Box archived for ${box.customer.first_name} ${box.customer.last_name}`);
    } catch (error) {
      console.error('Error archiving box:', error);
      const message = error instanceof Error ? error.message : 'Error archiving box';
      setError(message);
      speak(message);
    }
  };

  const handleDeleteBox = async (boxId: string) => {
    try {
      const { error: deleteError } = await supabase
        .from('shipped_boxes')
        .delete()
        .eq('id', boxId);

      if (deleteError) throw deleteError;

      setShippedBoxes(prev => prev.filter(box => box.id !== boxId));
      speak('Box deleted successfully');
    } catch (error) {
      console.error('Error deleting box:', error);
      const message = error instanceof Error ? error.message : 'Error deleting box';
      setError(message);
      speak(message);
    }
  };

  const handleScan = async (
    ref: React.RefObject<HTMLInputElement>,
    handler: (barcode: string) => Promise<void>
  ) => {
    setError(null);
    const value = ref.current?.value || '';
    
    if (!value.trim()) {
      setError('Please scan a barcode');
      speak('Please scan a barcode');
      return;
    }

    try {
      await handler(value);
      if (ref.current) {
        ref.current.value = '';
        ref.current.focus();
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Error scanning item';
      console.error('Scan error:', err);
      speak(message);
      setError(message);
      if (ref.current) {
        ref.current.select();
      }
    }
  };

  const handleKeyPress = (
    e: React.KeyboardEvent<HTMLInputElement>,
    ref: React.RefObject<HTMLInputElement>,
    handler: (barcode: string) => Promise<void>
  ) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleScan(ref, handler);
    }
  };

  const handleLookup = async (barcode: string) => {
    const item = await lookupItem(barcode);
    const fullName = `${item.customer.first_name} ${item.customer.last_name}`;
    speak(`This item belongs to ${fullName}`);
    navigate(`/customers/${item.customer.id}`);
  };

  const handleTray = async (barcode: string) => {
    const item = await updateItemStatus(barcode, 'in_tray');
    const fullName = `${item.customer.first_name} ${item.customer.last_name}`;
    speak(`Item scanned into tray for ${fullName}`);
    navigate(`/customers/${item.customer.id}`);
  };

  const handleBox = async (barcode: string) => {
    const item = await updateItemStatus(barcode, 'in_box');
    const fullName = `${item.customer.first_name} ${item.customer.last_name}`;
    speak(`Item packed into box for ${fullName}`);
    navigate(`/customers/${item.customer.id}`);
  };

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {/* Item Lookup */}
        <div className="relative">
          <div className="absolute -top-3 left-4 px-2 bg-gray-100 rounded">
            <div className="flex items-center gap-2">
              <Scan className="h-4 w-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-800">Item Lookup</span>
            </div>
          </div>
          <div className="bg-gray-100 rounded-lg p-4 pt-6">
            <input
              ref={lookupRef}
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-300 focus:border-gray-400 focus:ring-0"
              placeholder="Scan barcode..."
              onKeyPress={(e) => handleKeyPress(e, lookupRef, handleLookup)}
            />
          </div>
        </div>

        {/* Scan to Tray */}
        <div className="relative">
          <div className="absolute -top-3 left-4 px-2 bg-green-50 rounded">
            <div className="flex items-center gap-2">
              <Inbox className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium text-green-800">Scan to Tray</span>
            </div>
          </div>
          <div className="bg-green-50 rounded-lg p-4 pt-6">
            <input
              ref={trayRef}
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-green-300 focus:border-green-400 focus:ring-0"
              placeholder="Scan barcode..."
              onKeyPress={(e) => handleKeyPress(e, trayRef, handleTray)}
            />
          </div>
        </div>

        {/* Scan to Box */}
        <div className="relative">
          <div className="absolute -top-3 left-4 px-2 bg-blue-50 rounded">
            <div className="flex items-center gap-2">
              <Box className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-800">Scan to Box</span>
            </div>
          </div>
          <div className="bg-blue-50 rounded-lg p-4 pt-6">
            <input
              ref={boxRef}
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-blue-300 focus:border-blue-400 focus:ring-0"
              placeholder="Scan barcode..."
              onKeyPress={(e) => handleKeyPress(e, boxRef, handleBox)}
            />
          </div>
        </div>
      </div>

      {/* Shipped Boxes Summary */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Package className="h-6 w-6 text-gray-600" />
            <h2 className="text-xl font-semibold text-gray-800">Boxes Ready for Delivery</h2>
          </div>
          <button 
            onClick={handleRefresh}
            className="flex items-center gap-2 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>{isRefreshing ? 'Refreshing...' : 'Refresh'}</span>
          </button>
        </div>

        {loading ? (
          <LoadingSpinner />
        ) : shippedBoxes.length === 0 ? (
          <div className="bg-white rounded-lg shadow-lg p-6 text-center text-gray-500">
            No boxes ready for delivery
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {shippedBoxes.map((box) => (
              <div key={box.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="p-6">
                  <div className="flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`p-2 rounded-lg ${getBoxTypeColor(box.type)}`}>
                          <Box className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">
                            {box.customer.first_name} {box.customer.last_name}
                          </div>
                          <div className="text-sm text-gray-500">
                            Bidder #: {box.customer.bidder_number}
                          </div>
                          <div className="text-sm text-gray-500">
                            Created on {new Date(box.created_at).toLocaleString()}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-sm font-medium text-gray-700">
                          {box.type.charAt(0).toUpperCase() + box.type.slice(1)} Box
                        </div>
                        <div className="flex items-center gap-2 text-gray-600">
                          <Scale className="h-5 w-5" />
                          <span>{box.weight}kg</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleArchiveBox(box)}
                            className="p-2 text-green-600 hover:text-green-700 hover:bg-green-50 rounded-lg"
                            title="Archive Box"
                          >
                            <Archive className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteBox(box.id)}
                            className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg"
                            title="Delete Box"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {box.items.map((item) => (
                        <div
                          key={item.id}
                          className="inline-flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-gray-700"
                        >
                          <Package className="h-4 w-4 text-gray-500" />
                          <span>{item.item_code}</span>
                          <span className="text-gray-400">-</span>
                          <span>{item.item_name}</span>
                          {item.processed_at && (
                            <span className="text-xs text-gray-500">
                              ({new Date(item.processed_at).toLocaleString()})
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}