import React from 'react';
import { AlertCircle } from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { LoadingSpinner } from '../LoadingSpinner';

// Import custom hooks
import { useCustomerData } from '../../hooks/useCustomerData';
import { useScanningHandlers } from '../../hooks/useScanningHandlers';
import { useStorageManagement } from '../../hooks/useStorageManagement';
import { useBoxProcessing } from '../../hooks/useBoxProcessing';
import { useOrdersManagement } from '../../hooks/useOrdersManagement';

// Import components
import { CustomerHeader } from './CustomerHeader';
import { ScanningSection } from './ScanningSection';
import { ManagementButtons } from './ManagementButtons';
import { AccountSummary } from './AccountSummary';
import { StorageItemsList } from './StorageItemsList';
import { BoxModal } from './BoxModal';
import { OrdersTable } from './OrdersTable';
import { ShippedBoxesList } from './ShippedBoxesList';

export function CustomerDetailsExample() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  // Use custom hooks
  const { 
    customer, 
    orders, 
    storageItems, 
    shippedBoxes, 
    loading, 
    error: dataError, 
    accountSummary,
    refreshData
  } = useCustomerData(id);

  const { 
    error: scanError, 
    setError: setScanError, 
    handleLookup, 
    handleTray, 
    handleBox 
  } = useScanningHandlers(id, (customerId) => navigate(`/customers/${customerId}`));

  const {
    error: storageError,
    setError: setStorageError,
    handleAddBagToCage,
    handleAddBoxToShelf,
    handleDeleteStorageItem
  } = useStorageManagement(id, refreshData);

  const boxItemIds = orders
    .filter(order => order.status === 'in_box')
    .map(order => order.id);

  const {
    error: boxError,
    setError: setBoxError,
    showBoxModal,
    setShowBoxModal,
    handleBoxFull,
    handleBoxFullSubmit
  } = useBoxProcessing(id, boxItemIds, refreshData);

  const {
    selectedOrders,
    error: ordersError,
    handleSelectOrder,
    handleSelectAllOrders,
    handleDeleteSelected
  } = useOrdersManagement(refreshData);

  // Combine all errors
  const error = dataError || scanError || storageError || boxError || ordersError;
  const setError = (message: string | null) => {
    setScanError(message);
    setStorageError(message);
    setBoxError(message);
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!customer) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <AlertCircle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800">Customer Not Found</h2>
          <p className="text-gray-600 mt-2">The requested customer could not be found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      {/* Customer Info Card */}
      <CustomerHeader customer={customer} />

      {/* Scanning Fields */}
      <ScanningSection 
        onLookupScan={handleLookup}
        onTrayScan={handleTray}
        onBoxScan={handleBox}
      />

      {/* Management Buttons */}
      <ManagementButtons
        onAddBagToCage={handleAddBagToCage}
        onBoxFull={handleBoxFull}
        onAddBoxToShelf={handleAddBoxToShelf}
      />

      {/* Account Summary */}
      <AccountSummary
        unprocessedOrders={accountSummary.unprocessedOrders}
        bagsInCage={accountSummary.bagsInCage}
        boxesOnShelf={accountSummary.boxesOnShelf}
        itemsInTray={accountSummary.itemsInTray}
        itemsInBox={accountSummary.itemsInBox}
        daysSinceLastOrder={accountSummary.daysSinceLastOrder}
      />

      {/* Storage Items */}
      <StorageItemsList
        items={storageItems}
        onDeleteItem={handleDeleteStorageItem}
      />

      {/* Box Full Modal */}
      <BoxModal
        isOpen={showBoxModal}
        onClose={() => setShowBoxModal(false)}
        onSubmit={handleBoxFullSubmit}
      />

      {/* Orders Table */}
      <OrdersTable
        orders={orders}
        selectedOrders={selectedOrders}
        onSelectOrder={handleSelectOrder}
        onSelectAllOrders={handleSelectAllOrders}
        onDeleteSelected={handleDeleteSelected}
      />

      {/* Shipped Boxes */}
      <ShippedBoxesList boxes={shippedBoxes} />
    </div>
  );
}