import React from 'react';
import { Trash2 } from 'lucide-react';

interface StorageItem {
  id: string;
  type: 'bag_cage' | 'box_shelf';
  created_at: string;
}

interface StorageItemsListProps {
  items: StorageItem[];
  onDeleteItem: (itemId: string) => void;
}

export function StorageItemsList({ items, onDeleteItem }: StorageItemsListProps) {
  if (items.length === 0) return null;
  
  return (
    <div className="space-y-2">
      {items.map(item => (
        <div
          key={item.id}
          className={`flex items-center justify-between p-4 rounded-lg ${
            item.type === 'bag_cage' ? 'bg-pink-100' : 'bg-orange-100'
          }`}
        >
          <div className="flex items-center gap-4">
            <input
              type="checkbox"
              className="rounded border-gray-300"
            />
            <span className="font-medium">
              {item.type === 'bag_cage' ? 'Bag added to cage' : 'Box added to shelf'}
            </span>
          </div>
          <button
            onClick={() => onDeleteItem(item.id)}
            className="text-red-600 hover:text-red-700"
          >
            <Trash2 className="h-5 w-5" />
          </button>
        </div>
      ))}
    </div>
  );
}