import React, { useRef } from 'react';
import { Scan, Inbox, Box } from 'lucide-react';

interface ScanningSectionProps {
  onLookupScan: (barcode: string) => Promise<void>;
  onTrayScan: (barcode: string) => Promise<void>;
  onBoxScan: (barcode: string) => Promise<void>;
}

export function ScanningSection({ onLookupScan, onTrayScan, onBoxScan }: ScanningSectionProps) {
  const lookupRef = useRef<HTMLInputElement>(null);
  const trayRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLInputElement>(null);

  const handleKeyPress = async (
    e: React.KeyboardEvent<HTMLInputElement>,
    ref: React.RefObject<HTMLInputElement>,
    handler: (barcode: string) => Promise<void>
  ) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const value = ref.current?.value || '';
      if (!value.trim()) return;
      
      try {
        await handler(value);
        if (ref.current) {
          ref.current.value = '';
          ref.current.focus();
        }
      } catch (err) {
        if (ref.current) {
          ref.current.select();
        }
      }
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
      {/* Item Lookup */}
      <div className="relative">
        <div className="absolute -top-3 left-4 px-2 bg-gray-100 rounded">
          <div className="flex items-center gap-2">
            <Scan className="h-4 w-4 text-gray-600" />
            <span className="text-sm font-medium text-gray-800">Item Lookup</span>
          </div>
        </div>
        <div className="bg-gray-100 rounded-lg p-4 pt-6">
          <input
            ref={lookupRef}
            type="text"
            className="w-full px-4 py-3 rounded-lg border-2 border-gray-300 focus:border-gray-400 focus:ring-0"
            placeholder="Scan barcode..."
            onKeyPress={(e) => handleKeyPress(e, lookupRef, onLookupScan)}
          />
        </div>
      </div>

      {/* Scan to Tray */}
      <div className="relative">
        <div className="absolute -top-3 left-4 px-2 bg-green-50 rounded">
          <div className="flex items-center gap-2">
            <Inbox className="h-4 w-4 text-green-600" />
            <span className="text-sm font-medium text-green-800">Scan to Tray</span>
          </div>
        </div>
        <div className="bg-green-50 rounded-lg p-4 pt-6">
          <input
            ref={trayRef}
            type="text"
            className="w-full px-4 py-3 rounded-lg border-2 border-green-300 focus:border-green-400 focus:ring-0"
            placeholder="Scan barcode..."
            onKeyPress={(e) => handleKeyPress(e, trayRef, onTrayScan)}
          />
        </div>
      </div>

      {/* Scan to Box */}
      <div className="relative">
        <div className="absolute -top-3 left-4 px-2 bg-blue-50 rounded">
          <div className="flex items-center gap-2">
            <Box className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-800">Scan to Box</span>
          </div>
        </div>
        <div className="bg-blue-50 rounded-lg p-4 pt-6">
          <input
            ref={boxRef}
            type="text"
            className="w-full px-4 py-3 rounded-lg border-2 border-blue-300 focus:border-blue-400 focus:ring-0"
            placeholder="Scan barcode..."
            onKeyPress={(e) => handleKeyPress(e, boxRef, onBoxScan)}
          />
        </div>
      </div>
    </div>
  );
}