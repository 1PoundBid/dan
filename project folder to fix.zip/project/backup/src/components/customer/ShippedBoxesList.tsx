import React from 'react';
import { Package, Box } from 'lucide-react';

interface ShippedBoxItem {
  id: string;
  item_code: string;
  item_name: string;
  status: string;
  processed_at: string | null;
}

interface ShippedBox {
  id: string;
  type: 'single' | 'small' | 'big';
  weight: number;
  created_at: string;
  items: ShippedBoxItem[];
}

interface ShippedBoxesListProps {
  boxes: ShippedBox[];
}

export function ShippedBoxesList({ boxes }: ShippedBoxesListProps) {
  if (boxes.length === 0) return null;
  
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">Boxes Sent Out</h2>
      </div>
      <div className="divide-y divide-gray-200">
        {boxes.map((box) => (
          <div key={box.id} className="p-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-lg font-medium text-gray-900">
                  {box.type.charAt(0).toUpperCase() + box.type.slice(1)} Box
                </h3>
                <p className="text-sm text-gray-500">
                  Shipped on {new Date(box.created_at).toLocaleDateString()}
                </p>
                <p className="text-sm text-gray-500">
                  Weight: {box.weight}kg
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {box.items.map((item) => (
                <div
                  key={item.id}
                  className="inline-flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-gray-700"
                >
                  <Package className="h-4 w-4 text-gray-500" />
                  <span>{item.item_code}</span>
                  <span className="text-gray-400">-</span>
                  <span>{item.item_name}</span>
                  {item.processed_at && (
                    <span className="text-xs text-gray-500">
                      ({new Date(item.processed_at).toLocaleString()})
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}