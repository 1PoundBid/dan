import React from 'react';

interface ManagementButtonsProps {
  onAddBagToCage: () => void;
  onBoxFull: () => void;
  onAddBoxToShelf: () => void;
}

export function ManagementButtons({ 
  onAddBagToCage, 
  onBoxFull, 
  onAddBoxToShelf 
}: ManagementButtonsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <button
        onClick={onAddBagToCage}
        className="px-4 py-3 bg-pink-500 text-white rounded-lg hover:bg-pink-600 font-medium"
      >
        Add Bag to Cage
      </button>
      <button
        onClick={onBoxFull}
        className="px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 font-medium"
      >
        Box Full
      </button>
      <button
        onClick={onAddBoxToShelf}
        className="px-4 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 font-medium"
      >
        Add Box to Shelf
      </button>
    </div>
  );
}