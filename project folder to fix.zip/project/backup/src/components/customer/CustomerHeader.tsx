import React from 'react';
import { Mail } from 'lucide-react';
import type { Customer } from '../../types';

interface CustomerHeaderProps {
  customer: Customer | null;
}

export function CustomerHeader({ customer }: CustomerHeaderProps) {
  if (!customer) return null;
  
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            {customer.first_name} {customer.last_name}
          </h1>
          <div className="mt-2 space-y-2">
            <div className="text-gray-600">
              Bidder #: <span className="font-medium">{customer.bidder_number}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <Mail className="h-4 w-4 mr-2" />
              <a href={`mailto:${customer.email}`} className="hover:text-blue-600">
                {customer.email}
              </a>
            </div>
            <div className="text-gray-600">
              Balance: <span className="font-medium">${customer.balance?.toFixed(2) ?? '0.00'}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}