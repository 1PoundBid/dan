import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { speak } from '../utils/speech';

export function useStorageManagement(customerId: string | undefined, onRefresh: () => void) {
  const [error, setError] = useState<string | null>(null);

  const handleAddBagToCage = async () => {
    if (!customerId) return;
    
    try {
      const { data, error } = await supabase
        .from('storage_items')
        .insert({
          customer_id: customerId,
          type: 'bag_cage',
          created_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      
      speak('Bag has been added to the cage');
      onRefresh();
      return data;
    } catch (error) {
      console.error('Error adding bag to cage:', error);
      const message = error instanceof Error ? error.message : 'Error adding bag to cage';
      setError(message);
      speak(message);
      throw error;
    }
  };

  const handleAddBoxToShelf = async () => {
    if (!customerId) return;
    
    try {
      const { data, error } = await supabase
        .from('storage_items')
        .insert({
          customer_id: customerId,
          type: 'box_shelf',
          created_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      
      speak('Box has been added to the shelf');
      onRefresh();
      return data;
    } catch (error) {
      console.error('Error adding box to shelf:', error);
      const message = error instanceof Error ? error.message : 'Error adding box to shelf';
      setError(message);
      speak(message);
      throw error;
    }
  };

  const handleDeleteStorageItem = async (itemId: string) => {
    try {
      const { error } = await supabase
        .from('storage_items')
        .delete()
        .eq('id', itemId);

      if (error) throw error;
      
      onRefresh();
    } catch (error) {
      console.error('Error deleting storage item:', error);
      const message = error instanceof Error ? error.message : 'Error deleting storage item';
      setError(message);
      speak(message);
      throw error;
    }
  };

  return {
    error,
    setError,
    handleAddBagToCage,
    handleAddBoxToShelf,
    handleDeleteStorageItem
  };
}