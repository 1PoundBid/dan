import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { getShippedBoxes } from '../lib/supabase';

interface Customer {
  id: string;
  bidder_number: string;
  first_name: string;
  last_name: string;
  email: string;
  balance: number | null;
}

interface Order {
  id: string;
  item_code: string;
  item_name: string;
  status: string;
  processed_at: string | null;
  created_at: string;
}

interface StorageItem {
  id: string;
  type: 'bag_cage' | 'box_shelf';
  created_at: string;
}

interface ShippedBox {
  id: string;
  type: 'single' | 'small' | 'big';
  weight: number;
  created_at: string;
  items: {
    id: string;
    item_code: string;
    item_name: string;
    status: string;
    processed_at: string | null;
  }[];
}

interface AccountSummary {
  unprocessedOrders: number;
  bagsInCage: number;
  boxesOnShelf: number;
  itemsInTray: number;
  itemsInBox: number;
  daysSinceLastOrder: number;
}

export function useCustomerData(customerId: string | undefined) {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [storageItems, setStorageItems] = useState<StorageItem[]>([]);
  const [shippedBoxes, setShippedBoxes] = useState<ShippedBox[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [accountSummary, setAccountSummary] = useState<AccountSummary>({
    unprocessedOrders: 0,
    bagsInCage: 0,
    boxesOnShelf: 0,
    itemsInTray: 0,
    itemsInBox: 0,
    daysSinceLastOrder: 0
  });

  const ordersChannelRef = useRef<RealtimeChannel | null>(null);
  const storageChannelRef = useRef<RealtimeChannel | null>(null);

  useEffect(() => {
    if (!customerId) return;
    
    fetchCustomerData();
    setupRealtimeSubscriptions();

    return () => {
      if (ordersChannelRef.current) {
        ordersChannelRef.current.unsubscribe();
      }
      if (storageChannelRef.current) {
        storageChannelRef.current.unsubscribe();
      }
    };
  }, [customerId]);

  const setupRealtimeSubscriptions = () => {
    if (!customerId) return;

    ordersChannelRef.current = supabase
      .channel('orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
          filter: `customer_id=eq.${customerId}`
        },
        () => {
          fetchOrders();
        }
      )
      .subscribe();

    storageChannelRef.current = supabase
      .channel('storage-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'storage_items',
          filter: `customer_id=eq.${customerId}`
        },
        () => {
          fetchStorageItems();
        }
      )
      .subscribe();
  };

  const calculateAccountSummary = (orders: Order[], storageItems: StorageItem[]) => {
    const unprocessedOrders = orders.filter(order => order.status === 'unprocessed').length;
    const itemsInTray = orders.filter(order => order.status === 'in_tray').length;
    const itemsInBox = orders.filter(order => order.status === 'in_box').length;
    const bagsInCage = storageItems.filter(item => item.type === 'bag_cage').length;
    const boxesOnShelf = storageItems.filter(item => item.type === 'box_shelf').length;

    const lastOrderDate = orders.length > 0
      ? Math.max(...orders.map(order => new Date(order.created_at).getTime()))
      : null;
    const daysSinceLastOrder = lastOrderDate
      ? Math.floor((Date.now() - lastOrderDate) / (1000 * 60 * 60 * 24))
      : 0;

    setAccountSummary({
      unprocessedOrders,
      bagsInCage,
      boxesOnShelf,
      itemsInTray,
      itemsInBox,
      daysSinceLastOrder
    });
  };

  const fetchOrders = async () => {
    if (!customerId) return;

    try {
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*')
        .eq('customer_id', customerId)
        .order('created_at', { ascending: false });

      if (ordersError) throw ordersError;
      setOrders(ordersData);
      calculateAccountSummary(ordersData, storageItems);
    } catch (error) {
      console.error('Error fetching orders:', error);
      setError('Failed to fetch orders');
    }
  };

  const fetchStorageItems = async () => {
    if (!customerId) return;

    try {
      const { data: storageData, error: storageError } = await supabase
        .from('storage_items')
        .select('*')
        .eq('customer_id', customerId)
        .order('created_at', { ascending: false });

      if (storageError) throw storageError;
      setStorageItems(storageData || []);
      calculateAccountSummary(orders, storageData || []);
    } catch (error) {
      console.error('Error fetching storage items:', error);
      setError('Failed to fetch storage items');
    }
  };

  const fetchShippedBoxes = async () => {
    if (!customerId) return;

    try {
      const boxes = await getShippedBoxes(customerId);
      setShippedBoxes(boxes);
    } catch (error) {
      console.error('Error fetching shipped boxes:', error);
      setError('Failed to fetch shipped boxes');
    }
  };

  const fetchCustomerData = async () => {
    if (!customerId) return;

    setLoading(true);
    setError(null);
    
    try {
      const { data: customerData, error: customerError } = await supabase
        .from('customers')
        .select('*')
        .eq('id', customerId)
        .single();

      if (customerError) throw customerError;
      setCustomer(customerData);

      await Promise.all([
        fetchOrders(),
        fetchStorageItems(),
        fetchShippedBoxes()
      ]);
    } catch (error) {
      console.error('Error fetching customer data:', error);
      setError('Failed to fetch customer data');
    } finally {
      setLoading(false);
    }
  };

  const refreshData = () => {
    fetchCustomerData();
  };

  return {
    customer,
    orders,
    storageItems,
    shippedBoxes,
    loading,
    error,
    accountSummary,
    refreshData,
    fetchOrders,
    fetchStorageItems,
    fetchShippedBoxes
  };
}