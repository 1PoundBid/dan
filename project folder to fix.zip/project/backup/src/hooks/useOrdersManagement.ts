import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { speak } from '../utils/speech';

export function useOrdersManagement(onRefresh: () => void) {
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleSelectOrder = (orderId: string, selected: boolean) => {
    setSelectedOrders(prev => 
      selected 
        ? [...prev, orderId] 
        : prev.filter(id => id !== orderId)
    );
  };

  const handleSelectAllOrders = (selected: boolean, orderIds: string[]) => {
    setSelectedOrders(selected ? [...orderIds] : []);
  };

  const handleDeleteSelected = async () => {
    if (selectedOrders.length === 0) return;
    
    try {
      const { error } = await supabase
        .from('orders')
        .delete()
        .in('id', selectedOrders);

      if (error) throw error;
      
      setSelectedOrders([]);
      onRefresh();
    } catch (error) {
      console.error('Error deleting orders:', error);
      const message = error instanceof Error ? error.message : 'Error deleting orders';
      setError(message);
      speak(message);
    }
  };

  return {
    selectedOrders,
    setSelectedOrders,
    error,
    setError,
    handleSelectOrder,
    handleSelectAllOrders,
    handleDeleteSelected
  };
}