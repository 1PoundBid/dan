-- Add weight validation constraint
ALTER TABLE shipped_boxes 
DROP CONSTRAINT IF EXISTS shipped_boxes_weight_check;

ALTER TABLE shipped_boxes 
ADD CONSTRAINT shipped_boxes_weight_check 
CHECK (weight > 0);

-- Verify the constraint exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.table_constraints
    WHERE table_name = 'shipped_boxes'
    AND constraint_name = 'shipped_boxes_weight_check'
  ) THEN
    RAISE EXCEPTION 'Weight validation constraint is missing!';
  END IF;
END $$;