/*
  # Fix customer inquiries policies and permissions

  1. Changes
    - Drop existing policies and triggers
    - Remove RLS temporarily
    - Create new simplified policy
    - Grant proper permissions

  2. Security
    - Allow all operations without complex policies
    - Maintain basic permissions model
*/

-- First drop the trigger that depends on the function
DROP TRIGGER IF EXISTS tr_customer_inquiry_delete ON customer_inquiries;

-- Now we can safely drop the function and policies
DROP FUNCTION IF EXISTS delete_customer_inquiry(uuid);
DROP FUNCTION IF EXISTS handle_customer_inquiry_delete();
DROP POLICY IF EXISTS "basic_access" ON customer_inquiries;
DROP POLICY IF EXISTS "enable_all_access" ON customer_inquiries;
DROP POLICY IF EXISTS "enable_insert_only" ON customer_inquiries;

-- Remove any existing RLS
ALTER TABLE customer_inquiries DISABLE ROW LEVEL SECURITY;

-- Re-enable RLS with simple policy
ALTER TABLE customer_inquiries ENABLE ROW LEVEL SECURITY;

-- Create a single policy that allows all operations
CREATE POLICY "allow_all_operations"
    ON customer_inquiries
    FOR ALL
    TO authenticated, anon
    USING (true)
    WITH CHECK (true);

-- Ensure proper permissions
GRANT ALL ON customer_inquiries TO authenticated;
GRANT INSERT, SELECT ON customer_inquiries TO anon;