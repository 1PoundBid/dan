/*
  # Fix customer inquiries delete permissions

  1. Changes
    - Drop and recreate policies for customer_inquiries table
    - Ensure proper delete permissions for authenticated users
    - Add explicit policies for different operations

  2. Security
    - Maintain RLS protection
    - Allow authenticated users to delete inquiries
*/

-- First check and drop policies if they exist
DO $$ 
BEGIN
    -- Drop existing policies if they exist
    DROP POLICY IF EXISTS "allow_delete_for_authenticated" ON customer_inquiries;
    DROP POLICY IF EXISTS "allow_select_for_all" ON customer_inquiries;
    DROP POLICY IF EXISTS "allow_insert_for_anon" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable full access for authenticated users" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable insert for anon" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable read for all" ON customer_inquiries;
    DROP POLICY IF EXISTS "Enable write for authenticated" ON customer_inquiries;
END $$;

-- Create new policies with explicit delete permissions
DO $$ 
BEGIN
    -- Create delete policy
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_policies 
        WHERE schemaname = 'public' 
        AND tablename = 'customer_inquiries'
        AND policyname = 'allow_delete_for_authenticated'
    ) THEN
        CREATE POLICY "allow_delete_for_authenticated"
            ON customer_inquiries
            FOR DELETE
            TO authenticated
            USING (true);
    END IF;

    -- Create select policy
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_policies 
        WHERE schemaname = 'public' 
        AND tablename = 'customer_inquiries'
        AND policyname = 'allow_select_for_all'
    ) THEN
        CREATE POLICY "allow_select_for_all"
            ON customer_inquiries
            FOR SELECT
            TO authenticated, anon
            USING (true);
    END IF;

    -- Create insert policy
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_policies 
        WHERE schemaname = 'public' 
        AND tablename = 'customer_inquiries'
        AND policyname = 'allow_insert_for_anon'
    ) THEN
        CREATE POLICY "allow_insert_for_anon"
            ON customer_inquiries
            FOR INSERT
            TO anon
            WITH CHECK (true);
    END IF;
END $$;

-- Ensure proper grants
GRANT DELETE ON customer_inquiries TO authenticated;