/*
  # Fresh start migration
  
  1. Changes
    - Drop all existing tables
    - Create tables with proper structure
    - Set up proper indexes and constraints
    - Enable RLS where needed
  
  2. Details
    - Complete database reset
    - Fresh schema setup
*/

-- First drop all existing tables
DROP TABLE IF EXISTS sms_replies CASCADE;
DROP TABLE IF EXISTS twilio_config CASCADE;
DROP TABLE IF EXISTS customer_inquiries CASCADE;
DROP TABLE IF EXISTS box_orders CASCADE;
DROP TABLE IF EXISTS shipped_box_items CASCADE;
DROP TABLE IF EXISTS shipped_boxes CASCADE;
DROP TABLE IF EXISTS storage_items CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS customers CASCADE;

-- Create order status enum
CREATE TYPE order_status AS ENUM ('unprocessed', 'in_tray', 'in_box', 'shipped');

-- Create customers table
CREATE TABLE customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bidder_number text UNIQUE NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text,
  balance decimal DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create orders table
CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  recorded_at timestamptz NOT NULL,
  item_code text NOT NULL,
  item_name text NOT NULL,
  quantity integer DEFAULT 1,
  debit decimal DEFAULT 0,
  credit decimal DEFAULT 0,
  status order_status DEFAULT 'unprocessed',
  processed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create storage_items table
CREATE TABLE storage_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  type text CHECK (type IN ('bag_cage', 'box_shelf')),
  created_at timestamptz DEFAULT now()
);

-- Create shipped_boxes table
CREATE TABLE shipped_boxes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  type text CHECK (type IN ('single', 'small', 'big', 'bag')),
  weight decimal NOT NULL,
  price decimal NOT NULL,
  bag_type text CHECK (bag_type IN ('standard', 'large', null)),
  in_cage boolean DEFAULT false,
  archived boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create shipped_box_items table
CREATE TABLE shipped_box_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  box_id uuid REFERENCES shipped_boxes(id) ON DELETE CASCADE,
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(box_id, order_id)
);

-- Create box_orders table
CREATE TABLE box_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  box_type text NOT NULL,
  price decimal NOT NULL,
  status text DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create customer_inquiries table
CREATE TABLE customer_inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  question text NOT NULL,
  priority text CHECK (priority IN ('low', 'medium', 'high')) DEFAULT 'low',
  status text CHECK (status IN ('new', 'in_progress', 'answered')) DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create twilio_config table
CREATE TABLE twilio_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_sid text NOT NULL CHECK (length(account_sid) > 0),
  auth_token text NOT NULL CHECK (length(auth_token) > 0),
  phone_number text NOT NULL CHECK (phone_number ~ '^\+[1-9]\d{1,14}$'),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create sms_replies table
CREATE TABLE sms_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_number text NOT NULL,
  to_number text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now(),
  read boolean DEFAULT false
);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_customers_updated_at
  BEFORE UPDATE ON customers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_box_orders_updated_at
  BEFORE UPDATE ON box_orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_customer_inquiries_updated_at
  BEFORE UPDATE ON customer_inquiries
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_twilio_config_updated_at
  BEFORE UPDATE ON twilio_config
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes
CREATE INDEX idx_customers_bidder_number ON customers(bidder_number);
CREATE INDEX idx_orders_customer_id ON orders(customer_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_storage_items_customer_id ON storage_items(customer_id);
CREATE INDEX idx_shipped_boxes_customer_id ON shipped_boxes(customer_id);
CREATE INDEX idx_shipped_boxes_archived ON shipped_boxes(archived);
CREATE INDEX idx_box_orders_created_at ON box_orders(created_at DESC);
CREATE INDEX idx_customer_inquiries_status ON customer_inquiries(status);
CREATE INDEX idx_sms_replies_created_at ON sms_replies(created_at DESC);

-- Disable RLS on all tables for now
ALTER TABLE customers DISABLE ROW LEVEL SECURITY;
ALTER TABLE orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE storage_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_boxes DISABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_box_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE box_orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE customer_inquiries DISABLE ROW LEVEL SECURITY;
ALTER TABLE twilio_config DISABLE ROW LEVEL SECURITY;
ALTER TABLE sms_replies DISABLE ROW LEVEL SECURITY;

-- Grant all permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon;