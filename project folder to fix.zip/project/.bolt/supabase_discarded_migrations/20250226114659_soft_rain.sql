-- First check and drop existing indexes
DO $$ 
BEGIN
  -- Drop indexes if they exist
  IF EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname = 'idx_sms_replies_created_at'
  ) THEN
    DROP INDEX idx_sms_replies_created_at;
  END IF;

  IF EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname = 'idx_sms_replies_from_number'
  ) THEN
    DROP INDEX idx_sms_replies_from_number;
  END IF;

  IF EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname = 'idx_sms_replies_read'
  ) THEN
    DROP INDEX idx_sms_replies_read;
  END IF;
END $$;

-- Create new indexes with IF NOT EXISTS to prevent errors
CREATE INDEX IF NOT EXISTS idx_sms_replies_created_at ON sms_replies(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sms_replies_from_number ON sms_replies(from_number);
CREATE INDEX IF NOT EXISTS idx_sms_replies_read ON sms_replies(read);

-- Verify indexes exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname IN (
      'idx_sms_replies_created_at',
      'idx_sms_replies_from_number',
      'idx_sms_replies_read'
    )
  ) THEN
    RAISE EXCEPTION 'Failed to create required indexes';
  END IF;
END $$;