/*
  # Add robust box processing function

  1. Changes
    - Create a stored procedure to handle box processing in a transaction
    - Handle price column existence gracefully
    - Ensure all operations succeed or fail together
  
  2. Details
    - Combines box creation, item association, and order status update
    - Handles errors properly with detailed messages
    - Provides fallbacks for database schema variations
*/

-- Create a function to process boxes in a single transaction
CREATE OR REPLACE FUNCTION process_box(
  p_customer_id uuid,
  p_box_type text,
  p_weight decimal,
  p_order_ids uuid[]
)
RETURNS uuid
LANGUAGE plpgsql
AS $$
DECLARE
  v_box_id uuid;
  v_price decimal;
  v_order_id uuid;
  v_has_price_column boolean;
BEGIN
  -- Calculate price based on box type
  CASE p_box_type
    WHEN 'single' THEN v_price := 3.99;
    WHEN 'small' THEN v_price := 7.99;
    WHEN 'big' THEN v_price := 9.99;
    ELSE v_price := 0;
  END CASE;

  -- Check if price column exists
  SELECT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'price'
  ) INTO v_has_price_column;

  -- Start transaction
  BEGIN
    -- Insert the box record with or without price column
    IF v_has_price_column THEN
      INSERT INTO shipped_boxes (
        customer_id,
        type,
        weight,
        price,
        archived,
        created_at
      ) VALUES (
        p_customer_id,
        p_box_type,
        p_weight,
        v_price,
        false,
        now()
      ) RETURNING id INTO v_box_id;
    ELSE
      INSERT INTO shipped_boxes (
        customer_id,
        type,
        weight,
        archived,
        created_at
      ) VALUES (
        p_customer_id,
        p_box_type,
        p_weight,
        false,
        now()
      ) RETURNING id INTO v_box_id;
    END IF;

    -- Create relationships between box and orders
    FOREACH v_order_id IN ARRAY p_order_ids
    LOOP
      INSERT INTO shipped_box_items (
        box_id,
        order_id,
        created_at
      ) VALUES (
        v_box_id,
        v_order_id,
        now()
      );
    END LOOP;

    -- Update orders status to shipped
    UPDATE orders
    SET 
      status = 'shipped',
      processed_at = now()
    WHERE id = ANY(p_order_ids);

    -- Return the box ID
    RETURN v_box_id;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE EXCEPTION 'Error processing box: %', SQLERRM;
  END;
END;
$$;

-- Grant execute permission on the function
GRANT EXECUTE ON FUNCTION process_box(uuid, text, decimal, uuid[]) TO authenticated;
GRANT EXECUTE ON FUNCTION process_box(uuid, text, decimal, uuid[]) TO anon;

-- Create a function to check if an order can be processed
CREATE OR REPLACE FUNCTION can_process_orders(p_order_ids uuid[])
RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  v_count integer;
BEGIN
  -- Count how many of the provided order IDs are in the 'in_box' status
  SELECT COUNT(*)
  INTO v_count
  FROM orders
  WHERE id = ANY(p_order_ids)
  AND status = 'in_box';
  
  -- Return true if all orders are in 'in_box' status
  RETURN v_count = array_length(p_order_ids, 1);
END;
$$;

-- Grant execute permission on the function
GRANT EXECUTE ON FUNCTION can_process_orders(uuid[]) TO authenticated;
GRANT EXECUTE ON FUNCTION can_process_orders(uuid[]) TO anon;