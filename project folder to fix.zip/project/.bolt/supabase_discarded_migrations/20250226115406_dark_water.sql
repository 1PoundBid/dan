-- Create sms_replies table if it doesn't exist
CREATE TABLE IF NOT EXISTS sms_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_number text NOT NULL,
  to_number text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now(),
  read boolean DEFAULT false
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_sms_replies_created_at ON sms_replies(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sms_replies_from_number ON sms_replies(from_number);
CREATE INDEX IF NOT EXISTS idx_sms_replies_read ON sms_replies(read);

-- Disable RLS since this is an internal table
ALTER TABLE sms_replies DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON sms_replies TO authenticated;
GRANT ALL ON sms_replies TO anon;

-- Verify table and indexes exist
DO $$
BEGIN
  -- Check if table exists
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.tables 
    WHERE table_name = 'sms_replies'
  ) THEN
    RAISE EXCEPTION 'sms_replies table does not exist!';
  END IF;

  -- Check if indexes exist
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname IN (
      'idx_sms_replies_created_at',
      'idx_sms_replies_from_number',
      'idx_sms_replies_read'
    )
  ) THEN
    RAISE EXCEPTION 'Required indexes are missing!';
  END IF;
END $$;