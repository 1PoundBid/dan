/*
  # Enable Authentication and Secure Access

  1. Changes
    - Enable RLS on all tables
    - Create policies for authenticated access only
    - Remove anonymous access
  
  2. Security
    - Only authenticated users can access data
    - Proper row-level security
*/

-- Enable RLS on all tables
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_boxes ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipped_box_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE box_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE twilio_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE sms_replies ENABLE ROW LEVEL SECURITY;

-- Drop any existing policies
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "enable_all_access" ON customers;
    DROP POLICY IF EXISTS "enable_all_access" ON orders;
    DROP POLICY IF EXISTS "enable_all_access" ON storage_items;
    DROP POLICY IF EXISTS "enable_all_access" ON shipped_boxes;
    DROP POLICY IF EXISTS "enable_all_access" ON shipped_box_items;
    DROP POLICY IF EXISTS "enable_all_access" ON box_orders;
    DROP POLICY IF EXISTS "enable_all_access" ON customer_inquiries;
    DROP POLICY IF EXISTS "enable_all_access" ON twilio_config;
    DROP POLICY IF EXISTS "enable_all_access" ON sms_replies;
END $$;

-- Create new policies that only allow authenticated access
CREATE POLICY "authenticated_access" ON customers
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_access" ON orders
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_access" ON storage_items
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_access" ON shipped_boxes
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_access" ON shipped_box_items
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_access" ON box_orders
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_access" ON customer_inquiries
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_access" ON twilio_config
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "authenticated_access" ON sms_replies
    FOR ALL TO authenticated
    USING (true)
    WITH CHECK (true);

-- Revoke anonymous access
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;

-- Grant permissions only to authenticated users
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO authenticated;