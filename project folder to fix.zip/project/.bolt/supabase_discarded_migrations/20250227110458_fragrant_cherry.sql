/*
  # Add price column to shipped_boxes table

  1. Changes
    - Add price column to shipped_boxes table
    - Set default prices for existing boxes
    - Make price column required
    - Create a database function to check and add the price column

  2. Details
    - Adds a decimal column for tracking shipping costs
    - Sets prices based on box type (single: 3.99, small: 7.99, big: 9.99)
    - Ensures all existing records have a price value
    - Creates a function that can be called from the application to ensure the column exists
*/

-- Create a function to check and add the price column if it doesn't exist
CREATE OR REPLACE FUNCTION check_and_add_price_column()
RETURNS void AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'price'
  ) THEN
    -- Add the column
    ALTER TABLE shipped_boxes
    ADD COLUMN price decimal;

    -- Set default prices for existing boxes
    UPDATE shipped_boxes
    SET price = CASE
      WHEN type = 'single' THEN 3.99
      WHEN type = 'small' THEN 7.99
      WHEN type = 'big' THEN 9.99
      ELSE 0
    END
    WHERE price IS NULL;

    -- Make price column required
    ALTER TABLE shipped_boxes
    ALTER COLUMN price SET NOT NULL;
    
    -- Create index for better query performance
    CREATE INDEX IF NOT EXISTS idx_shipped_boxes_price ON shipped_boxes(price);
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Execute the function to ensure the column exists
SELECT check_and_add_price_column();