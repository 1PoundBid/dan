/*
  # Add price column to shipped_boxes table

  1. Changes
    - Add price column to shipped_boxes table
    - Set default prices based on box type
    - Make price column required

  2. Details
    - Prices are set based on box type:
      - single: 3.99
      - small: 7.99
      - big: 9.99
    - This ensures compatibility with the application code
*/

-- Add price column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'price'
  ) THEN
    -- Add the column
    ALTER TABLE shipped_boxes
    ADD COLUMN price decimal;

    -- Set default prices for existing boxes
    UPDATE shipped_boxes
    SET price = CASE
      WHEN type = 'single' THEN 3.99
      WHEN type = 'small' THEN 7.99
      WHEN type = 'big' THEN 9.99
      ELSE 0
    END
    WHERE price IS NULL;

    -- Make price column required
    ALTER TABLE shipped_boxes
    ALTER COLUMN price SET NOT NULL;
  END IF;
END $$;

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_shipped_boxes_price ON shipped_boxes(price);