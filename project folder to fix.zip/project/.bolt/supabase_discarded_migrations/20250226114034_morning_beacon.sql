/*
  # Add SMS Replies Table

  1. New Tables
    - `sms_replies`
      - `id` (uuid, primary key)
      - `from_number` (text)
      - `to_number` (text)
      - `message` (text)
      - `created_at` (timestamp)
      - `read` (boolean)

  2. Security
    - Disable RLS since we're using open access
    - Grant necessary permissions
*/

-- Create sms_replies table
CREATE TABLE IF NOT EXISTS sms_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_number text NOT NULL,
  to_number text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now(),
  read boolean DEFAULT false
);

-- Create indexes for better query performance
CREATE INDEX idx_sms_replies_created_at ON sms_replies(created_at DESC);
CREATE INDEX idx_sms_replies_from_number ON sms_replies(from_number);
CREATE INDEX idx_sms_replies_read ON sms_replies(read);

-- Disable RLS
ALTER TABLE sms_replies DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON sms_replies TO authenticated;
GRANT ALL ON sms_replies TO anon;