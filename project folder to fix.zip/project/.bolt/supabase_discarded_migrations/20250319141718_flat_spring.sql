/*
  # Safe Database Reset

  1. Changes
    - Safely clear existing data
    - Check table existence before truncating
    - Reset sequences if they exist
  
  2. Details
    - Prevents errors from non-existent tables
    - Maintains data integrity
    - Safe cleanup process
*/

DO $$ 
BEGIN
  -- Safely truncate tables if they exist
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'sms_replies') THEN
    TRUNCATE TABLE sms_replies CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'twilio_config') THEN
    TRUNCATE TABLE twilio_config CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'customer_inquiries') THEN
    TRUNCATE TABLE customer_inquiries CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'box_orders') THEN
    TRUNCATE TABLE box_orders CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'shipped_box_items') THEN
    TRUNCATE TABLE shipped_box_items CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'shipped_boxes') THEN
    TRUNCATE TABLE shipped_boxes CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'storage_items') THEN
    TRUNCATE TABLE storage_items CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'orders') THEN
    TRUNCATE TABLE orders CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'customers') THEN
    TRUNCATE TABLE customers CASCADE;
  END IF;

  -- Reset sequences if they exist
  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'customers_id_seq') THEN
    ALTER SEQUENCE customers_id_seq RESTART WITH 1;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'orders_id_seq') THEN
    ALTER SEQUENCE orders_id_seq RESTART WITH 1;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'storage_items_id_seq') THEN
    ALTER SEQUENCE storage_items_id_seq RESTART WITH 1;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'shipped_boxes_id_seq') THEN
    ALTER SEQUENCE shipped_boxes_id_seq RESTART WITH 1;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'shipped_box_items_id_seq') THEN
    ALTER SEQUENCE shipped_box_items_id_seq RESTART WITH 1;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'box_orders_id_seq') THEN
    ALTER SEQUENCE box_orders_id_seq RESTART WITH 1;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'customer_inquiries_id_seq') THEN
    ALTER SEQUENCE customer_inquiries_id_seq RESTART WITH 1;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'twilio_config_id_seq') THEN
    ALTER SEQUENCE twilio_config_id_seq RESTART WITH 1;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = 'sms_replies_id_seq') THEN
    ALTER SEQUENCE sms_replies_id_seq RESTART WITH 1;
  END IF;
END $$;