/*
  # Clean up backup data

  1. Changes
    - Remove any sensitive or unnecessary data
    - Clean up temporary tables
    - Reset sequences if needed

  2. Security
    - Ensure no sensitive data remains
    - Maintain data integrity
*/

-- Clean up any temporary tables that might exist
DROP TABLE IF EXISTS temp_shipped_boxes;
DROP TABLE IF EXISTS shipped_boxes_backup;
DROP TABLE IF EXISTS system_backup;

-- Reset sequences to a safe starting point
SELECT setval(pg_get_serial_sequence('customers', 'id'), 1, false);
SELECT setval(pg_get_serial_sequence('orders', 'id'), 1, false);
SELECT setval(pg_get_serial_sequence('storage_items', 'id'), 1, false);
SELECT setval(pg_get_serial_sequence('shipped_boxes', 'id'), 1, false);
SELECT setval(pg_get_serial_sequence('shipped_box_items', 'id'), 1, false);
SELECT setval(pg_get_serial_sequence('box_orders', 'id'), 1, false);
SELECT setval(pg_get_serial_sequence('customer_inquiries', 'id'), 1, false);
SELECT setval(pg_get_serial_sequence('twilio_config', 'id'), 1, false);
SELECT setval(pg_get_serial_sequence('sms_replies', 'id'), 1, false);

-- Verify cleanup
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.tables 
    WHERE table_name IN ('temp_shipped_boxes', 'shipped_boxes_backup', 'system_backup')
  ) THEN
    RAISE EXCEPTION 'Cleanup failed - temporary tables still exist';
  END IF;
END $$;