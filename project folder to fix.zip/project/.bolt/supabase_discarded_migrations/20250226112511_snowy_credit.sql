/*
  # Create Twilio Configuration Table

  1. New Tables
    - `twilio_config`
      - `id` (uuid, primary key)
      - `account_sid` (text)
      - `auth_token` (text)
      - `phone_number` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Disable RLS for admin-only access
    - Grant full permissions to both roles
*/

-- First ensure clean state
DROP TABLE IF EXISTS twilio_config CASCADE;

-- Create twilio_config table
CREATE TABLE twilio_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_sid text NOT NULL CHECK (length(account_sid) > 0),
  auth_token text NOT NULL CHECK (length(auth_token) > 0),
  phone_number text NOT NULL CHECK (phone_number ~ '^\+[1-9]\d{1,14}$'),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_twilio_config_created_at ON twilio_config(created_at DESC);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_twilio_config_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_twilio_config_updated_at
  BEFORE UPDATE ON twilio_config
  FOR EACH ROW
  EXECUTE FUNCTION update_twilio_config_updated_at();

-- Disable RLS
ALTER TABLE twilio_config DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON twilio_config TO authenticated;
GRANT ALL ON twilio_config TO anon;

-- Verify table exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.tables 
    WHERE table_name = 'twilio_config'
  ) THEN
    RAISE EXCEPTION 'twilio_config table does not exist!';
  END IF;
END $$;