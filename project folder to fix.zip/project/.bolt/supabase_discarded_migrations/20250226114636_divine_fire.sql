-- Drop existing indexes if they exist
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname = 'idx_sms_replies_created_at'
  ) THEN
    DROP INDEX idx_sms_replies_created_at;
  END IF;

  IF EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname = 'idx_sms_replies_from_number'
  ) THEN
    DROP INDEX idx_sms_replies_from_number;
  END IF;

  IF EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname = 'idx_sms_replies_read'
  ) THEN
    DROP INDEX idx_sms_replies_read;
  END IF;
END $$;

-- Recreate indexes
CREATE INDEX idx_sms_replies_created_at ON sms_replies(created_at DESC);
CREATE INDEX idx_sms_replies_from_number ON sms_replies(from_number);
CREATE INDEX idx_sms_replies_read ON sms_replies(read);