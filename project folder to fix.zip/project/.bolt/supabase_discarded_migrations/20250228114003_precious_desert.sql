/*
  # Remove price column from shipped_boxes table

  1. Changes
    - Remove the price column from shipped_boxes table
    - Drop the check_and_add_price_column function
    - Drop any indexes related to the price column
  
  2. Details
    - This migration removes the price column as it's no longer needed
    - Ensures all references to the price column are removed
*/

-- First check if the price column exists and drop it
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'price'
  ) THEN
    -- Drop the column
    ALTER TABLE shipped_boxes DROP COLUMN price;
  END IF;
END $$;

-- Drop the index if it exists
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname = 'idx_shipped_boxes_price'
  ) THEN
    DROP INDEX idx_shipped_boxes_price;
  END IF;
END $$;

-- Drop the function if it exists
DROP FUNCTION IF EXISTS check_and_add_price_column();