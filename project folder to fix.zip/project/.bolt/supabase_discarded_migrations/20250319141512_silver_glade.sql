/*
  # Reset Database to Clean State

  1. Changes
    - Clear all existing data
    - Reset sequences
    - Maintain table structure
  
  2. Details
    - Safe cleanup of all tables
    - Preserve schema and relationships
*/

-- Clear data from tables in correct order
TRUNCATE TABLE sms_replies CASCADE;
TRUNCATE TABLE twilio_config CASCADE;
TRUNCATE TABLE customer_inquiries CASCADE;
TRUNCATE TABLE box_orders CASCADE;
TRUNCATE TABLE shipped_box_items CASCADE;
TRUNCATE TABLE shipped_boxes CASCADE;
TRUNCATE TABLE storage_items CASCADE;
TRUNCATE TABLE orders CASCADE;
TRUNCATE TABLE customers CASCADE;

-- Reset sequences
ALTER SEQUENCE IF EXISTS customers_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS orders_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS storage_items_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS shipped_boxes_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS shipped_box_items_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS box_orders_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS customer_inquiries_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS twilio_config_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS sms_replies_id_seq RESTART WITH 1;