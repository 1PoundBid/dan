-- First check if the price column exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'price'
  ) THEN
    -- Add the column
    ALTER TABLE shipped_boxes
    ADD COLUMN price decimal DEFAULT 0;

    -- Set default prices for existing boxes
    UPDATE shipped_boxes
    SET price = CASE
      WHEN type = 'single' THEN 3.99
      WHEN type = 'small' THEN 7.99
      WHEN type = 'big' THEN 9.99
      ELSE 0
    END;

    -- Make price column required
    ALTER TABLE shipped_boxes
    ALTER COLUMN price SET NOT NULL;
    
    -- Create index for better query performance
    CREATE INDEX IF NOT EXISTS idx_shipped_boxes_price ON shipped_boxes(price);
  END IF;
END $$;

-- Create or replace the function to check and add the price column
CREATE OR REPLACE FUNCTION check_and_add_price_column()
RETURNS void AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'shipped_boxes' 
    AND column_name = 'price'
  ) THEN
    -- Add the column
    ALTER TABLE shipped_boxes
    ADD COLUMN price decimal DEFAULT 0;

    -- Set default prices for existing boxes
    UPDATE shipped_boxes
    SET price = CASE
      WHEN type = 'single' THEN 3.99
      WHEN type = 'small' THEN 7.99
      WHEN type = 'big' THEN 9.99
      ELSE 0
    END;

    -- Make price column required
    ALTER TABLE shipped_boxes
    ALTER COLUMN price SET NOT NULL;
    
    -- Create index for better query performance
    CREATE INDEX IF NOT EXISTS idx_shipped_boxes_price ON shipped_boxes(price);
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Execute the function to ensure the column exists
SELECT check_and_add_price_column();

-- Grant execute permission on the function
GRANT EXECUTE ON FUNCTION check_and_add_price_column() TO authenticated;
GRANT EXECUTE ON FUNCTION check_and_add_price_column() TO anon;