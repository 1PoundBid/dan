/*
  # Fix Box Orders RLS Policies

  1. Changes
    - Drop existing restrictive policies
    - Create new unified policy for all operations
    - Grant proper permissions to both authenticated and anon roles

  2. Security
    - Enable RLS
    - Allow all operations for authenticated users
    - Allow insert and select for anon users
*/

-- Drop existing policies
DO $$ 
BEGIN
    IF EXISTS (
        SELECT 1 
        FROM pg_policies 
        WHERE schemaname = 'public' 
        AND tablename = 'box_orders'
    ) THEN
        DROP POLICY IF EXISTS "box_orders_anon_insert" ON box_orders;
        DROP POLICY IF EXISTS "box_orders_public_select" ON box_orders;
        DROP POLICY IF EXISTS "box_orders_auth_all" ON box_orders;
    END IF;
END $$;

-- Create a single unified policy
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_policies 
        WHERE schemaname = 'public' 
        AND tablename = 'box_orders'
        AND policyname = 'allow_all_operations'
    ) THEN
        CREATE POLICY "allow_all_operations"
            ON box_orders
            FOR ALL
            TO authenticated, anon
            USING (true)
            WITH CHECK (true);
    END IF;
END $$;

-- Ensure proper permissions
GRANT ALL ON box_orders TO authenticated;
GRANT INSERT, SELECT ON box_orders TO anon;