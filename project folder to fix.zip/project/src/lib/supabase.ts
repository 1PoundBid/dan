import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';
import { config } from './config';

// Create Supabase client using environment-specific configuration
export const supabase = createClient<Database>(
  config.supabase.url,
  config.supabase.key
);

// Maximum number of retry attempts for network errors
const MAX_RETRIES = 3;
// Base delay in milliseconds before retrying (will be multiplied by attempt number)
const RETRY_DELAY = 1000;

// Helper function to retry a Supabase operation on network errors
async function retryOnNetworkError<T>(operation: () => Promise<T>, maxRetries = MAX_RETRIES): Promise<T> {
  let lastError: any;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error: any) {
      lastError = error;
      
      // Only retry on network errors (Failed to fetch)
      if (error?.message?.includes('Failed to fetch')) {
        console.warn(`Network error, retrying (${attempt + 1}/${maxRetries})...`, error);
        // Exponential backoff
        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * (attempt + 1)));
        continue;
      }
      
      // For other errors, don't retry
      throw error;
    }
  }
  
  // If we've exhausted all retries
  throw lastError;
}

export async function lookupItem(barcode: string) {
  if (!barcode?.trim()) {
    throw new Error('Please scan a valid barcode');
  }

  try {
    // Get the most recent order for this item code
    const { data: orders, error } = await retryOnNetworkError(() => 
      supabase
        .from('orders')
        .select(`
          id,
          item_name,
          item_code,
          status,
          customer:customer_id (
            id,
            first_name,
            last_name,
            bidder_number
          )
        `)
        .eq('item_code', barcode)
        .order('recorded_at', { ascending: false })
        .limit(1)
    );

    if (error) {
      throw new Error(`Database error: ${error.message}`);
    }

    if (!orders || orders.length === 0) {
      throw new Error(`No orders found for barcode ${barcode}`);
    }

    return {
      id: orders[0].id,
      item_code: orders[0].item_code,
      item_name: orders[0].item_name,
      customer: orders[0].customer
    };
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('An unexpected error occurred while looking up item');
  }
}

export async function updateItemStatus(barcode: string, status: 'in_tray' | 'in_box' | 'shipped') {
  if (!barcode?.trim()) {
    throw new Error('Please scan a valid barcode');
  }

  try {
    // First check if the item is already in the tray
    if (status === 'in_tray') {
      const { data: existingItems, error: existingError } = await retryOnNetworkError(() => 
        supabase
          .from('orders')
          .select(`
            id,
            item_name,
            item_code,
            status,
            customer:customer_id (
              id,
              first_name,
              last_name,
              bidder_number
            )
          `)
          .eq('item_code', barcode)
          .eq('status', 'in_tray')
          .order('recorded_at', { ascending: false })
          .limit(1)
      );

      if (existingError) {
        throw new Error(`Database error: ${existingError.message}`);
      }

      if (existingItems && existingItems.length > 0) {
        const item = existingItems[0];
        const fullName = `${item.customer.first_name} ${item.customer.last_name}`;
        throw new Error(`Item already in tray for ${fullName}`);
      }
    }

    // Then get the most recent unprocessed order for this item code
    const { data: orders, error: findError } = await retryOnNetworkError(() => 
      supabase
        .from('orders')
        .select(`
          id,
          item_name,
          item_code,
          status,
          customer:customer_id (
            id,
            first_name,
            last_name,
            bidder_number
          )
        `)
        .eq('item_code', barcode)
        .eq('status', status === 'in_box' ? 'in_tray' : 'unprocessed')
        .order('recorded_at', { ascending: false })
        .limit(1)
    );

    if (findError) {
      throw new Error(`Database error: ${findError.message}`);
    }

    if (!orders || orders.length === 0) {
      if (status === 'in_box') {
        throw new Error(`No items in tray found for barcode ${barcode}`);
      } else {
        throw new Error(`No unprocessed orders found for barcode ${barcode}`);
      }
    }

    const order = orders[0];

    // Then update the order status
    const { error: updateError } = await retryOnNetworkError(() => 
      supabase
        .from('orders')
        .update({ 
          status,
          processed_at: status === 'shipped' ? new Date().toISOString() : null
        })
        .eq('id', order.id)
    );

    if (updateError) {
      throw new Error(`Failed to update order status: ${updateError.message}`);
    }

    return {
      id: order.id,
      item_code: order.item_code,
      item_name: order.item_name,
      customer: order.customer
    };
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('An unexpected error occurred while updating item status');
  }
}

export async function processBox(
  customerId: string,
  boxType: 'single' | 'small' | 'big' | 'bag',
  weight: number,
  orderIds: string[],
  bagType?: 'standard' | 'large'
) {
  try {
    if (!orderIds.length) {
      throw new Error('No items selected for boxing');
    }

    // Create a new shipped box record
    const { data: boxData, error: boxError } = await retryOnNetworkError(() => 
      supabase
        .from('shipped_boxes')
        .insert({
          customer_id: customerId,
          type: boxType,
          weight,
          price: boxType === 'bag' ? 0 : 
                 boxType === 'single' ? 3.99 :
                 boxType === 'small' ? 7.99 : 9.99,
          bag_type: boxType === 'bag' ? bagType : null,
          in_cage: boxType === 'bag',
          archived: false,
          created_at: new Date().toISOString()
        })
        .select()
        .single()
    );

    if (boxError) {
      console.error('Error creating shipped box:', boxError);
      throw new Error(`Failed to create shipped box: ${boxError.message}`);
    }

    // Create relationships between box and orders
    const { error: itemsError } = await retryOnNetworkError(() => 
      supabase
        .from('shipped_box_items')
        .insert(
          orderIds.map(orderId => ({
            box_id: boxData.id,
            order_id: orderId
          }))
        )
    );

    if (itemsError) {
      console.error('Error creating shipped box items:', itemsError);
      throw new Error(`Failed to create shipped box items: ${itemsError.message}`);
    }

    // Update orders status to shipped
    const { error: updateError } = await retryOnNetworkError(() => 
      supabase
        .from('orders')
        .update({ 
          status: 'shipped',
          processed_at: new Date().toISOString()
        })
        .in('id', orderIds)
    );

    if (updateError) {
      console.error('Error updating order status:', updateError);
      throw new Error(`Failed to update order status: ${updateError.message}`);
    }

    return boxData;
  } catch (error) {
    console.error('Error processing box:', error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('An unexpected error occurred while processing box');
  }
}

export async function getShippedBoxes(customerId: string) {
  try {
    const { data: boxes, error: boxesError } = await retryOnNetworkError(() => 
      supabase
        .from('shipped_boxes')
        .select(`
          id,
          type,
          weight,
          bag_type,
          created_at,
          shipped_box_items (
            order:order_id (
              id,
              item_code,
              item_name,
              status,
              processed_at
            )
          )
        `)
        .eq('customer_id', customerId)
        .order('created_at', { ascending: false })
    );

    if (boxesError) throw boxesError;

    // Process the data to make it easier to work with
    return boxes.map(box => ({
      id: box.id,
      type: box.type,
      weight: box.weight,
      bag_type: box.bag_type,
      created_at: box.created_at,
      items: box.shipped_box_items.map(item => item.order)
    }));
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('An unexpected error occurred while fetching shipped boxes');
  }
}