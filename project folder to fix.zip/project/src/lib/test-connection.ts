import { supabase } from './supabase';
import { config, isProduction } from './config';

// Maximum number of retry attempts
const MAX_RETRIES = 3;
// Base delay in milliseconds before retrying
const RETRY_DELAY = 1000;

async function retryOperation<T>(operation: () => Promise<T>): Promise<T> {
  let lastError: any;
  
  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      return await operation();
    } catch (error: any) {
      lastError = error;
      
      // Only retry on network errors
      if (error?.message?.includes('Failed to fetch')) {
        if (!isProduction) {
          console.warn(`Connection attempt ${attempt + 1}/${MAX_RETRIES} failed, retrying...`);
        }
        // Exponential backoff
        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * Math.pow(2, attempt)));
        continue;
      }
      
      throw error;
    }
  }
  
  throw lastError;
}

export async function testSupabaseConnection() {
  try {
    // Log environment info in development
    if (!isProduction) {
      console.log('Testing connection to:', config.supabase.url);
      console.log('Environment:', import.meta.env.VITE_ENV);
    }

    // Try to get a single customer to test connection with retry
    const { data, error } = await retryOperation(async () => 
      await supabase
        .from('customers')
        .select('id')
        .limit(1)
    );

    if (error) {
      console.error('Supabase connection error:', error);
      return {
        connected: false,
        error: error.message,
        url: config.supabase.url
      };
    }

    return {
      connected: true,
      url: config.supabase.url
    };
  } catch (error) {
    console.error('Supabase test error:', error);
    return {
      connected: false,
      error: error instanceof Error 
        ? error.message 
        : 'Failed to connect to database. Please check your network connection.',
      url: config.supabase.url
    };
  }
}