/**
 * Central configuration management for the application.
 * Loads and validates environment variables.
 */

interface Config {
  supabase: {
    url: string;
    anonKey: string;
  };
  isDevelopment: boolean;
}

function validateSupabaseConfig() {
  const url = 'https://wdahgclackfaifkhrell.supabase.co';
  const key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndkYWhnY2xhY2tmYWlma2hyZWxsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzc2NzI5NzMsImV4cCI6MjA1MzI0ODk3M30.q6HiA2Kk385MSKhLdxKOq-IroSREZY5jWJh-9260WjA';

  if (!url || !key) {
    throw new Error(
      'Missing required Supabase configuration. Please check your .env file and ensure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set.'
    );
  }

  return { url, key };
}

export const config: Config = {
  supabase: validateSupabaseConfig(),
  isDevelopment: import.meta.env.VITE_ENV === 'development'
};

// Environment detection helpers
export const isProduction = import.meta.env.VITE_ENV === 'production';
export const isTestEnvironment = import.meta.env.VITE_ENV === 'test';

// Feature flags based on environment
export const features = {
  debugLogging: import.meta.env.VITE_ENV === 'development',
  strictMode: import.meta.env.VITE_ENV === 'production'
};

// Validate configuration on load
(() => {
  // Validate production requirements
  if (isProduction && !config.supabase.url.includes('https://')) {
    throw new Error('Production Supabase URL must use HTTPS');
  }
})();