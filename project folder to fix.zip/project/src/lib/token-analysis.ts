/**
 * Token analysis utilities for tracking Supabase token usage
 */

import type { SupabaseClient } from '@supabase/supabase-js';

interface TokenUsage {
  endpoint: string;
  method: string;
  timestamp: string;
  tokenCount: number;
}

interface TokenAnalysis {
  totalTokens: number;
  endpointBreakdown: Record<string, number>;
  methodBreakdown: Record<string, number>;
  timeAnalysis: {
    hourly: Record<number, number>;
    daily: Record<string, number>;
  };
}

// Track token usage for each request
const tokenUsage: TokenUsage[] = [];

// Initialize tracking state
let isInitialized = false;
let supabaseInstance: SupabaseClient | null = null;

// Intercept Supabase requests to track token usage
export function initTokenTracking(client: SupabaseClient) {
  if (isInitialized) return;
  
  supabaseInstance = client;
  const originalFetch = client.rest.headers;
  
  client.rest.headers = async (...args) => {
    const result = await originalFetch.apply(client.rest, args);
    
    // Estimate token usage based on request/response size
    const requestSize = JSON.stringify(args).length;
    const responseSize = JSON.stringify(result).length;
    const estimatedTokens = Math.ceil((requestSize + responseSize) / 4); // Rough estimate
    
    tokenUsage.push({
      endpoint: args[0] as string,
      method: args[1]?.method || 'GET',
      timestamp: new Date().toISOString(),
      tokenCount: estimatedTokens
    });
    
    return result;
  };

  isInitialized = true;
}

// Analyze token usage patterns
export function analyzeTokenUsage(): TokenAnalysis {
  if (!isInitialized || !supabaseInstance) {
    return {
      totalTokens: 0,
      endpointBreakdown: {},
      methodBreakdown: {},
      timeAnalysis: {
        hourly: {},
        daily: {}
      }
    };
  }

  const analysis: TokenAnalysis = {
    totalTokens: 0,
    endpointBreakdown: {},
    methodBreakdown: {},
    timeAnalysis: {
      hourly: {},
      daily: {}
    }
  };
  
  tokenUsage.forEach(usage => {
    // Total tokens
    analysis.totalTokens += usage.tokenCount;
    
    // Endpoint breakdown
    analysis.endpointBreakdown[usage.endpoint] = 
      (analysis.endpointBreakdown[usage.endpoint] || 0) + usage.tokenCount;
      
    // Method breakdown  
    analysis.methodBreakdown[usage.method] = 
      (analysis.methodBreakdown[usage.method] || 0) + usage.tokenCount;
      
    // Time analysis
    const date = new Date(usage.timestamp);
    const hour = date.getHours();
    const day = date.toISOString().split('T')[0];
    
    analysis.timeAnalysis.hourly[hour] = 
      (analysis.timeAnalysis.hourly[hour] || 0) + usage.tokenCount;
      
    analysis.timeAnalysis.daily[day] = 
      (analysis.timeAnalysis.daily[day] || 0) + usage.tokenCount;
  });
  
  return analysis;
}

// Get current token usage metrics
export function getTokenMetrics() {
  if (!isInitialized || !supabaseInstance) {
    return {
      totalTokens: 0,
      topEndpoints: [],
      methodDistribution: {},
      peakUsageHour: null,
      dailyAverage: 0
    };
  }

  const analysis = analyzeTokenUsage();
  
  return {
    totalTokens: analysis.totalTokens,
    topEndpoints: Object.entries(analysis.endpointBreakdown)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5),
    methodDistribution: analysis.methodBreakdown,
    peakUsageHour: Object.entries(analysis.timeAnalysis.hourly)
      .sort(([,a], [,b]) => b - a)[0],
    dailyAverage: Object.values(analysis.timeAnalysis.daily)
      .reduce((sum, val) => sum + val, 0) / 
      Object.keys(analysis.timeAnalysis.daily).length || 0
  };
}