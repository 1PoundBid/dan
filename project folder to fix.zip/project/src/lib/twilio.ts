import { supabase } from './supabase';

interface TwilioConfig {
  account_sid: string;
  auth_token: string;
  phone_number: string;
}

let cachedConfig: TwilioConfig | null = null;

export const getTwilioConfig = async (): Promise<TwilioConfig> => {
  try {
    if (cachedConfig) {
      return cachedConfig;
    }

    const { data, error } = await supabase
      .from('twilio_config')
      .select('*')
      .limit(1)
      .single();

    if (error) {
      if (error.code === '42P01') { // Table does not exist
        throw new Error('Twilio configuration table not found. Please run the database migrations.');
      }
      throw new Error(`Failed to load Twilio configuration: ${error.message}`);
    }

    if (!data) {
      throw new Error('Please configure your Twilio settings in the Settings page first.');
    }

    if (!data.account_sid || !data.auth_token || !data.phone_number) {
      throw new Error('Invalid Twilio configuration. Please check all required fields.');
    }

    cachedConfig = data;
    return data;
  } catch (error) {
    console.error('Error loading Twilio config:', error);
    throw error instanceof Error ? error : new Error('Failed to load Twilio configuration');
  }
};

// Validate phone number format
const validatePhoneNumber = (phoneNumber: string): boolean => {
  // Remove any spaces, dashes, or parentheses
  const cleanNumber = phoneNumber.replace(/[\s\-\(\)]/g, '');
  
  // Must start with + and contain 10-15 digits
  const phoneRegex = /^\+[1-9]\d{9,14}$/;
  return phoneRegex.test(cleanNumber);
};

// Format phone number to E.164 format
const formatPhoneNumber = (phoneNumber: string): string => {
  // Remove all non-digit characters except +
  const cleanNumber = phoneNumber.replace(/[^\d+]/g, '');
  
  // If number doesn't start with +, assume it's a US number
  if (!cleanNumber.startsWith('+')) {
    return `+1${cleanNumber}`; // Add US country code
  }
  
  return cleanNumber;
};

export const sendSMS = async (to: string, message: string) => {
  try {
    const config = await getTwilioConfig();

    // Format and validate the phone number
    const formattedNumber = formatPhoneNumber(to);
    if (!validatePhoneNumber(formattedNumber)) {
      throw new Error(`Invalid phone number format: ${to}. Number must be in E.164 format (e.g. +1234567890)`);
    }

    const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${config.account_sid}/Messages.json`, {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + btoa(`${config.account_sid}:${config.auth_token}`),
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
      },
      body: new URLSearchParams({
        To: formattedNumber,
        From: config.phone_number,
        Body: message,
        StatusCallback: 'https://wdahgclackfaifkhrell.supabase.co/functions/v1/twilio-webhook'
      })
    });

    const responseData = await response.json();

    if (!response.ok) {
      console.error('Twilio API error:', responseData);
      throw new Error(responseData.message || `Twilio API error: ${response.status}`);
    }

    // Store the sent message in sms_replies
    const { error: insertError } = await supabase
      .from('sms_replies')
      .insert({
        from_number: config.phone_number,
        to_number: formattedNumber,
        message: message,
        read: true // Mark as read since we sent it
      });

    if (insertError) {
      console.error('Error storing sent SMS:', insertError);
    }

    return responseData;
  } catch (error) {
    console.error('Error sending SMS:', error);
    if (error instanceof Error && error.message.includes('configuration')) {
      throw error; // Re-throw configuration errors as-is
    }
    throw error instanceof Error ? error : new Error('Failed to send SMS. Please check your Twilio configuration and try again.');
  }
};