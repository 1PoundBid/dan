import { useState } from 'react';
import { lookupItem, updateItemStatus } from '../lib/supabase';
import { speak } from '../utils/speech';

export function useScanningHandlers(customerId: string | undefined, onNavigate?: (customerId: string) => void) {
  const [error, setError] = useState<string | null>(null);

  const handleLookup = async (barcode: string) => {
    setError(null);
    
    try {
      const item = await lookupItem(barcode);
      const fullName = `${item.customer.first_name} ${item.customer.last_name}`;
      speak(`This item belongs to ${fullName}`);
      
      if (onNavigate && item.customer.id !== customerId) {
        onNavigate(item.customer.id);
      }
      
      return item;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Error scanning item';
      console.error('Scan error:', err);
      speak(message);
      setError(message);
      throw err;
    }
  };

  const handleTray = async (barcode: string) => {
    setError(null);
    
    try {
      const item = await lookupItem(barcode);
      
      // Check if we have a valid customer context
      if (!customerId) {
        const message = 'No active customer selected. Please select a customer first.';
        speak(message);
        setError(message);
        throw new Error(message);
      }

      // Verify item ownership
      if (item.customer.id !== customerId) {
        const message = `Stop! This item does not belong to this customer. It belongs to ${item.customer.first_name} ${item.customer.last_name}. Please place in their tray.`;
        speak(message);
        setError(message);
        throw new Error(message);
      }

      const updatedItem = await updateItemStatus(barcode, 'in_tray');
      const fullName = `${updatedItem.customer.first_name} ${updatedItem.customer.last_name}`;
      speak(`Item scanned into tray for ${fullName}`);
      
      return updatedItem;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Error scanning item';
      console.error('Scan error:', err);
      speak(message);
      setError(message);
      throw err;
    }
  };

  const handleBox = async (barcode: string) => {
    setError(null);
    
    try {
      // First look up the item to verify ownership
      const item = await lookupItem(barcode);
      
      // Check if we have a valid customer context
      if (!customerId) {
        const message = 'No active customer selected. Please select a customer first.';
        speak(message);
        setError(message);
        throw new Error(message);
      }

      // Verify item ownership before attempting to box
      if (item.customer.id !== customerId) {
        const message = `Stop! This item does not belong to this customer. It belongs to ${item.customer.first_name} ${item.customer.last_name}. Please place in their tray.`;
        speak(message);
        setError(message);
        throw new Error(message);
      }

      // If ownership verified, check if item is in the correct state to be boxed
      if (item.status !== 'in_tray') {
        const message = 'Item must be scanned to tray before it can be boxed.';
        speak(message);
        setError(message);
        throw new Error(message);
      }

      // If all checks pass, update the status to in_box
      const updatedItem = await updateItemStatus(barcode, 'in_box');
      const fullName = `${updatedItem.customer.first_name} ${updatedItem.customer.last_name}`;
      speak(`Item packed into box for ${fullName}`);
      
      return updatedItem;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Error scanning item';
      console.error('Scan error:', err);
      speak(message);
      setError(message);
      throw err;
    }
  };

  return {
    error,
    setError,
    handleLookup,
    handleTray,
    handleBox
  };
}