import { useState } from 'react';
import { speak } from '../utils/speech';
import { supabase } from '../lib/supabase';
import { processBox } from '../lib/supabase';

export function useBoxProcessing(
  customerId: string | undefined, 
  boxItems: string[],
  onSuccess: () => void
) {
  const [error, setError] = useState<string | null>(null);
  const [showBoxModal, setShowBoxModal] = useState(false);
  const [processing, setProcessing] = useState(false);

  const handleBoxFull = () => {
    if (boxItems.length === 0) {
      const message = 'No items in box to process';
      setError(message);
      speak(message);
      return;
    }
    
    speak('Please select a box type and enter the weight in kilograms');
    setShowBoxModal(true);
  };

  const handleBoxFullSubmit = async (boxType: 'single' | 'small' | 'big' | 'bag', weight: number) => {
    if (!customerId) return;
    if (isNaN(weight) || weight <= 0) {
      setError('Please enter a valid weight');
      return;
    }
    
    setProcessing(true);
    setError(null);
    
    try {
      // Process the box using the processBox function
      await processBox(customerId, boxType, weight, boxItems);
      
      // Close the modal and notify the user
      setShowBoxModal(false);
      speak('Box has been processed and items marked as shipped');
      
      // Refresh the data
      onSuccess();
    } catch (error) {
      console.error('Error processing box:', error);
      const message = error instanceof Error ? error.message : 'Error processing box';
      setError(message);
      speak(message);
    } finally {
      setProcessing(false);
    }
  };

  return {
    error,
    setError,
    showBoxModal,
    setShowBoxModal,
    processing,
    handleBoxFull,
    handleBoxFullSubmit
  };
}