import React from 'react';
import { Mail } from 'lucide-react';

interface CustomerHeaderProps {
  name: string;
  bidderNumber: string;
  email: string;
  balance: number;
}

export function CustomerHeader({ name, bidderNumber, email, balance }: CustomerHeaderProps) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{name}</h1>
          <div className="mt-2 space-y-2">
            <div className="text-gray-600">
              Bidder #: <span className="font-medium">{bidderNumber}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <Mail className="h-4 w-4 mr-2" />
              <a href={`mailto:${email}`} className="hover:text-blue-600">
                {email}
              </a>
            </div>
            <div className="text-gray-600">
              Balance: <span className="font-medium">${balance.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}