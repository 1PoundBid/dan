import React, { useState } from 'react';
import { Package, Mail, Scan, Box, Inbox, Trash2, Archive, Clock, AlertCircle, Scale } from 'lucide-react';
import { BoxModal } from './BoxModal';
import { speak } from '../../utils/speech';

export function CustomerDetails() {
  const [showBoxModal, setShowBoxModal] = useState(false);

  const handleBoxFull = () => {
    setShowBoxModal(true);
  };

  const handleBoxModalClose = () => {
    setShowBoxModal(false);
  };

  const handleBoxModalSubmit = async (boxType: 'single' | 'small' | 'big' | 'bag', weight: number) => {
    // This will be implemented later
    console.log('Processing:', { boxType, weight });
    setShowBoxModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Customer Info Card */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Customer Name
            </h1>
            <div className="mt-2 space-y-2">
              <div className="text-gray-600">
                Bidder #: <span className="font-medium">12345</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Mail className="h-4 w-4 mr-2" />
                <a href="mailto:customer@example.com" className="hover:text-blue-600">
                  customer@example.com
                </a>
              </div>
              <div className="text-gray-600">
                Balance: <span className="font-medium">$0.00</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scanning Fields */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {/* Item Lookup */}
        <div className="relative">
          <div className="absolute -top-3 left-4 px-2 bg-gray-100 rounded">
            <div className="flex items-center gap-2">
              <Scan className="h-4 w-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-800">Item Lookup</span>
            </div>
          </div>
          <div className="bg-gray-100 rounded-lg p-4 pt-6">
            <input
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-300 focus:border-gray-400 focus:ring-0"
              placeholder="Scan barcode..."
            />
          </div>
        </div>

        {/* Scan to Tray */}
        <div className="relative">
          <div className="absolute -top-3 left-4 px-2 bg-green-50 rounded">
            <div className="flex items-center gap-2">
              <Inbox className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium text-green-800">Scan to Tray</span>
            </div>
          </div>
          <div className="bg-green-50 rounded-lg p-4 pt-6">
            <input
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-green-300 focus:border-green-400 focus:ring-0"
              placeholder="Scan barcode..."
            />
          </div>
        </div>

        {/* Scan to Box */}
        <div className="relative">
          <div className="absolute -top-3 left-4 px-2 bg-blue-50 rounded">
            <div className="flex items-center gap-2">
              <Box className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-800">Scan to Box</span>
            </div>
          </div>
          <div className="bg-blue-50 rounded-lg p-4 pt-6">
            <input
              type="text"
              className="w-full px-4 py-3 rounded-lg border-2 border-blue-300 focus:border-blue-400 focus:ring-0"
              placeholder="Scan barcode..."
            />
          </div>
        </div>
      </div>

      {/* Management Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          className="px-4 py-3 bg-pink-500 text-white rounded-lg hover:bg-pink-600 font-medium"
        >
          Add Bag to Cage
        </button>
        <button
          onClick={handleBoxFull}
          className="px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 font-medium"
        >
          Box or Bag Full
        </button>
        <button
          className="px-4 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 font-medium"
        >
          Add Box to Shelf
        </button>
      </div>

      {/* Box Modal */}
      <BoxModal 
        isOpen={showBoxModal}
        onClose={handleBoxModalClose}
        onSubmit={handleBoxModalSubmit}
      />

      {/* Account Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {/* Unprocessed Orders */}
        <div className="bg-gray-100 rounded-lg p-4 flex flex-col items-center justify-center">
          <Package className="h-8 w-8 text-gray-600 mb-2" />
          <span className="text-2xl font-bold text-gray-800">0</span>
          <span className="text-sm text-gray-600">Unprocessed Orders</span>
        </div>

        {/* Items in Box */}
        <div className="bg-blue-50 rounded-lg p-4 flex flex-col items-center justify-center">
          <Box className="h-8 w-8 text-blue-600 mb-2" />
          <span className="text-2xl font-bold text-blue-800">0</span>
          <span className="text-sm text-blue-600">Items in Box</span>
        </div>

        {/* Days Since Last Order */}
        <div className="bg-purple-50 rounded-lg p-4 flex flex-col items-center justify-center">
          <Clock className="h-8 w-8 text-purple-600 mb-2" />
          <span className="text-2xl font-bold text-purple-800">0</span>
          <span className="text-sm text-purple-600">Days Since Last Order</span>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-800">Purchased Items</h2>
            <button
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              <Trash2 className="h-4 w-4" />
              Delete Selected (0)
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="w-12 px-6 py-3">
                  <input
                    type="checkbox"
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Item Code
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Item Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Process Time
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <tr className="hover:bg-gray-50">
                <td className="w-12 px-6 py-4">
                  <input
                    type="checkbox"
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">
                    ITEM-001
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    Sample Item
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                    UNPROCESSED
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">
                    -
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Past Shipped Orders */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800">Past Shipped Orders</h2>
        </div>
        <div className="divide-y divide-gray-200">
          <div className="p-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-lg font-medium text-gray-900">
                  Sample Box Delivery
                </h3>
                <p className="text-sm text-gray-500">
                  Shipped on 01/01/2025
                </p>
                <div className="flex items-center gap-2 text-gray-600 mt-1">
                  <Scale className="h-4 w-4" />
                  <span>2.5kg</span>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-gray-700">
                <Package className="h-4 w-4 text-gray-500" />
                <span>ITEM-001</span>
                <span className="text-gray-400">-</span>
                <span>Sample Item</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}