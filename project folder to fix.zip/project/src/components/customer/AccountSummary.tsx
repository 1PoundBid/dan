import React from 'react';
import { Package, Archive, Box, Inbox, Clock } from 'lucide-react';

interface AccountSummaryProps {
  unprocessedOrders: number;
  bagsInCage: number;
  boxesOnShelf: number;
  itemsInTray: number;
  itemsInBox: number;
  daysSinceLastOrder: number;
}

export function AccountSummary({
  unprocessedOrders,
  bagsInCage,
  boxesOnShelf,
  itemsInTray,
  itemsInBox,
  daysSinceLastOrder
}: AccountSummaryProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
      <div className="bg-gray-100 rounded-lg p-4 flex flex-col items-center justify-center">
        <Package className="h-8 w-8 text-gray-600 mb-2" />
        <span className="text-2xl font-bold text-gray-800">{unprocessedOrders}</span>
        <span className="text-sm text-gray-600">Unprocessed Orders</span>
      </div>

      <div className="bg-pink-50 rounded-lg p-4 flex flex-col items-center justify-center">
        <Archive className="h-8 w-8 text-pink-600 mb-2" />
        <span className="text-2xl font-bold text-pink-800">{bagsInCage}</span>
        <span className="text-sm text-pink-600">Bags in Cage</span>
      </div>

      <div className="bg-orange-50 rounded-lg p-4 flex flex-col items-center justify-center">
        <Box className="h-8 w-8 text-orange-600 mb-2" />
        <span className="text-2xl font-bold text-orange-800">{boxesOnShelf}</span>
        <span className="text-sm text-orange-600">Boxes on Shelf</span>
      </div>

      <div className="bg-green-50 rounded-lg p-4 flex flex-col items-center justify-center">
        <Inbox className="h-8 w-8 text-green-600 mb-2" />
        <span className="text-2xl font-bold text-green-800">{itemsInTray}</span>
        <span className="text-sm text-green-600">Items in Tray</span>
      </div>

      <div className="bg-blue-50 rounded-lg p-4 flex flex-col items-center justify-center">
        <Box className="h-8 w-8 text-blue-600 mb-2" />
        <span className="text-2xl font-bold text-blue-800">{itemsInBox}</span>
        <span className="text-sm text-blue-600">Items in Box</span>
      </div>

      <div className="bg-purple-50 rounded-lg p-4 flex flex-col items-center justify-center">
        <Clock className="h-8 w-8 text-purple-600 mb-2" />
        <span className="text-2xl font-bold text-purple-800">{daysSinceLastOrder}</span>
        <span className="text-sm text-purple-600">Days Since Last Order</span>
      </div>
    </div>
  );
}