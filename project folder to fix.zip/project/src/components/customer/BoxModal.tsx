import React, { useState } from 'react';
import { Box, Package, Scale } from 'lucide-react';

interface BoxModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (boxType: 'single' | 'small' | 'big' | 'bag', weight: number, bagType?: 'standard' | 'large') => void;
}

interface BoxOption {
  value: 'single' | 'small' | 'big' | 'bag';
  label: string;
  description: string;
  icon: typeof Box | typeof Package;
  price: number | null;
}

const boxOptions: BoxOption[] = [
  {
    value: 'single',
    label: 'Single Item',
    description: 'For shipping a single item',
    icon: Box,
    price: 3.99
  },
  {
    value: 'small',
    label: 'Small Box',
    description: 'For up to 5 items',
    icon: Box,
    price: 7.99
  },
  {
    value: 'big',
    label: 'Big Box',
    description: 'For up to 20 items',
    icon: Box,
    price: 9.99
  },
  {
    value: 'bag',
    label: 'Black Bag',
    description: 'For collection only',
    icon: Package,
    price: null
  }
];

export function BoxModal({ isOpen, onClose, onSubmit }: BoxModalProps) {
  const [boxType, setBoxType] = useState<'single' | 'small' | 'big' | 'bag'>('single');
  const [bagType, setBagType] = useState<'standard' | 'large'>('standard');
  const [weight, setWeight] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = () => {
    setError(null);
    const parsedWeight = parseFloat(weight);

    if (!weight.trim() || isNaN(parsedWeight) || parsedWeight <= 0) {
      setError('Please enter a valid weight');
      return;
    }

    onSubmit(boxType, parsedWeight, boxType === 'bag' ? bagType : undefined);
    setWeight('');
    setBoxType('single');
    setBagType('standard');
    onClose();
  };

  const selectedOption = boxOptions.find(option => option.value === boxType);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-gray-900">Complete Packaging</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <span className="sr-only">Close</span>
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-6">
          {/* Box Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Type
            </label>
            <div className="space-y-2">
              {boxOptions.map(option => (
                <label
                  key={option.value}
                  className={`flex items-center justify-between p-3 rounded-lg border-2 cursor-pointer transition-colors ${
                    boxType === option.value
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="boxType"
                      value={option.value}
                      checked={boxType === option.value}
                      onChange={(e) => setBoxType(e.target.value as any)}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <option.icon className="h-5 w-5" />
                        <span className="font-medium">{option.label}</span>
                      </div>
                      <p className="text-sm text-gray-500">{option.description}</p>
                    </div>
                  </div>
                  {option.price !== null && (
                    <span className="text-sm font-medium text-blue-600">
                      £{option.price.toFixed(2)}
                    </span>
                  )}
                </label>
              ))}
            </div>
          </div>

          {/* Bag Type Selection (only shown when bag is selected) */}
          {boxType === 'bag' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bag Size
              </label>
              <select
                value={bagType}
                onChange={(e) => setBagType(e.target.value as 'standard' | 'large')}
                className="w-full rounded-lg border-gray-300"
              >
                <option value="standard">Standard Bag</option>
                <option value="large">Large Bag</option>
              </select>
            </div>
          )}

          {/* Weight Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Weight (kg)
            </label>
            <div className="relative">
              <Scale className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                step="0.1"
                min="0.1"
                placeholder="Enter weight in kg"
              />
            </div>
            {error && (
              <p className="mt-1 text-sm text-red-600">{error}</p>
            )}
          </div>

          {/* Summary */}
          {selectedOption && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2">Summary</h4>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Type:</span>
                  <span className="font-medium">{selectedOption.label}</span>
                </div>
                {boxType === 'bag' && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Size:</span>
                    <span className="font-medium">
                      {bagType === 'standard' ? 'Standard Bag' : 'Large Bag'}
                    </span>
                  </div>
                )}
                {selectedOption.price !== null && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Price:</span>
                    <span className="font-medium text-blue-600">£{selectedOption.price.toFixed(2)}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:text-gray-900 font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
            >
              Confirm
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}