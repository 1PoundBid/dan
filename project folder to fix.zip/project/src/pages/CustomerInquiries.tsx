import React, { useState, useEffect, useRef } from 'react';
import { Mail, Phone, Clock, AlertCircle, MessageSquare, Trash2, Send, CheckCircle2, Plus, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { sendSMS, getTwilioConfig } from '../lib/twilio';
import { LoadingSpinner } from '../components/LoadingSpinner';
import type { RealtimeChannel } from '@supabase/supabase-js';

interface Customer {
  id: string;
  first_name: string;
  last_name: string;
  phone: string;
}

interface CustomerInquiry {
  id: string;
  customer_name: string;
  email: string;
  phone: string;
  question: string;
  created_at: string;
}

interface SMSReply {
  id: string;
  from_number: string;
  to_number: string;
  message: string;
  created_at: string;
  read: boolean;
}

interface SMSTemplate {
  id: string;
  name: string;
  content: string;
}

interface SMSThread {
  phoneNumber: string;
  customerName?: string;
  messages: SMSReply[];
}

interface TwilioConfig {
  phone_number: string;
}

export function CustomerInquiries() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerSearch, setCustomerSearch] = useState('');
  const [inquiries, setInquiries] = useState<CustomerInquiry[]>([]);
  const [smsReplies, setSMSReplies] = useState<SMSReply[]>([]);
  const [templates, setTemplates] = useState<SMSTemplate[]>([]);
  const [selectedTemplates, setSelectedTemplates] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedInquiries, setSelectedInquiries] = useState<string[]>([]);
  const [smsMessage, setSmsMessage] = useState('');
  const [manualPhone, setManualPhone] = useState('');
  const [newTemplate, setNewTemplate] = useState({ name: '', content: '' });
  const [sendingSMS, setSendingSMS] = useState(false);
  const [twilio, setTwilio] = useState<TwilioConfig | null>(null);
  const repliesChannelRef = useRef<RealtimeChannel | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchCustomers();
    fetchInquiries();
    fetchSMSReplies();
    fetchTemplates();
    fetchTwilioConfig();
    setupRealtimeSubscription();

    return () => {
      if (repliesChannelRef.current) {
        repliesChannelRef.current.unsubscribe();
      }
    };
  }, []);

  const fetchTwilioConfig = async () => {
    try {
      const config = await getTwilioConfig();
      setTwilio({
        phone_number: config.phone_number
      });
    } catch (err) {
      console.error('Error fetching Twilio config:', err);
      setError('Failed to load Twilio configuration');
    }
  };

  const setupRealtimeSubscription = () => {
    repliesChannelRef.current = supabase
      .channel('sms-replies-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'sms_replies'
        },
        () => {
          fetchSMSReplies();
        }
      )
      .subscribe();
  };

  const fetchCustomers = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('customers')
        .select('id, first_name, last_name, phone')
        .order('first_name');

      if (fetchError) throw fetchError;
      setCustomers(data || []);
    } catch (err) {
      console.error('Error fetching customers:', err);
      setError('Failed to fetch customers');
    }
  };

  const fetchInquiries = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('customer_inquiries')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setInquiries(data || []);
    } catch (err) {
      console.error('Error fetching inquiries:', err);
      setError('Failed to fetch inquiries');
    }
  };

  const fetchSMSReplies = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('sms_replies')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setSMSReplies(data || []);
    } catch (err) {
      console.error('Error fetching SMS replies:', err);
      setError('Failed to fetch SMS replies');
    } finally {
      setLoading(false);
    }
  };

  const fetchTemplates = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('sms_templates')
        .select('*')
        .order('name');

      if (fetchError) throw fetchError;
      setTemplates(data || []);
    } catch (err) {
      console.error('Error fetching templates:', err);
      setError('Failed to fetch templates');
    }
  };

  const handleDeleteSelected = async () => {
    if (!selectedInquiries.length) return;

    if (!confirm(`Are you sure you want to delete ${selectedInquiries.length} selected inquir${selectedInquiries.length === 1 ? 'y' : 'ies'}?`)) {
      return;
    }

    try {
      const { error: deleteError } = await supabase
        .from('customer_inquiries')
        .delete()
        .in('id', selectedInquiries);

      if (deleteError) throw deleteError;

      setInquiries(prev => prev.filter(inquiry => !selectedInquiries.includes(inquiry.id)));
      setSelectedInquiries([]);
    } catch (err) {
      console.error('Error deleting inquiries:', err);
      setError('Failed to delete inquiries');
    }
  };

  const handleDeleteTemplates = async () => {
    if (!selectedTemplates.length) return;

    if (!confirm(`Are you sure you want to delete ${selectedTemplates.length} selected template${selectedTemplates.length === 1 ? '' : 's'}?`)) {
      return;
    }

    try {
      const { error: deleteError } = await supabase
        .from('sms_templates')
        .delete()
        .in('id', selectedTemplates);

      if (deleteError) throw deleteError;

      setTemplates(prev => prev.filter(template => !selectedTemplates.includes(template.id)));
      setSelectedTemplates([]);
    } catch (err) {
      console.error('Error deleting templates:', err);
      setError('Failed to delete templates');
    }
  };

  const markReplyAsRead = async (replyId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('sms_replies')
        .update({ read: true })
        .eq('id', replyId);

      if (updateError) throw updateError;

      setSMSReplies(prev =>
        prev.map(reply =>
          reply.id === replyId ? { ...reply, read: true } : reply
        )
      );
    } catch (err) {
      console.error('Error marking reply as read:', err);
      setError('Failed to mark reply as read');
    }
  };

  const handleSaveTemplate = async () => {
    if (!newTemplate.name || !newTemplate.content) {
      setError('Please provide both a name and content for the template');
      return;
    }

    try {
      const { error: saveError } = await supabase
        .from('sms_templates')
        .insert(newTemplate);

      if (saveError) throw saveError;

      setNewTemplate({ name: '', content: '' });
      fetchTemplates();
    } catch (err) {
      console.error('Error saving template:', err);
      setError('Failed to save template');
    }
  };

  const handleTemplateSelect = (templateContent: string) => {
    setSmsMessage(templateContent);
  };

  const handleSendSMS = async () => {
    if (!smsMessage.trim()) {
      setError('Please enter a message');
      return;
    }

    if (!manualPhone) {
      setError('Please enter a phone number');
      return;
    }

    setSendingSMS(true);
    setError(null);

    try {
      await sendSMS(manualPhone, smsMessage);
      setSmsMessage('');
      setManualPhone('');
      setError(null);
    } catch (err) {
      console.error('Error sending SMS:', err);
      setError(err instanceof Error ? err.message : 'Failed to send SMS message');
    } finally {
      setSendingSMS(false);
    }
  };

  // Group messages by phone number into threads
  const smsThreads = smsReplies.reduce<Record<string, SMSThread>>((acc, reply) => {
    // For outgoing messages (from Twilio), use the recipient's number as the thread key
    // For incoming messages (to Twilio), use the sender's number as the thread key
    const phoneNumber = twilio?.phone_number && reply.from_number === twilio.phone_number 
      ? reply.to_number 
      : reply.from_number;

    if (!acc[phoneNumber]) {
      const customer = customers.find(c => c.phone === phoneNumber);
      acc[phoneNumber] = {
        phoneNumber,
        customerName: customer ? `${customer.first_name} ${customer.last_name}` : undefined,
        messages: []
      };
    }
    acc[phoneNumber].messages.push(reply);
    return acc;
  }, {});

  // Sort messages within each thread by date
  Object.values(smsThreads).forEach(thread => {
    thread.messages.sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  });

  const filteredCustomers = customers.filter(customer => {
    if (!customerSearch.trim()) return false;
    
    const searchTerm = customerSearch.toLowerCase();
    const fullName = `${customer.first_name} ${customer.last_name}`.toLowerCase();
    return fullName.includes(searchTerm) || (customer.phone && customer.phone.includes(searchTerm));
  });

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      {/* SMS Composition Section */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <Send className="h-6 w-6 text-blue-500" />
          <h2 className="text-xl font-semibold text-gray-900">Send SMS</h2>
        </div>

        <div className="space-y-4">
          {/* Phone Number Search */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Search Customer or Enter Phone Number
            </label>
            <div className="relative">
              <input
                ref={searchInputRef}
                type="text"
                value={customerSearch}
                onChange={(e) => setCustomerSearch(e.target.value)}
                placeholder="Search by name or phone number..."
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          {/* Customer Search Results */}
          {customerSearch.trim() !== '' && filteredCustomers.length > 0 && (
            <div className="border rounded-lg divide-y max-h-48 overflow-y-auto">
              {filteredCustomers.map((customer) => (
                <button
                  key={customer.id}
                  onClick={() => {
                    setManualPhone(customer.phone);
                    setCustomerSearch('');
                    searchInputRef.current?.blur();
                  }}
                  className="w-full p-3 text-left hover:bg-gray-50 flex items-center justify-between"
                >
                  <span className="font-medium">
                    {customer.first_name} {customer.last_name}
                  </span>
                  <span className="text-gray-600">{customer.phone}</span>
                </button>
              ))}
            </div>
          )}

          {/* Manual Phone Number Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phone Number
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <input
                type="tel"
                value={manualPhone}
                onChange={(e) => setManualPhone(e.target.value)}
                placeholder="+1234567890"
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <p className="mt-1 text-sm text-gray-500">
              Enter number in international format (e.g. +1234567890)
            </p>
          </div>

          {/* Message Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Message
            </label>
            <textarea
              value={smsMessage}
              onChange={(e) => setSmsMessage(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={3}
              placeholder="Enter your message..."
            />
          </div>

          {/* SMS Templates */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Templates
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map((template) => (
                <div
                  key={template.id}
                  className={`p-4 border rounded-lg transition-colors ${
                    selectedTemplates.includes(template.id) 
                      ? 'border-blue-500 bg-blue-50'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={selectedTemplates.includes(template.id)}
                      onChange={(e) => {
                        setSelectedTemplates(prev =>
                          e.target.checked
                            ? [...prev, template.id]
                            : prev.filter(id => id !== template.id)
                        );
                      }}
                      className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{template.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">{template.content}</p>
                      <button
                        onClick={() => handleTemplateSelect(template.content)}
                        className="mt-2 text-sm text-blue-600 hover:text-blue-700"
                      >
                        Use Template
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Send Button */}
          <button
            onClick={handleSendSMS}
            disabled={sendingSMS || !smsMessage.trim() || !manualPhone}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Send className="h-4 w-4" />
            {sendingSMS ? 'Sending...' : 'Send SMS'}
          </button>
        </div>
      </div>

      {/* SMS Templates Section */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">SMS Templates</h2>
          {selectedTemplates.length > 0 && (
            <button
              onClick={handleDeleteTemplates}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              <Trash2 className="h-4 w-4" />
              Delete Selected ({selectedTemplates.length})
            </button>
          )}
        </div>
        
        <div className="space-y-4">
          {/* Existing Templates */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {templates.map((template) => (
              <div
                key={template.id}
                className={`p-4 border rounded-lg transition-colors ${
                  selectedTemplates.includes(template.id) 
                    ? 'border-blue-500 bg-blue-50'
                    : 'hover:bg-gray-50'
                }`}
              >
                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={selectedTemplates.includes(template.id)}
                    onChange={(e) => {
                      setSelectedTemplates(prev =>
                        e.target.checked
                          ? [...prev, template.id]
                          : prev.filter(id => id !== template.id)
                      );
                    }}
                    className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900">{template.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">{template.content}</p>
                    <button
                      onClick={() => setSmsMessage(template.content)}
                      className="mt-2 text-sm text-blue-600 hover:text-blue-700"
                    >
                      Use Template
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* New Template Form */}
          <div className="border-t pt-4 mt-4">
            <h3 className="font-medium text-gray-900 mb-3">Add New Template</h3>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Template name"
                value={newTemplate.name}
                onChange={(e) => setNewTemplate(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <textarea
                placeholder="Template content"
                value={newTemplate.content}
                onChange={(e) => setNewTemplate(prev => ({ ...prev, content: e.target.value }))}
                rows={3}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                onClick={handleSaveTemplate}
                disabled={!newTemplate.name || !newTemplate.content}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Plus className="h-4 w-4" />
                Save Template
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* SMS Replies Section */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">SMS Conversations</h2>
          <span className="text-sm text-gray-500">
            {smsReplies.filter(reply => !reply.read).length} unread
          </span>
        </div>
        
        <div className="space-y-6">
          {Object.values(smsThreads).length === 0 ? (
            <p className="text-gray-500 text-center py-4">No SMS conversations yet</p>
          ) : (
            Object.values(smsThreads).map((thread) => (
              <div
                key={thread.phoneNumber}
                className="border rounded-lg overflow-hidden"
              >
                <div className="bg-gray-50 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Phone className="h-5 w-5 text-blue-500" />
                      <span className="font-medium">
                        {thread.customerName || thread.phoneNumber}
                      </span>
                      <button
                        onClick={() => setManualPhone(thread.phoneNumber)}
                        className="ml-2 text-sm text-blue-600 hover:text-blue-700"
                      >
                        Reply
                      </button>
                    </div>
                  </div>
                </div>
                <div className="divide-y divide-gray-100">
                  {thread.messages.map((message) => {
                    const isOutgoing = twilio?.phone_number && message.from_number === twilio.phone_number;
                    
                    return (
                      <div
                        key={message.id}
                        className={`p-4 ${
                          message.read ? 'bg-white' : 'bg-blue-50'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className={`text-sm font-medium ${
                              isOutgoing ? 'text-green-600' : 'text-blue-600'
                            }`}>
                              {isOutgoing ? 'Sent' : 'Received'}
                            </span>
                            <span className="text-gray-500 text-sm">
                              {new Date(message.created_at).toLocaleString()}
                            </span>
                          </div>
                          {!message.read && !isOutgoing && (
                            <button
                              onClick={() => markReplyAsRead(message.id)}
                              className="p-1 text-blue-600 hover:text-blue-700 hover:bg-blue-100 rounded"
                              title="Mark as read"
                            >
                              <CheckCircle2 className="h-5 w-5" />
                            </button>
                          )}
                        </div>
                        <p className="text-gray-700 whitespace-pre-wrap pl-4 border-l-2 border-gray-200">
                          {message.message}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Customer Inquiries Section */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Customer Inquiries</h1>
          {selectedInquiries.length > 0 && (
            <button
              onClick={handleDeleteSelected}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              <Trash2 className="h-4 w-4" />
              Delete Selected ({selectedInquiries.length})
            </button>
          )}
        </div>
        
        <div className="space-y-4">
          {inquiries.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No inquiries found</p>
          ) : (
            inquiries.map((inquiry) => (
              <div
                key={inquiry.id}
                className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <input
                      type="checkbox"
                      checked={selectedInquiries.includes(inquiry.id)}
                      onChange={(e) => {
                        setSelectedInquiries(prev =>
                          e.target.checked
                            ? [...prev, inquiry.id]
                            : prev.filter(id => id !== inquiry.id)
                        );
                      }}
                      className="h-5 w-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-5 w-5 text-blue-500" />
                        <span className="font-medium">{inquiry.customer_name}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Mail className="h-4 w-4" />
                        <a href={`mailto:${inquiry.email}`} className="hover:text-blue-600">
                          {inquiry.email}
                        </a>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Phone className="h-4 w-4" />
                        <button
                          onClick={() => setManualPhone(inquiry.phone)}
                          className="hover:text-blue-600"
                        >
                          {inquiry.phone}
                        </button>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Clock className="h-4 w-4" />
                        <span>{new Date(inquiry.created_at).toLocaleString()}</span>
                      </div>
                      <div className="mt-4 bg-gray-50 p-4 rounded-lg">
                        <p className="text-gray-700 whitespace-pre-wrap">{inquiry.question}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}