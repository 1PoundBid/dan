/**
 * Simple speech utility that uses browser's built-in speech synthesis
 */
export function speak(text: string) {
  // Skip empty text
  if (!text?.trim()) return;
  
  // Use browser speech synthesis
  if ('speechSynthesis' in window) {
    const utterance = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utterance);
  }
}