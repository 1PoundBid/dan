# 1PoundBid System Backup
Generated: 24/03/2025, 15:18:52

## Backup Information
- Timestamp: 2025-03-24T15:18:52.749Z
- System: 1PoundBid
- Version: 0.0.0
- Total Files: 295

## File Categories
- Source Files: 46
- Database Migrations: 68
- Configuration Files: 61

## Dependencies
```json
{
  "@supabase/supabase-js": "^2.39.7",
  "lucide-react": "^0.344.0",
  "react": "^18.3.1",
  "react-dom": "^18.3.1",
  "react-router-dom": "^6.22.3"
}
```

## Dev Dependencies
```json
{
  "@types/react": "^18.2.64",
  "@types/react-dom": "^18.2.21",
  "@typescript-eslint/eslint-plugin": "^7.1.1",
  "@typescript-eslint/parser": "^7.1.1",
  "@vitejs/plugin-react": "^4.2.1",
  "autoprefixer": "^10.4.18",
  "eslint": "^8.57.0",
  "eslint-plugin-react-hooks": "^4.6.0",
  "eslint-plugin-react-refresh": "^0.4.5",
  "postcss": "^8.4.35",
  "tailwindcss": "^3.4.1",
  "typescript": "^5.2.2",
  "vite": "^5.1.6"
}
```

## Restore Instructions
1. Create a new project directory
2. Extract all files from the backup
3. Run `npm install` to install dependencies
4. Set up Supabase environment variables
5. Run `npm run dev` to start the development server

## Important Notes
- This backup contains all source code and configuration
- Database content is NOT included, only schema migrations
- Environment variables are NOT included for security reasons
