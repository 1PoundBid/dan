# 1PoundBid Database Schema

## Tables

### customers
- id (uuid, primary key)
- bidder_number (text, unique)
- first_name (text)
- last_name (text)
- email (text)
- balance (decimal)
- created_at (timestamptz)
- updated_at (timestamptz)

### orders
- id (uuid, primary key)
- customer_id (uuid, foreign key)
- recorded_at (timestamptz)
- item_code (text)
- item_name (text)
- quantity (integer)
- debit (decimal)
- credit (decimal)
- status (enum: unprocessed, in_tray, in_box, shipped)
- processed_at (timestamptz)
- created_at (timestamptz)
- updated_at (timestamptz)

### storage_items
- id (uuid, primary key)
- customer_id (uuid, foreign key)
- type (text: bag_cage, box_shelf)
- created_at (timestamptz)

### shipped_boxes
- id (uuid, primary key)
- customer_id (uuid, foreign key)
- type (text: single, small, big)
- weight (decimal)
- archived (boolean)
- created_at (timestamptz)

### shipped_box_items
- id (uuid, primary key)
- box_id (uuid, foreign key)
- order_id (uuid, foreign key)
- created_at (timestamptz)

### box_orders
- id (uuid, primary key)
- customer_name (text)
- email (text)
- box_type (text)
- status (text)
- created_at (timestamptz)
- updated_at (timestamptz)

### customer_inquiries
- id (uuid, primary key)
- customer_name (text)
- email (text)
- phone (text)
- question (text)
- priority (text)
- status (text)
- created_at (timestamptz)
- updated_at (timestamptz)

### twilio_config
- id (uuid, primary key)
- account_sid (text)
- auth_token (text)
- phone_number (text)
- created_at (timestamptz)
- updated_at (timestamptz)

### sms_replies
- id (uuid, primary key)
- from_number (text)
- to_number (text)
- message (text)
- created_at (timestamptz)
- read (boolean)
